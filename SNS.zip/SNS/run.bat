echo ============================================================
echo   Starting LogiPulse (Disruption-Aware Logistics Platform)
echo   Autonomous Fleet Operations
echo ============================================================
echo.
echo Opening server at http://localhost:8000
echo.

set PYTHON_EXE=C:\Users\pravi\AppData\Local\Python\bin\python.exe

if exist "%PYTHON_EXE%" (
    "%PYTHON_EXE%" "c:\Users\pravi\OneDrive\Documents\SNS\disruption-logistics\run_server.py"
) else (
    python "c:\Users\pravi\OneDrive\Documents\SNS\disruption-logistics\run_server.py"
)

pause
