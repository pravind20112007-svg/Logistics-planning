@echo off
echo ============================================================
echo   Starting LogiGuard AI
echo   Disruption-Aware Logistics Planning System
echo   Autonomous Multi-Role Fleet Operations Console
echo ============================================================
echo.
echo Opening server at http://localhost:8000
echo.

set PYTHON_EXE=C:\Users\pravi\AppData\Local\Python\bin\python.exe

if exist "%PYTHON_EXE%" (
    "%PYTHON_EXE%" "c:\Users\pravi\OneDrive\Documents\SNS\logiguard-ai\run_server.py"
) else (
    python "c:\Users\pravi\OneDrive\Documents\SNS\logiguard-ai\run_server.py"
)

pause
