import React, { useState, useEffect } from 'react';
import MapView from './components/MapView';
import StatusBanner from './components/StatusBanner';
import ImpactPanel from './components/ImpactPanel';
import ActionPanel from './components/ActionPanel';
import DeliveryTable from './components/DeliveryTable';
import axios from 'axios';

const App = () => {
  const [data, setData] = useState({ vehicles: [], deliveries: [], graph: null });
  const [disruption, setDisruption] = useState(null);
  const [impact, setImpact] = useState(null);
  const [plan, setPlan] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchInitialData();
  }, []);

  const fetchInitialData = async () => {
    try {
      setLoading(true);
      const res = await axios.get('http://localhost:8000/fleet');
      setData(res.data);
    } catch (err) {
      console.error("Failed to fetch fleet data", err);
    } finally {
      setLoading(false);
    }
  };

  const triggerDisruption = async () => {
    try {
      const demoDisruption = {
        id: "DSR-001",
        type: "road_closure",
        affected_edges: [[12, 38]], // Avinashi Road closure demo
        start_time: new Date().toISOString()
      };

      const res = await axios.post('http://localhost:8000/disruption', demoDisruption);
      setDisruption(demoDisruption);
      setImpact(res.data.impact);
      setPlan(res.data.plan);
    } catch (err) {
      console.error("Failed to trigger disruption", err);
    }
  };

  const applyPlan = async () => {
    try {
      await axios.post('http://localhost:8000/plan/apply');
      fetchInitialData();
      setImpact(null);
      setDisruption(null);
    } catch (err) {
      console.error("Failed to apply plan", err);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <header className="mb-8 flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Smart Logistics Dashboard</h1>
          <p className="text-slate-500">Disruption-Aware Planning System</p>
        </div>
        <StatusBanner isDisrupted={!!disruption} />
      </header>

      <div className="grid grid-cols-12 gap-6">
        <div className="col-span-8 space-y-6">
          <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200">
            <h2 className="text-lg font-semibold mb-4">Live Network Map</h2>
            <MapView vehicles={data.vehicles} graph={data.graph} disruption={disruption} plan={plan} />
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <h2 className="text-lg font-semibold mb-4">Active Deliveries</h2>
            <DeliveryTable deliveries={data.deliveries} />
          </div>
        </div>

        <div className="col-span-4 space-y-6">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <h2 className="text-lg font-semibold mb-4">Controls</h2>
            <button
              onClick={triggerDisruption}
              className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-4 rounded-lg transition"
            >
              Trigger Demo Disruption
            </button>
          </div>

          {impact && (
            <ImpactPanel impact={impact} />
          )}

          {plan && (
            <ActionPanel plan={plan} onApply={applyPlan} />
          )}
        </div>
      </div>
    </div>
  );
};

export default App;
