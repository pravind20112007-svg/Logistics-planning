import React from 'react';
import { Sparkles, CheckCircle, ArrowRight } from 'lucide-react';

const ActionPanel = ({ plan, onApply }) => {
  return (
    <div className="bg-white border border-slate-200 p-6 rounded-xl shadow-lg ring-2 ring-blue-500 ring-opacity-50">
      <div className="flex items-center gap-2 text-blue-600 mb-4">
        <Sparkles size={20} />
        <h2 className="text-lg font-bold">AI Recommendation</h2>
      </div>

      <div className="bg-blue-50 p-4 rounded-lg mb-6 border border-blue-100">
        <p className="text-sm text-blue-900 leading-relaxed">
          {plan.summary || "Reroute 5 vehicles via Gandhipuram bypass. Reassign 2 urgent deliveries to V10 to minimize delay from 55m to 18m."}
        </p>
      </div>

      <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider mb-3">Proposed Actions</h3>
      <div className="space-y-3 mb-6">
        {plan.changes.map((change, idx) => (
          <div key={idx} className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg border border-slate-100">
            <div className="mt-1 bg-blue-100 text-blue-600 p-1 rounded">
              <ArrowRight size={14} />
            </div>
            <div>
              <p className="text-sm font-semibold text-slate-800">{change.type}</p>
              <p className="text-xs text-slate-500">{change.description}</p>
            </div>
          </div>
        ))}
      </div>

      <button
        onClick={onApply}
        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg flex items-center justify-center gap-2 transition"
      >
        <CheckCircle size={20} />
        APPLY NEW PLAN
      </button>
    </div>
  );
};

export default ActionPanel;
