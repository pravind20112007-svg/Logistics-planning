import React from 'react';
import { ShieldCheck, AlertTriangle } from 'lucide-react';

const StatusBanner = ({ isDisrupted }) => {
  if (isDisrupted) {
    return (
      <div className="flex items-center gap-2 bg-red-100 text-red-700 px-4 py-2 rounded-full border border-red-200">
        <AlertTriangle size={18} />
        <span className="font-semibold uppercase text-sm tracking-wider">Disruption Detected</span>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2 bg-green-100 text-green-700 px-4 py-2 rounded-full border border-green-200">
      <ShieldCheck size={18} />
      <span className="font-semibold uppercase text-sm tracking-wider">System Normal</span>
    </div>
  );
};

export default StatusBanner;
