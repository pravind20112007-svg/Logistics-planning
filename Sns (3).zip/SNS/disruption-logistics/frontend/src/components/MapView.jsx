import React from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, CircleMarker } from 'react-leaflet';
import L from 'leaflet';

// Fix for default marker icons in Leaflet with Vite
import 'leaflet/dist/leaflet.css';
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
    iconUrl: markerIcon,
    shadowUrl: markerShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

const MapView = ({ vehicles, graph, disruption, plan }) => {
  const center = [11.0183, 76.9644]; // Coimbatore Gandhipuram

  const getPos = (nodeId) => {
    if (!graph || !graph.nodes) return [0, 0];
    const node = graph.nodes.find(n => n.id === nodeId);
    return node ? [node.lat, node.lon] : [0, 0];
  };

  const disruptedEdges = disruption ? disruption.affected_edges : [];

  return (
    <MapContainer center={center} zoom={13} scrollWheelZoom={false}>
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />

      {/* Draw Road Graph Edges */}
      {graph && graph.edges.map((edge, idx) => {
        const isDisrupted = disruptedEdges.some(de =>
          (de[0] === edge.u && de[1] === edge.v) || (de[0] === edge.v && de[1] === edge.u)
        );
        return (
          <Polyline
            key={`edge-${idx}`}
            positions={[getPos(edge.u), getPos(edge.v)]}
            color={isDisrupted ? "#ef4444" : "#cbd5e1"}
            weight={isDisrupted ? 6 : 2}
            dashArray={isDisrupted ? "10, 10" : ""}
          />
        );
      })}

      {/* Draw Vehicle Routes */}
      {vehicles.map(vehicle => (
        <Polyline
          key={`route-${vehicle.id}`}
          positions={vehicle.route.map(nodeId => getPos(nodeId))}
          color="#3b82f6"
          weight={3}
          opacity={0.6}
        />
      ))}

      {/* Draw New Plan Routes if exists */}
      {plan && plan.assignments.map(assignment => (
        <Polyline
          key={`new-route-${assignment.vehicle_id}`}
          positions={assignment.new_route.map(nodeId => getPos(nodeId))}
          color="#22c55e"
          weight={4}
          dashArray="5, 10"
        />
      ))}

      {/* Vehicle Markers */}
      {vehicles.map(vehicle => (
        <CircleMarker
          key={vehicle.id}
          center={getPos(vehicle.location)}
          radius={8}
          pathOptions={{ fillColor: '#3b82f6', color: '#fff', weight: 2, fillOpacity: 1 }}
        >
          <Popup>
            <div className="font-sans">
              <h3 className="font-bold">Vehicle: {vehicle.id}</h3>
              <p>Capacity: {vehicle.capacity}</p>
              <p>Status: {vehicle.status}</p>
            </div>
          </Popup>
        </CircleMarker>
      ))}

      {/* Node Labels (Subset) */}
      {graph && graph.nodes.filter((_, i) => i % 5 === 0).map(node => (
        <Marker key={node.id} position={[node.lat, node.lon]} opacity={0.5}>
          <Popup>{node.name}</Popup>
        </Marker>
      ))}
    </MapContainer>
  );
};

export default MapView;
