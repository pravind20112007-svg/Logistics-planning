import React from 'react';
import { Truck, Package, AlertCircle, Clock } from 'lucide-react';

const ImpactPanel = ({ impact }) => {
  return (
    <div className="bg-red-50 border border-red-100 p-6 rounded-xl shadow-sm">
      <h2 className="text-lg font-bold text-red-800 mb-4 flex items-center gap-2">
        <AlertCircle size={20} />
        Impact Assessment
      </h2>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white p-3 rounded-lg border border-red-100">
          <div className="flex items-center gap-2 text-red-600 mb-1">
            <Truck size={16} />
            <span className="text-xs font-bold uppercase">Vehicles</span>
          </div>
          <p className="text-2xl font-bold text-slate-900">{impact.affected_vehicle_ids.length}</p>
        </div>

        <div className="bg-white p-3 rounded-lg border border-red-100">
          <div className="flex items-center gap-2 text-red-600 mb-1">
            <Package size={16} />
            <span className="text-xs font-bold uppercase">Deliveries</span>
          </div>
          <p className="text-2xl font-bold text-slate-900">{impact.affected_delivery_ids.length}</p>
        </div>

        <div className="bg-white p-3 rounded-lg border border-red-100">
          <div className="flex items-center gap-2 text-red-600 mb-1">
            <AlertCircle size={16} />
            <span className="text-xs font-bold uppercase">Critical</span>
          </div>
          <p className="text-2xl font-bold text-slate-900">{impact.critical_delivery_ids.length}</p>
        </div>

        <div className="bg-white p-3 rounded-lg border border-red-100">
          <div className="flex items-center gap-2 text-red-600 mb-1">
            <Clock size={16} />
            <span className="text-xs font-bold uppercase">Est. Delay</span>
          </div>
          <p className="text-2xl font-bold text-slate-900">{impact.estimated_delay}m</p>
        </div>
      </div>

      <div className="mt-4 p-3 bg-red-100 rounded-lg">
        <p className="text-sm text-red-800 italic font-medium">
          Route 12 (Avinashi Road) is blocked. Re-routing required for all East-bound vehicles.
        </p>
      </div>
    </div>
  );
};

export default ImpactPanel;
