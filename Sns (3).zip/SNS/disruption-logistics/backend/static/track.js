// LogiGuard AI Customer Order Tracking System Logic

// Sample Orders Database
const mockOrdersDB = {
  "LG202610001": {
    orderId: "LG202610001",
    status: "Out for Delivery",
    stepIndex: 4, // 1 to 5
    vehicle: "V-101",
    vehicleModel: "Electric Autonomous Van 2.0",
    partner: "Assigned (Ramesh Kumar - ⭐ 4.9)",
    partnerPhone: "+91 98402 11094",
    currentLocation: "Salem (NH-544 Expressway)",
    destination: "Coimbatore (Peelamedu)",
    destinationFull: "Pravin Kumar, 42 Green Valley Residency, Peelamedu, Coimbatore - 641004",
    eta: "Today, 4:30 PM",
    orderDate: "October 8, 2026 &bull; 08:30 AM",
    items: [
      { name: "📦 1x UltraMax AI Sensor Module Pro", price: "₹14,999" },
      { name: "📦 2x High-Precision LiDAR Sensor Kits", price: "₹8,499" }
    ],
    whereSummary: "Salem &bull; NH-544 Expressway Corridor (38 km to destination)",
    whatSummary: "Traffic disruption detected on original route; autonomous Route B activated (+10m delay)",
    whenSummary: "Today, 4:30 PM (Guaranteed Window)",
    aiInsight: "Your order is currently on <strong>Route B</strong>. A traffic disruption was detected on the original route, so the system automatically selected an alternative route. Estimated delay: <strong>10 minutes</strong>.",
    hasDisruption: true,
    disruptionTitle: "Avinashi Road Construction & Waterlogging Blockade",
    vehiclePos: [11.4500, 77.5500], // Near Erode/Perundurai along highway from Salem
    destPos: [11.0267, 77.0108], // Coimbatore Peelamedu
    disruptionPos: [11.1900, 77.2600], // Avinashi Road
    originalPath: [
      [11.6643, 78.1460], // Salem
      [11.5200, 77.8500], // Sankari
      [11.3400, 77.7100], // Erode
      [11.2300, 77.5800], // Perundurai
      [11.1900, 77.2600], // Avinashi (Blocked)
      [11.0267, 77.0108]  // Peelamedu Coimbatore
    ],
    alternativePath: [
      [11.4500, 77.5500], // Current Vehicle Pos
      [11.3200, 77.3000], // Tiruppur Bypass
      [11.1500, 77.1000], // Annur Corridor
      [11.0267, 77.0108]  // Peelamedu Coimbatore
    ]
  },
  "LG202610002": {
    orderId: "LG202610002",
    status: "Dispatched",
    stepIndex: 3,
    vehicle: "V-204",
    vehicleModel: "Heavy Cargo Transport",
    partner: "Assigned (Karthik S. - ⭐ 4.8)",
    partnerPhone: "+91 94432 88401",
    currentLocation: "Bengaluru Sorting Facility",
    destination: "Chennai Central",
    destinationFull: "Anand R., 15 Marina Bay Road, Mylapore, Chennai - 600004",
    eta: "Tomorrow, 11:00 AM",
    orderDate: "October 8, 2026 &bull; 11:15 AM",
    items: [
      { name: "📦 1x Studio Sound Monitor Pro", price: "₹24,500" }
    ],
    whereSummary: "Bengaluru &bull; National Highway 44 Transit",
    whatSummary: "On schedule, no traffic disruptions encountered",
    whenSummary: "Tomorrow, 11:00 AM",
    aiInsight: "Route is fully clear. Weather telemetry nominal along Golden Quadrilateral. Delivery tracking on-time with 99.8% ETA reliability.",
    hasDisruption: false,
    vehiclePos: [12.9716, 77.5946],
    destPos: [13.0827, 80.2707],
    originalPath: [
      [12.9716, 77.5946],
      [12.9100, 79.1300],
      [13.0827, 80.2707]
    ],
    alternativePath: []
  },
  "LG202610003": {
    orderId: "LG202610003",
    status: "Delivered",
    stepIndex: 5,
    vehicle: "V-088",
    vehicleModel: "Express Metro Courier",
    partner: "Delivered (Pooja M. - ⭐ 5.0)",
    partnerPhone: "+91 98220 54129",
    currentLocation: "Pune Destination Hub",
    destination: "Pune Kothrud",
    destinationFull: "Meera Joshi, 88 Hill View Apt, Kothrud, Pune - 411038",
    eta: "Delivered Today at 01:15 PM",
    orderDate: "October 7, 2026 &bull; 04:20 PM",
    items: [
      { name: "📦 1x Ergonomic AI Office Chair", price: "₹18,200" }
    ],
    whereSummary: "Delivered &bull; Handed to Customer",
    whatSummary: "Completed smoothly with biometric OTP verification",
    whenSummary: "Delivered &bull; Oct 8, 01:15 PM",
    aiInsight: "Order successfully delivered! Thank you for choosing LogiGuard AI Autonomous Delivery Network.",
    hasDisruption: false,
    vehiclePos: [18.5204, 73.8567],
    destPos: [18.5074, 73.8077],
    originalPath: [
      [18.9220, 72.8347],
      [18.5204, 73.8567],
      [18.5074, 73.8077]
    ],
    alternativePath: []
  }
};

let currentOrderData = mockOrdersDB["LG202610001"];
let trackMap = null;
let mapLayers = {
  vehicle: null,
  dest: null,
  disruption: null,
  origRoute: null,
  altRoute: null,
  disruptionCircle: null
};

// Initialize on DOM Loaded
document.addEventListener('DOMContentLoaded', () => {
  lucide.createIcons();
  initTrackMap();
  displayOrderData(currentOrderData);
});

// Handle Form Search Submit
function handleTrackSubmit(e) {
  e.preventDefault();
  const inputEl = document.getElementById('tracking-input');
  const rawId = inputEl.value.trim().toUpperCase();

  if (!rawId) return;

  const btn = document.getElementById('track-btn');
  btn.innerHTML = `<span class="animate-spin">⏳</span> Searching...`;

  setTimeout(() => {
    btn.innerHTML = `<i data-lucide="search" class="w-4 h-4"></i><span>🔍 Track Order</span>`;
    
    // Find in mock database or generate realistic dynamic order
    let order = mockOrdersDB[rawId];
    if (!order) {
      order = generateDynamicOrder(rawId);
    }

    currentOrderData = order;
    displayOrderData(order);

    if (window.confetti) {
      confetti({
        particleCount: 50,
        spread: 50,
        origin: { y: 0.8 }
      });
    }

    lucide.createIcons();
  }, 400);
}

// Load Preset Sample Order
function loadSampleOrder(orderId) {
  const inputEl = document.getElementById('tracking-input');
  inputEl.value = orderId;
  const order = mockOrdersDB[orderId] || generateDynamicOrder(orderId);
  currentOrderData = order;
  displayOrderData(order);
  lucide.createIcons();
}

// Generate Dynamic Order if ID is new
function generateDynamicOrder(customId) {
  return {
    orderId: customId,
    status: "Out for Delivery",
    stepIndex: 4,
    vehicle: `V-${customId.slice(-3) || "101"}`,
    vehicleModel: "Smart Electric Cargo Van",
    partner: "Assigned (LogiGuard Partner - ⭐ 4.9)",
    partnerPhone: "+91 98402 11094",
    currentLocation: "Salem (Transit Hub)",
    destination: "Coimbatore",
    destinationFull: "Customer Delivery Hub, Coimbatore - 641002",
    eta: "Today, 4:30 PM",
    orderDate: "October 8, 2026 &bull; 08:30 AM",
    items: [
      { name: `📦 1x LogiGuard Smart Delivery Package #${customId}`, price: "₹12,499" }
    ],
    whereSummary: "Salem &bull; NH-544 Highway Corridor",
    whatSummary: "Traffic disruption detected; AI Route B active (+10m delay)",
    whenSummary: "Today, 4:30 PM",
    aiInsight: "Your order is currently on <strong>Route B</strong>. A traffic disruption was detected on the original route, so the system automatically selected an alternative route. Estimated delay: <strong>10 minutes</strong>.",
    hasDisruption: true,
    disruptionTitle: "Traffic Bottleneck on Highway",
    vehiclePos: [11.4500, 77.5500],
    destPos: [11.0267, 77.0108],
    disruptionPos: [11.1900, 77.2600],
    originalPath: [
      [11.6643, 78.1460],
      [11.3400, 77.7100],
      [11.1900, 77.2600],
      [11.0267, 77.0108]
    ],
    alternativePath: [
      [11.4500, 77.5500],
      [11.3200, 77.3000],
      [11.0267, 77.0108]
    ]
  };
}

// Display Order Data to DOM
function displayOrderData(order) {
  document.getElementById('order-id-display').innerText = `Order #${order.orderId}`;
  
  // Status Badge
  const badgeEl = document.getElementById('order-status-badge');
  badgeEl.innerHTML = `<span class="w-2 h-2 rounded-full bg-blue-400"></span><span>📦 ${order.status}</span>`;

  // 3 Questions summary
  document.getElementById('summary-where').innerText = order.whereSummary;
  document.getElementById('summary-what').innerText = order.whatSummary;
  document.getElementById('summary-when').innerText = order.whenSummary;

  // Key stats
  document.getElementById('disp-status').innerText = order.status;
  document.getElementById('disp-vehicle').innerText = order.vehicle;
  document.getElementById('disp-partner').innerText = order.partner;
  document.getElementById('disp-location').innerText = order.currentLocation;
  document.getElementById('disp-destination').innerText = order.destination;
  document.getElementById('disp-eta').innerText = order.eta;

  // Customer info
  document.getElementById('cust-date').innerHTML = order.orderDate;
  document.getElementById('cust-address').innerHTML = order.destinationFull.replace(/,/g, ',<br>');
  document.getElementById('cust-items').innerHTML = order.items.map(item => `
    <div class="flex justify-between items-center">
      <span>${item.name}</span>
      <span class="font-mono text-slate-300 font-bold">${item.price}</span>
    </div>
  `).join('');

  // AI Assistant text
  document.getElementById('ai-insight-text').innerHTML = order.aiInsight;

  // Update Stepper Timeline
  updateTimelineStepper(order.stepIndex);

  // Update Map
  updateMap(order);

  lucide.createIcons();
}

// Update Timeline Stepper
function updateTimelineStepper(activeStep) {
  const steps = [1, 2, 3, 4, 5];
  const progressBar = document.getElementById('timeline-progress-bar');
  
  if (progressBar) {
    const percentages = { 1: '10%', 2: '30%', 3: '50%', 4: '75%', 5: '100%' };
    progressBar.style.width = percentages[activeStep] || '75%';
  }

  steps.forEach(s => {
    const el = document.getElementById(`step-${s}`);
    if (!el) return;

    if (s < activeStep) {
      // Completed step
      el.className = "flex md:flex-col items-center md:justify-center gap-3 md:gap-2 text-left md:text-center";
      el.querySelector('div:first-child').className = "w-10 h-10 rounded-full bg-emerald-500 text-slate-950 font-bold flex items-center justify-center shadow-lg shadow-emerald-500/30 shrink-0";
      el.querySelector('div:first-child').innerHTML = `<i data-lucide="check" class="w-5 h-5"></i>`;
    } else if (s === activeStep) {
      // Current active step
      el.className = "flex md:flex-col items-center md:justify-center gap-3 md:gap-2 text-left md:text-center";
      el.querySelector('div:first-child').className = "w-10 h-10 rounded-full bg-blue-600 text-white font-bold flex items-center justify-center shadow-xl shadow-blue-500/50 shrink-0 ring-4 ring-blue-500/30 radar-pulse";
      el.querySelector('div:first-child').innerHTML = `<i data-lucide="truck" class="w-5 h-5 animate-pulse"></i>`;
    } else {
      // Pending step
      el.className = "flex md:flex-col items-center md:justify-center gap-3 md:gap-2 text-left md:text-center opacity-40";
      el.querySelector('div:first-child').className = "w-10 h-10 rounded-full bg-slate-800 text-slate-400 font-bold flex items-center justify-center border border-slate-700 shrink-0";
      el.querySelector('div:first-child').innerHTML = `<i data-lucide="home" class="w-5 h-5"></i>`;
    }
  });
}

// Initialize Leaflet Map
function initTrackMap() {
  const mapEl = document.getElementById('order-map');
  if (!mapEl) return;

  trackMap = L.map('order-map', {
    center: [11.3500, 77.4000],
    zoom: 9,
    scrollWheelZoom: false
  });

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors &bull; LogiGuard AI',
    maxZoom: 18
  }).addTo(trackMap);
}

// Update Map Features for Current Order
function updateMap(order) {
  if (!trackMap) return;

  // Clear previous layers
  Object.values(mapLayers).forEach(layer => {
    if (layer) trackMap.removeLayer(layer);
  });

  // 1. Draw Original Route (Grey/Red dashed)
  if (order.originalPath && order.originalPath.length > 0) {
    mapLayers.origRoute = L.polyline(order.originalPath, {
      color: order.hasDisruption ? '#f43f5e' : '#38bdf8',
      weight: 3.5,
      opacity: order.hasDisruption ? 0.4 : 0.8,
      dashArray: order.hasDisruption ? '6, 6' : null
    }).addTo(trackMap);
  }

  // 2. Draw Alternative AI Route (Emerald Green)
  if (order.alternativePath && order.alternativePath.length > 0) {
    mapLayers.altRoute = L.polyline(order.alternativePath, {
      color: '#10b981',
      weight: 5,
      opacity: 0.95,
      dashArray: '8, 8'
    }).addTo(trackMap);

    mapLayers.altRoute.bindPopup(`
      <div class="p-1 font-sans text-xs">
        <strong class="text-emerald-400">✨ AI Autonomous Route B</strong>
        <p class="text-slate-300">Active bypass avoiding road disruption (+10m detour vs 45m blockade delay)</p>
      </div>
    `);
  }

  // 3. Draw Disruption Marker if present
  if (order.hasDisruption && order.disruptionPos) {
    mapLayers.disruptionCircle = L.circle(order.disruptionPos, {
      radius: 4000,
      fillColor: '#ef4444',
      fillOpacity: 0.25,
      color: '#ef4444',
      weight: 2
    }).addTo(trackMap);

    mapLayers.disruption = L.marker(order.disruptionPos, {
      icon: L.divIcon({
        className: 'disruption-pin',
        html: `<span>⚠️</span>`,
        iconSize: [28, 28],
        iconAnchor: [14, 14]
      })
    }).addTo(trackMap);

    mapLayers.disruption.bindPopup(`
      <div class="p-1 font-sans text-xs">
        <h4 class="font-bold text-rose-400 mb-0.5">⚠️ Road Disruption Detected</h4>
        <p class="text-slate-300">${order.disruptionTitle}</p>
        <span class="text-[10px] text-amber-300 font-mono">Bypassed by AI Route B</span>
      </div>
    `);
  }

  // 4. Draw Destination Pin
  if (order.destPos) {
    mapLayers.dest = L.marker(order.destPos, {
      icon: L.divIcon({
        className: 'destination-pin',
        html: `<span>📍</span>`,
        iconSize: [28, 28],
        iconAnchor: [14, 14]
      })
    }).addTo(trackMap);

    mapLayers.dest.bindPopup(`
      <div class="p-1 font-sans text-xs">
        <strong class="text-emerald-400">🎯 Delivery Destination</strong>
        <p class="text-slate-300">${order.destination}</p>
      </div>
    `);
  }

  // 5. Draw Vehicle Marker
  if (order.vehiclePos) {
    mapLayers.vehicle = L.marker(order.vehiclePos, {
      icon: L.divIcon({
        className: 'vehicle-pin',
        html: `<span>🚚</span>`,
        iconSize: [32, 32],
        iconAnchor: [16, 16]
      })
    }).addTo(trackMap);

    mapLayers.vehicle.bindPopup(`
      <div class="p-1 font-sans text-xs">
        <h4 class="font-bold text-blue-400 mb-0.5">🚚 Vehicle ${order.vehicle}</h4>
        <p class="text-slate-300"><strong>Driver:</strong> ${order.partner}</p>
        <p class="text-slate-300"><strong>Status:</strong> ${order.status}</p>
        <p class="text-slate-300 font-mono"><strong>Speed:</strong> 58 km/h</p>
      </div>
    `);
  }

  // Fit Bounds
  if (order.vehiclePos && order.destPos) {
    const bounds = L.latLngBounds([order.vehiclePos, order.destPos]);
    if (order.disruptionPos) bounds.extend(order.disruptionPos);
    trackMap.fitBounds(bounds, { padding: [50, 50] });
  }
}

// Recenter Map
function recenterMap() {
  if (trackMap && currentOrderData && currentOrderData.vehiclePos) {
    trackMap.setView(currentOrderData.vehiclePos, 10);
  }
}

// Text-to-Speech AI Update
function readAIUpdateAloud() {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    const cleanText = "LogiGuard AI Assistant update: " + currentOrderData.aiInsight.replace(/<[^>]*>/g, '');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.pitch = 1.05;
    window.speechSynthesis.speak(utterance);
  } else {
    alert("Voice synthesis is not supported on this browser.");
  }
}

// Notification Preferences Modal
function openNotificationModal() {
  const modal = document.getElementById('notification-modal');
  if (modal) modal.classList.remove('hidden');
}

function closeNotificationModal() {
  const modal = document.getElementById('notification-modal');
  if (modal) modal.classList.add('hidden');
}

function saveNotificationPreferences() {
  closeNotificationModal();
  if (window.confetti) {
    confetti({
      particleCount: 40,
      spread: 40,
      origin: { y: 0.6 }
    });
  }
  alert("🔔 Delivery alert preferences saved! You will receive live WhatsApp & SMS updates.");
}

// Support Drawer
function openSupportDrawer() {
  const drawer = document.getElementById('support-drawer');
  if (drawer) {
    drawer.classList.remove('hidden');
    drawer.classList.add('flex');
  }
}

function closeSupportDrawer() {
  const drawer = document.getElementById('support-drawer');
  if (drawer) {
    drawer.classList.add('hidden');
    drawer.classList.remove('flex');
  }
}

function sendQuickSupportMessage(msg) {
  const chatBox = document.getElementById('support-chat-history');
  if (!chatBox) return;

  chatBox.innerHTML += `
    <div class="bg-blue-600 p-2.5 rounded-xl text-white font-medium text-right">
      ${msg}
    </div>
  `;
  chatBox.scrollTop = chatBox.scrollHeight;

  setTimeout(() => {
    chatBox.innerHTML += `
      <div class="bg-blue-950/40 border border-blue-900/40 p-2.5 rounded-xl text-slate-200">
        👨‍✈️ <strong>Partner Ramesh:</strong> Received! I've noted your delivery preference: "${msg}". I'll arrive safely at around 4:30 PM.
      </div>
    `;
    chatBox.scrollTop = chatBox.scrollHeight;
  }, 600);
}

function handleSupportMessageSubmit(e) {
  e.preventDefault();
  const input = document.getElementById('support-input');
  if (!input || !input.value.trim()) return;

  const msg = input.value.trim();
  input.value = '';
  sendQuickSupportMessage(msg);
}

function openInstructionsModal() {
  const note = prompt("Enter specific delivery note (e.g., Gate Code, Flat Landmark):", "Leave at front door");
  if (note) {
    alert(`✅ Delivery instruction saved: "${note}". Synced with driver handheld.`);
  }
}
