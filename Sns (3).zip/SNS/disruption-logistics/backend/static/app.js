// LogiPulse Platform Client-Side Application Logic

// App State
let state = {
  currentView: 'landing', // 'landing' | 'dashboard'
  fleetData: {
    vehicles: [],
    deliveries: [],
    graph: null,
    active_disruptions: [],
    current_impact: null,
    current_plan: null,
    audit_log: [],
    stats: {}
  },
  scenarios: [],
  map: null,
  mapLayers: {
    edges: [],
    vehicles: [],
    disruptions: [],
    routes: [],
    reroutes: [],
    nodes: []
  },
  selectedVehicleId: null,
  selectedDeliveryFilter: 'all',
  searchQuery: ''
};

// Initialize Application
document.addEventListener('DOMContentLoaded', async () => {
  lucide.createIcons();
  startLiveClock();
  await loadScenarios();
  await fetchFleetData();
});

// Switch Views
function switchView(viewName) {
  state.currentView = viewName;
  const viewLanding = document.getElementById('view-landing');
  const viewDashboard = document.getElementById('view-dashboard');
  const headerTelemetry = document.getElementById('header-telemetry');
  const navBtnLanding = document.getElementById('nav-btn-landing');
  const navBtnConsole = document.getElementById('nav-btn-console');

  if (viewName === 'dashboard') {
    viewLanding.classList.add('hidden');
    viewLanding.classList.remove('block');
    viewDashboard.classList.remove('hidden');
    viewDashboard.classList.add('block');
    headerTelemetry.classList.remove('hidden');
    
    navBtnConsole.classList.add('ring-2', 'ring-indigo-400');
    navBtnLanding.classList.remove('ring-2', 'ring-indigo-400');

    // Initialize or resize map
    setTimeout(() => {
      if (!state.map) {
        initMap();
      } else {
        state.map.invalidateSize();
      }
      renderMap();
    }, 100);

  } else {
    viewLanding.classList.remove('hidden');
    viewLanding.classList.add('block');
    viewDashboard.classList.add('hidden');
    viewDashboard.classList.remove('block');
    headerTelemetry.classList.add('hidden');

    navBtnLanding.classList.add('ring-2', 'ring-indigo-400');
    navBtnConsole.classList.remove('ring-2', 'ring-indigo-400');
  }

  lucide.createIcons();
}

// Audience Tab Switcher
function switchAudienceTab(tabId) {
  const tabs = ['operators', 'delivery', 'transport'];
  tabs.forEach(t => {
    const btn = document.getElementById(`tab-${t}`);
    const content = document.getElementById(`content-${t}`);
    if (t === tabId) {
      btn.className = "flex-1 py-2.5 px-4 rounded-lg text-xs font-bold transition bg-indigo-600 text-white shadow";
      content.classList.remove('hidden');
      content.classList.add('block');
    } else {
      btn.className = "flex-1 py-2.5 px-4 rounded-lg text-xs font-bold transition text-slate-400 hover:text-white";
      content.classList.add('hidden');
      content.classList.remove('block');
    }
  });
  lucide.createIcons();
}

// Start Live Clock
function startLiveClock() {
  const clockEl = document.getElementById('live-dispatch-clock');
  setInterval(() => {
    const now = new Date();
    clockEl.innerText = now.toLocaleTimeString('en-US', { hour12: true, hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }, 1000);
}

// Fetch Fleet Data from Backend API
async function fetchFleetData() {
  try {
    const res = await fetch('/api/fleet');
    if (!res.ok) throw new Error("API Offline");
    const data = await res.json();
    state.fleetData = data;
    updateUI();
  } catch (err) {
    console.warn("Backend API not reachable, loading fallback data", err);
  }
}

// Fetch Scenarios
async function loadScenarios() {
  try {
    const res = await fetch('/api/scenarios');
    if (res.ok) {
      state.scenarios = await res.json();
      populateCustomModalDropdowns();
    }
  } catch (err) {
    console.warn("Failed to load scenarios", err);
  }
}

// Populate Custom Builder Node Dropdowns
function populateCustomModalDropdowns() {
  if (!state.fleetData.graph) return;
  const fromSel = document.getElementById('custom-from-node');
  const toSel = document.getElementById('custom-to-node');
  if (!fromSel || !toSel) return;

  fromSel.innerHTML = '';
  toSel.innerHTML = '';

  state.fleetData.graph.nodes.forEach(node => {
    fromSel.innerHTML += `<option value="${node.id}">${node.name} (ID ${node.id})</option>`;
    toSel.innerHTML += `<option value="${node.id}">${node.name} (ID ${node.id})</option>`;
  });
  toSel.selectedIndex = 1;
}

// Update Entire UI State
function updateUI() {
  renderTelemetryStats();
  renderDisruptionsPanel();
  renderImpactPanel();
  renderDecisionPanel();
  renderDAG();
  renderDeliveryTable();
  renderAuditTrail();
  if (state.map) {
    renderMap();
  }
  lucide.createIcons();
}

// Render Top Telemetry Badges
function renderTelemetryStats() {
  const stats = state.fleetData.stats || {};
  const activeFleetEl = document.getElementById('stat-active-fleet');
  const disCountEl = document.getElementById('stat-disruption-count');
  const disBadgeEl = document.getElementById('stat-disruption-badge');
  const ontimeEl = document.getElementById('stat-ontime-rate');

  if (activeFleetEl) activeFleetEl.innerText = `${stats.active_vehicles || 20} Active`;
  if (ontimeEl) ontimeEl.innerText = `${stats.on_time_rate || 98.6}%`;

  const dCount = state.fleetData.active_disruptions.length;
  if (disCountEl && disBadgeEl) {
    if (dCount > 0) {
      disCountEl.innerText = `${dCount} Critical`;
      disCountEl.className = "font-bold text-rose-400";
      disBadgeEl.className = "flex items-center gap-2 px-3 py-1.5 rounded-lg bg-rose-950/60 border border-rose-800 text-rose-300 animate-pulse";
    } else {
      disCountEl.innerText = "0 Active";
      disCountEl.className = "font-bold text-emerald-400";
      disBadgeEl.className = "flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900/80 border border-slate-800 text-slate-300";
    }
  }
}

// Initialize Leaflet Map
function initMap() {
  const mapContainer = document.getElementById('map');
  if (!mapContainer) return;

  // Coimbatore Coordinates
  const coimbatoreCenter = [11.0183, 76.9644];
  
  state.map = L.map('map', {
    center: coimbatoreCenter,
    zoom: 12.5,
    zoomControl: true,
    scrollWheelZoom: true
  });

  // OpenStreetMap Tile Layer
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors &bull; LogiPulse',
    maxZoom: 18,
  }).addTo(state.map);

  populateCustomModalDropdowns();
  renderMap();
}

// Render Map Elements (Roads, Nodes, Vehicles, Disrupted Zones, AI Reroutes)
function renderMap() {
  if (!state.map || !state.fleetData.graph) return;

  // Clear previous layers
  Object.values(state.mapLayers).forEach(layerGroup => {
    layerGroup.forEach(layer => state.map.removeLayer(layer));
  });
  state.mapLayers = { edges: [], vehicles: [], disruptions: [], routes: [], reroutes: [], nodes: [] };

  const graph = state.fleetData.graph;
  const getNodePos = (id) => {
    const node = graph.nodes.find(n => n.id === id);
    return node ? [node.lat, node.lon] : [11.0183, 76.9644];
  };

  const activeDisruption = state.fleetData.active_disruptions[0];
  const blockedEdges = activeDisruption ? activeDisruption.affected_edges : [];

  // 1. Draw Road Graph Edges
  graph.edges.forEach((edge, idx) => {
    const isBlocked = blockedEdges.some(be => 
      (be[0] === edge.u && be[1] === edge.v) || (be[0] === edge.v && be[1] === edge.u)
    );

    const poly = L.polyline([getNodePos(edge.u), getNodePos(edge.v)], {
      color: isBlocked ? '#f43f5e' : '#334155',
      weight: isBlocked ? 6 : 2.5,
      opacity: isBlocked ? 0.9 : 0.4,
      dashArray: isBlocked ? '8, 8' : null
    }).addTo(state.map);

    if (isBlocked) {
      poly.bindPopup(`<div class="text-xs font-sans text-rose-400 font-bold">⛔ Blocked Road Segment (Edge ${edge.u} ↔ ${edge.v})</div>`);
    }

    state.mapLayers.edges.push(poly);
  });

  // 2. Draw Key Logistics Hub Nodes (Subset of prominent nodes)
  const keyNodeIds = [0, 1, 2, 3, 4, 5, 8, 12, 13, 14, 15, 16, 17, 18, 20, 21, 25, 27, 30, 32, 38];
  graph.nodes.filter(n => keyNodeIds.includes(n.id)).forEach(node => {
    const circle = L.circleMarker([node.lat, node.lon], {
      radius: 4.5,
      fillColor: '#818cf8',
      color: '#ffffff',
      weight: 1.5,
      fillOpacity: 0.9
    }).addTo(state.map);

    circle.bindTooltip(`<strong>${node.name}</strong> (Node ${node.id})`, {
      permanent: false,
      direction: 'top',
      className: 'node-label-icon'
    });

    state.mapLayers.nodes.push(circle);
  });

  // 3. Draw Scheduled Vehicle Routes (Blue)
  state.fleetData.vehicles.forEach(v => {
    if (!v.route || v.route.length === 0) return;
    const pathCoords = [getNodePos(v.location), ...v.route.map(nId => getNodePos(nId))];

    const isAffected = activeDisruption && state.fleetData.current_impact?.affected_vehicles?.some(av => av.vehicle_id === v.id);

    const routeLine = L.polyline(pathCoords, {
      color: isAffected ? '#f59e0b' : '#38bdf8',
      weight: isAffected ? 3.5 : 2,
      opacity: 0.65,
      dashArray: isAffected ? '6, 6' : null
    }).addTo(state.map);

    state.mapLayers.routes.push(routeLine);
  });

  // 4. Draw AI Recommended Bypass Reroutes (Emerald Green)
  if (state.fleetData.current_plan && state.fleetData.current_plan.assignments) {
    state.fleetData.current_plan.assignments.forEach(assign => {
      if (assign.new_route && assign.new_route.length > 1) {
        const rerouteCoords = assign.new_route.map(nId => getNodePos(nId));
        const greenLine = L.polyline(rerouteCoords, {
          color: '#10b981',
          weight: 5,
          opacity: 0.95,
          dashArray: '8, 8'
        }).addTo(state.map);

        greenLine.bindPopup(`
          <div class="text-xs font-sans">
            <span class="font-bold text-emerald-400">✨ AI Recommended Bypass Path</span>
            <p class="text-slate-300">Fleet ${assign.vehicle_id} rerouted via arterial corridors</p>
          </div>
        `);

        state.mapLayers.reroutes.push(greenLine);
      }
    });
  }

  // 5. Draw Disruption Marker & Danger Radius Zone
  if (activeDisruption) {
    const focusNodeId = activeDisruption.affected_node || (activeDisruption.affected_edges[0] ? activeDisruption.affected_edges[0][0] : 0);
    const focusPos = getNodePos(focusNodeId);

    const dangerCircle = L.circle(focusPos, {
      radius: 900,
      fillColor: '#f43f5e',
      fillOpacity: 0.25,
      color: '#f43f5e',
      weight: 2
    }).addTo(state.map);

    const incidentMarker = L.marker(focusPos, {
      icon: L.divIcon({
        className: 'pulse-disruption-glow',
        html: `<div style="background:#f43f5e; color:white; width:30px; height:30px; border-radius:50%; display:flex; align-items:center; justify-content:center; border:2px solid white; font-weight:bold; font-size:14px;">⚠️</div>`,
        iconSize: [30, 30],
        iconAnchor: [15, 15]
      })
    }).addTo(state.map);

    incidentMarker.bindPopup(`
      <div class="p-1 font-sans text-xs">
        <h4 class="font-bold text-rose-400 text-sm mb-1">${activeDisruption.title}</h4>
        <p class="text-slate-300 mb-1">${activeDisruption.description || 'Active Blockade'}</p>
        <span class="text-[10px] bg-rose-500/20 text-rose-300 px-2 py-0.5 rounded font-mono">SEVERITY: CRITICAL</span>
      </div>
    `);

    state.mapLayers.disruptions.push(dangerCircle, incidentMarker);
  }

  // 6. Draw Vehicle Markers
  state.fleetData.vehicles.forEach(v => {
    const pos = getNodePos(v.location);
    const isAffected = activeDisruption && state.fleetData.current_impact?.affected_vehicles?.some(av => av.vehicle_id === v.id);
    const isRerouted = v.status && v.status.includes('rerouted');

    let markerClass = 'vehicle-marker-icon';
    if (isAffected) markerClass += ' vehicle-marker-disrupted';
    if (isRerouted) markerClass += ' vehicle-marker-rerouted';

    const vMarker = L.marker(pos, {
      icon: L.divIcon({
        className: markerClass,
        html: `<span>${v.id}</span>`,
        iconSize: [26, 26],
        iconAnchor: [13, 13]
      })
    }).addTo(state.map);

    // Get vehicle deliveries
    const vDeliveries = state.fleetData.deliveries.filter(d => d.vehicle_id === v.id);
    const urgentCount = vDeliveries.filter(d => d.priority === 'urgent').length;

    vMarker.bindPopup(`
      <div class="font-sans text-xs p-1">
        <div class="flex items-center justify-between gap-2 border-b border-slate-700 pb-1.5 mb-1.5">
          <h4 class="font-bold text-sm text-indigo-400">Fleet ${v.id}</h4>
          <span class="text-[10px] px-2 py-0.5 rounded font-mono ${isAffected ? 'bg-rose-500/20 text-rose-300' : 'bg-emerald-500/20 text-emerald-300'}">${v.status || 'Active'}</span>
        </div>
        <p class="text-slate-300"><strong>Current Hub:</strong> ${graph.nodes.find(n => n.id === v.location)?.name || v.location}</p>
        <p class="text-slate-300"><strong>Payload:</strong> ${vDeliveries.length} packages (${urgentCount} Urgent)</p>
        <p class="text-slate-300"><strong>Capacity:</strong> ${v.capacity} units</p>
        <p class="text-slate-300"><strong>Route Waypoints:</strong> ${v.route.join(' → ')}</p>
      </div>
    `);

    state.mapLayers.vehicles.push(vMarker);
  });
}

// Render Disruption Panel (Module A: "What Changed?")
function renderDisruptionsPanel() {
  const container = document.getElementById('disruption-card-container');
  const countBadge = document.getElementById('badge-incident-count');
  if (!container) return;

  const disruptions = state.fleetData.active_disruptions;
  if (countBadge) countBadge.innerText = `${disruptions.length} Active`;

  if (disruptions.length === 0) {
    container.innerHTML = `
      <div class="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 text-center py-6 text-xs text-slate-500">
        <i data-lucide="check-circle" class="w-6 h-6 mx-auto text-emerald-400/70 mb-2"></i>
        <span>No active disruptions. Select a scenario above to simulate.</span>
      </div>
    `;
    return;
  }

  container.innerHTML = disruptions.map(d => `
    <div class="p-4 rounded-xl bg-rose-950/30 border border-rose-500/40 relative shadow-lg animate-in fade-in">
      <div class="flex items-start justify-between gap-2 mb-2">
        <div class="flex items-center gap-2">
          <span class="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping"></span>
          <h4 class="font-bold text-sm text-rose-200">${d.title}</h4>
        </div>
        <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30 font-bold">${d.severity || 'CRITICAL'}</span>
      </div>
      <p class="text-xs text-slate-300 mb-3 leading-relaxed">${d.description || 'Arterial road blockade detected.'}</p>
      <div class="grid grid-cols-2 gap-2 text-[11px] text-slate-400 font-mono bg-slate-950/70 p-2 rounded-lg border border-slate-800">
        <div><strong class="text-slate-300">Category:</strong> ${(d.type || 'road_closure').replace('_', ' ').toUpperCase()}</div>
        <div><strong class="text-slate-300">Time:</strong> ${d.timestamp || 'Just Now'}</div>
        <div class="col-span-2"><strong class="text-slate-300">Location:</strong> ${d.location_name || 'Peelamedu Corridor'}</div>
      </div>
    </div>
  `).join('');
}

// Render Impact Panel (Module B: "What is Affected?")
function renderImpactPanel() {
  const panel = document.getElementById('impact-panel');
  if (!panel) return;

  const impact = state.fleetData.current_impact;
  if (!impact || state.fleetData.active_disruptions.length === 0) {
    panel.classList.add('hidden');
    return;
  }

  panel.classList.remove('hidden');

  const slaRiskEl = document.getElementById('impact-sla-risk');
  const delayTimeEl = document.getElementById('impact-delay-time');
  const delayedFleetsEl = document.getElementById('impact-delayed-fleets');
  const atRiskParcelsEl = document.getElementById('impact-at-risk-parcels');
  const downstreamListEl = document.getElementById('impact-downstream-list');

  if (slaRiskEl) slaRiskEl.innerText = `${impact.sla_breach_risk_percent}%`;
  if (delayTimeEl) delayTimeEl.innerText = `+${impact.total_delay_minutes} mins`;
  if (delayedFleetsEl) delayedFleetsEl.innerText = `${impact.affected_vehicles_count} Vehicle(s) Delayed`;
  if (atRiskParcelsEl) atRiskParcelsEl.innerText = `${impact.affected_deliveries_count} Parcels at Risk`;

  if (downstreamListEl && impact.affected_vehicles) {
    const downstreamItems = [];
    impact.affected_vehicles.forEach(av => {
      (av.downstream_effects || []).forEach(effect => {
        downstreamItems.push(`<div class="flex items-center gap-1.5 text-rose-300"><i data-lucide="alert-triangle" class="w-3 h-3 text-rose-400 shrink-0"></i><span>${effect}</span></div>`);
      });
    });

    if (downstreamItems.length === 0) {
      downstreamItems.push(`<div class="text-slate-400">Minor detour penalty without cross-dock disruption.</div>`);
    }

    downstreamListEl.innerHTML = downstreamItems.join('');
  }
}

// Render Decision Panel (Module C: "What Should They Do Next?")
function renderDecisionPanel() {
  const panel = document.getElementById('decision-panel');
  const container = document.getElementById('decision-cards-container');
  if (!panel || !container) return;

  const plan = state.fleetData.current_plan;
  if (!plan || !plan.options || state.fleetData.active_disruptions.length === 0) {
    panel.classList.add('hidden');
    return;
  }

  panel.classList.remove('hidden');

  container.innerHTML = plan.options.map((opt, idx) => {
    const isRec = opt.badge === 'RECOMMENDED';
    const cardBorderClass = isRec ? 'recommended-card bg-emerald-950/20' : 'bg-slate-950 border border-slate-800';

    return `
      <div class="p-4 rounded-2xl ${cardBorderClass} space-y-3 transition hover:scale-[1.01]">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <span class="text-xs font-bold text-slate-400">Option ${idx + 1}</span>
            <h4 class="font-bold text-sm text-white">${opt.title}</h4>
          </div>
          <span class="text-[10px] font-bold px-2 py-0.5 rounded-full ${isRec ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'}">${opt.badge}</span>
        </div>

        <p class="text-xs text-slate-300 leading-relaxed">${opt.description}</p>

        <!-- Metric Badges -->
        <div class="grid grid-cols-2 gap-2 text-[11px] font-mono p-2.5 rounded-xl bg-slate-900/90 border border-slate-800/80">
          <div><span class="text-slate-400">Time Saved:</span> <strong class="text-emerald-400">${opt.metrics.time_saved}</strong></div>
          <div><span class="text-slate-400">SLA Recovery:</span> <strong class="text-cyan-400">${opt.metrics.sla_recovery}</strong></div>
        </div>

        <!-- Action Button -->
        <button onclick="applyDecisionOption('${opt.id}')" class="w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition ${isRec ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/30' : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30'}">
          <i data-lucide="send" class="w-3.5 h-3.5"></i>
          <span>Apply & Sync to Driver Handheld</span>
        </button>
      </div>
    `;
  }).join('');
}

// Render Interactive Visual Dependency DAG (Graph)
function renderDAG() {
  const emptyState = document.getElementById('dag-empty-state');
  const graphContainer = document.getElementById('dag-interactive-graph');
  const pill = document.getElementById('dag-status-pill');
  if (!emptyState || !graphContainer) return;

  const impact = state.fleetData.current_impact;
  if (!impact || !impact.dag || state.fleetData.active_disruptions.length === 0) {
    emptyState.classList.remove('hidden');
    graphContainer.classList.add('hidden');
    if (pill) {
      pill.innerText = "Nominal Flow";
      pill.className = "text-xs px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 font-mono";
    }
    return;
  }

  emptyState.classList.add('hidden');
  graphContainer.classList.remove('hidden');
  if (pill) {
    pill.innerText = "Cascade Flow Active";
    pill.className = "text-xs px-2.5 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 font-mono font-bold animate-pulse";
  }

  const nodes = impact.dag.nodes || [];

  // Group nodes into stages: Disruption -> Vehicle -> Delivery -> Downstream
  const disruptionNodes = nodes.filter(n => n.type === 'disruption');
  const vehicleNodes = nodes.filter(n => n.type === 'vehicle');
  const deliveryNodes = nodes.filter(n => n.type === 'delivery');
  const downstreamNodes = nodes.filter(n => n.type === 'downstream');

  graphContainer.innerHTML = `
    <div class="flex items-center justify-between gap-3 overflow-x-auto py-2">
      
      <!-- Stage 1: Root Disruption -->
      <div class="flex-1 min-w-[160px] space-y-2 text-center">
        <span class="text-[10px] font-bold text-rose-400 uppercase tracking-wider block">1. Root Event</span>
        ${disruptionNodes.map(n => `
          <div class="p-2.5 rounded-xl bg-rose-950/50 border border-rose-500/50 text-xs shadow-md">
            <div class="font-bold text-rose-200">${n.label}</div>
            <div class="text-[10px] text-rose-300/80 font-mono mt-0.5">${n.details}</div>
          </div>
        `).join('')}
      </div>

      <div class="text-slate-600 font-bold">➔</div>

      <!-- Stage 2: Delayed Vehicle -->
      <div class="flex-1 min-w-[160px] space-y-2 text-center">
        <span class="text-[10px] font-bold text-amber-400 uppercase tracking-wider block">2. Fleet Impact</span>
        ${vehicleNodes.map(n => `
          <div class="p-2.5 rounded-xl bg-amber-950/40 border border-amber-500/40 text-xs shadow-md">
            <div class="font-bold text-amber-200">${n.label}</div>
            <div class="text-[10px] text-amber-300/80 font-mono mt-0.5">${n.details}</div>
          </div>
        `).join('')}
      </div>

      <div class="text-slate-600 font-bold">➔</div>

      <!-- Stage 3: Affected Deliveries -->
      <div class="flex-1 min-w-[160px] space-y-2 text-center">
        <span class="text-[10px] font-bold text-indigo-400 uppercase tracking-wider block">3. Cargo Risk</span>
        ${deliveryNodes.slice(0, 2).map(n => `
          <div class="p-2.5 rounded-xl bg-indigo-950/40 border border-indigo-500/40 text-xs shadow-md">
            <div class="font-bold text-indigo-200">${n.label}</div>
            <div class="text-[10px] text-indigo-300/80 font-mono mt-0.5">${n.details}</div>
          </div>
        `).join('')}
      </div>

      <div class="text-slate-600 font-bold">➔</div>

      <!-- Stage 4: Downstream SLA & Shifts -->
      <div class="flex-1 min-w-[180px] space-y-2 text-center">
        <span class="text-[10px] font-bold text-rose-400 uppercase tracking-wider block">4. Downstream SLA</span>
        ${downstreamNodes.map(n => `
          <div class="p-2.5 rounded-xl bg-rose-950/40 border border-rose-500/40 text-xs shadow-md">
            <div class="font-bold text-rose-200">${n.label}</div>
            <div class="text-[10px] text-rose-300/80 font-mono mt-0.5">${n.details}</div>
          </div>
        `).join('')}
      </div>

    </div>
  `;
}

// Render Deliveries Table
function renderDeliveryTable() {
  const tbody = document.getElementById('delivery-table-body');
  if (!tbody || !state.fleetData.deliveries) return;

  const graph = state.fleetData.graph;
  const getNodeName = (id) => graph?.nodes?.find(n => n.id === id)?.name || `Node ${id}`;

  const filtered = state.fleetData.deliveries.filter(d => {
    const matchesPriority = state.selectedDeliveryFilter === 'all' || d.priority === state.selectedDeliveryFilter;
    const matchesSearch = state.searchQuery === '' || 
      d.id.toLowerCase().includes(state.searchQuery.toLowerCase()) || 
      d.vehicle_id.toLowerCase().includes(state.searchQuery.toLowerCase()) ||
      getNodeName(d.destination).toLowerCase().includes(state.searchQuery.toLowerCase());
    return matchesPriority && matchesSearch;
  });

  tbody.innerHTML = filtered.map(d => {
    const isUrgent = d.priority === 'urgent';
    const isDisrupted = state.fleetData.current_impact?.affected_deliveries?.some(ad => ad.delivery_id === d.id);

    return `
      <tr class="hover:bg-slate-800/40 transition">
        <td class="p-3 font-bold text-indigo-300">${d.id}</td>
        <td class="p-3 text-slate-200">${d.vehicle_id}</td>
        <td class="p-3 text-slate-300 font-sans">${getNodeName(d.destination)}</td>
        <td class="p-3 text-slate-400">${d.time_window}</td>
        <td class="p-3">
          <span class="px-2 py-0.5 rounded text-[10px] font-bold ${isUrgent ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' : 'bg-slate-800 text-slate-400'}">
            ${d.priority.toUpperCase()}
          </span>
        </td>
        <td class="p-3">
          <span class="px-2 py-0.5 rounded text-[10px] font-bold ${isDisrupted ? 'bg-amber-500/20 text-amber-300 animate-pulse' : (d.status === 'delivered' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-300')}">
            ${isDisrupted ? 'AT RISK' : (d.status || 'In Transit').toUpperCase()}
          </span>
        </td>
      </tr>
    `;
  }).join('');
}

// Filter Deliveries
function filterDeliveryTable() {
  state.searchQuery = document.getElementById('delivery-search')?.value || '';
  state.selectedDeliveryFilter = document.getElementById('delivery-filter-priority')?.value || 'all';
  renderDeliveryTable();
}

// Render Audit Trail Logs
function renderAuditTrail() {
  const container = document.getElementById('audit-log-container');
  if (!container || !state.fleetData.audit_log) return;

  container.innerHTML = state.fleetData.audit_log.map(log => {
    let color = 'text-slate-400';
    if (log.level === 'CRITICAL') color = 'text-rose-400';
    if (log.level === 'SUCCESS') color = 'text-emerald-400';

    return `
      <div class="flex items-start gap-2 py-0.5">
        <span class="text-slate-500 shrink-0">[${log.timestamp}]</span>
        <span class="${color} font-medium">${log.event}</span>
      </div>
    `;
  }).join('');
}

// Trigger Scenario from Button
async function triggerQuickScenario(scenarioId) {
  const scn = state.scenarios.find(s => s.id === scenarioId);
  if (!scn) return;

  switchView('dashboard');

  try {
    const res = await fetch('/api/disruptions/trigger', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(scn)
    });
    if (res.ok) {
      await fetchFleetData();
    }
  } catch (err) {
    console.error("Failed to trigger disruption", err);
  }
}

// Custom Disruption Trigger Builder
function toggleCustomTriggerModal() {
  const panel = document.getElementById('custom-trigger-panel');
  if (panel) {
    panel.classList.toggle('hidden');
  }
}

async function triggerCustomDisruption() {
  const title = document.getElementById('custom-title').value;
  const fromNode = parseInt(document.getElementById('custom-from-node').value);
  const toNode = parseInt(document.getElementById('custom-to-node').value);
  const type = document.getElementById('custom-type').value;

  const payload = {
    id: `DSR-CUSTOM-${Date.now().toString().slice(-4)}`,
    title: title,
    type: type,
    severity: 'CRITICAL',
    affected_edges: [[fromNode, toNode]],
    affected_node: fromNode,
    description: `Manual dispatcher blockade between Node ${fromNode} and Node ${toNode}`
  };

  try {
    const res = await fetch('/api/disruptions/trigger', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (res.ok) {
      toggleCustomTriggerModal();
      await fetchFleetData();
    }
  } catch (err) {
    console.error("Failed custom trigger", err);
  }
}

// Apply Resolution Card
async function applyDecisionOption(optionId) {
  try {
    const res = await fetch('/api/plan/apply', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ option_id: optionId })
    });

    if (res.ok) {
      const data = await res.json();
      
      // Trigger Confetti effect
      if (window.confetti) {
        confetti({
          particleCount: 70,
          spread: 60,
          origin: { y: 0.7 }
        });
      }

      // Show Driver Handheld Modal
      showDriverModal(optionId, data.message);
      await fetchFleetData();
    }
  } catch (err) {
    console.error("Failed to apply solution", err);
  }
}

// Driver Sync Modal
function showDriverModal(optionId, msg) {
  const modal = document.getElementById('driver-sync-modal');
  const content = document.getElementById('driver-modal-content');
  if (!modal || !content) return;

  content.innerHTML = `
    <div class="space-y-2">
      <div class="p-2 rounded bg-indigo-950/60 border border-indigo-900/60 text-indigo-200">
        🔔 <strong>IN-CAB NAV UPDATE:</strong> New turn-by-turn routing payload received from LogiPulse Autonomous Dispatch Hub.
      </div>
      <p class="text-slate-300"><strong>Status:</strong> ${msg}</p>
      <p class="text-[11px] text-slate-400">Driver tablet updated with dynamic bypass coordinates. SLA protected.</p>
    </div>
  `;

  modal.classList.remove('hidden');
  lucide.createIcons();
}

function closeDriverModal() {
  const modal = document.getElementById('driver-sync-modal');
  if (modal) modal.classList.add('hidden');
}

// Reset System State
async function resetSystemState() {
  try {
    const res = await fetch('/api/reset', { method: 'POST' });
    if (res.ok) {
      await fetchFleetData();
    }
  } catch (err) {
    console.error("Reset failed", err);
  }
}

// Dispatcher AI Copilot Chat
async function handleCopilotSubmit(e) {
  e.preventDefault();
  const input = document.getElementById('copilot-input');
  if (!input || !input.value.trim()) return;

  const query = input.value.trim();
  input.value = '';
  await askCopilot(query);
}

async function askCopilot(query) {
  const chatBox = document.getElementById('copilot-chat-box');
  if (!chatBox) return;

  // Add User Message
  chatBox.innerHTML += `
    <div class="bg-slate-800/80 p-2 rounded-lg text-slate-200 font-medium text-right">
      ${query}
    </div>
  `;
  chatBox.scrollTop = chatBox.scrollHeight;

  try {
    const res = await fetch('/api/copilot', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: query })
    });

    if (res.ok) {
      const data = await res.json();
      chatBox.innerHTML += `
        <div class="bg-indigo-950/50 border border-indigo-900/50 p-2.5 rounded-lg text-slate-200 leading-relaxed">
          ${data.reply.replace(/\n/g, '<br>')}
        </div>
      `;
      chatBox.scrollTop = chatBox.scrollHeight;
    }
  } catch (err) {
    chatBox.innerHTML += `
      <div class="bg-rose-950/40 text-rose-300 p-2 rounded">
        Copilot service is temporarily unreachable.
      </div>
    `;
  }
  lucide.createIcons();
}
