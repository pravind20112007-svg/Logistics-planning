import json
import heapq
from typing import Dict, List, Tuple, Optional

class RoadGraph:
    def __init__(self, data_path: Optional[str] = None, data_dict: Optional[dict] = None):
        self.nodes: Dict[int, dict] = {}
        self.adj: Dict[int, List[Tuple[int, float]]] = {}
        
        if data_path:
            with open(data_path, 'r') as f:
                raw = json.load(f)
                self._load(raw)
        elif data_dict:
            self._load(data_dict)

    def _load(self, raw: dict):
        for n in raw.get("nodes", []):
            self.nodes[n["id"]] = n
            self.adj[n["id"]] = []
            
        for e in raw.get("edges", []):
            u, v, w = e["u"], e["v"], float(e["weight"])
            # Bidirectional network
            if u in self.adj and v in self.adj:
                self.adj[u].append((v, w))
                self.adj[v].append((u, w))

    def get_node(self, node_id: int) -> Optional[dict]:
        return self.nodes.get(node_id)

    def dijkstra_path(
        self,
        start: int,
        target: int,
        blocked_edges: Optional[List[Tuple[int, int]]] = None,
        blocked_nodes: Optional[List[int]] = None
    ) -> Tuple[List[int], float]:
        """
        Finds shortest path between start and target avoiding blocked edges and nodes.
        """
        if start == target:
            return [start], 0.0

        blocked_e_set = set()
        if blocked_edges:
            for u, v in blocked_edges:
                blocked_e_set.add((u, v))
                blocked_e_set.add((v, u))

        blocked_n_set = set(blocked_nodes or [])

        # Priority queue: (dist, current_node, path)
        pq = [(0.0, start, [start])]
        visited = {}

        while pq:
            cost, current, path = heapq.heappop(pq)

            if current in visited and visited[current] <= cost:
                continue
            visited[current] = cost

            if current == target:
                return path, round(cost, 2)

            for neighbor, weight in self.adj.get(current, []):
                if neighbor in blocked_n_set and neighbor != target:
                    continue
                if (current, neighbor) in blocked_e_set:
                    continue

                new_cost = cost + weight
                if neighbor not in visited or visited[neighbor] > new_cost:
                    heapq.heappush(pq, (new_cost, neighbor, path + [neighbor]))

        # If no path found without blocked edges, return direct fallback
        return [start, target], 999.0

    def compute_route(self, waypoints: List[int], blocked_edges: Optional[List[Tuple[int, int]]] = None) -> Tuple[List[int], float]:
        """
        Computes the complete continuous route path through a series of waypoints.
        """
        if not waypoints:
            return [], 0.0
        if len(waypoints) == 1:
            return waypoints, 0.0

        full_path = [waypoints[0]]
        total_dist = 0.0

        for i in range(len(waypoints) - 1):
            sub_path, sub_dist = self.dijkstra_path(waypoints[i], waypoints[i+1], blocked_edges)
            if len(sub_path) > 1:
                full_path.extend(sub_path[1:])
            total_dist += sub_dist

        return full_path, round(total_dist, 2)
