from typing import Dict, List, Tuple, Any
from .graph import RoadGraph

class ImpactAnalyzer:
    def __init__(self, graph: RoadGraph):
        self.graph = graph

    def evaluate_impact(
        self,
        disruption: dict,
        vehicles: List[dict],
        deliveries: List[dict]
    ) -> dict:
        """
        Evaluates the cascade impact of a disruption across the fleet, deliveries, and schedule.
        Answers: 'What is affected?'
        """
        disruption_id = disruption.get("id", "DSR-AUTO")
        disruption_type = disruption.get("type", "road_closure")
        affected_edges = disruption.get("affected_edges", [])
        affected_node = disruption.get("affected_node", None)
        title = disruption.get("title", "Active Logistics Disruption")

        blocked_pairs = set()
        for edge in affected_edges:
            if len(edge) == 2:
                blocked_pairs.add((edge[0], edge[1]))
                blocked_pairs.add((edge[1], edge[0]))

        affected_vehicles = []
        affected_deliveries = []
        sla_breach_count = 0
        total_delay_minutes = 0
        dag_nodes = []
        dag_links = []

        # Root Disruption DAG Node
        disruption_node_id = f"disruption_{disruption_id}"
        dag_nodes.append({
            "id": disruption_node_id,
            "label": title,
            "type": "disruption",
            "status": "critical",
            "details": f"Type: {disruption_type.replace('_', ' ').title()}"
        })

        # Check each vehicle
        for v in vehicles:
            v_id = v["id"]
            current_loc = v.get("location", 0)
            route = v.get("route", [])
            full_path = [current_loc] + route

            is_vehicle_affected = False
            bottleneck_reason = ""
            delay_added = 0

            # 1. Road closure check
            for i in range(len(full_path) - 1):
                pair = (full_path[i], full_path[i+1])
                if pair in blocked_pairs:
                    is_vehicle_affected = True
                    bottleneck_reason = f"Route intersects blocked segment ({self.graph.get_node(pair[0])['name']} ↔ {self.graph.get_node(pair[1])['name']})"
                    delay_added = 45 # default estimated detour delay
                    break

            # 2. Node/Location breakdown check
            if affected_node is not None and (affected_node in full_path or current_loc == affected_node):
                is_vehicle_affected = True
                bottleneck_reason = f"Blocked at/near {self.graph.get_node(affected_node)['name']}"
                delay_added = 60

            # 3. Specific vehicle breakdown
            if disruption_type == "vehicle_breakdown" and disruption.get("vehicle_id") == v_id:
                is_vehicle_affected = True
                bottleneck_reason = "Vehicle mechanical failure - immobilised"
                delay_added = 90

            if is_vehicle_affected:
                total_delay_minutes += delay_added
                v_node_id = f"vehicle_{v_id}"
                dag_nodes.append({
                    "id": v_node_id,
                    "label": f"Fleet {v_id}",
                    "type": "vehicle",
                    "status": "warning",
                    "details": f"Delay: +{delay_added}m | Loc: {self.graph.get_node(current_loc)['name'] if self.graph.get_node(current_loc) else current_loc}"
                })
                dag_links.append({
                    "source": disruption_node_id,
                    "target": v_node_id,
                    "relationship": "Blocks Route"
                })

                # Find associated deliveries
                v_deliveries = [d for d in deliveries if d.get("vehicle_id") == v_id and d.get("status") != "delivered"]
                v_deliv_details = []

                for d in v_deliveries:
                    d_id = d["id"]
                    is_urgent = d.get("priority") == "urgent"
                    sla_risk = "Critical Risk" if is_urgent else "Moderate Delay"
                    if is_urgent:
                        sla_breach_count += 1

                    dest_name = self.graph.get_node(d["destination"])["name"] if self.graph.get_node(d["destination"]) else f"Node {d['destination']}"
                    
                    deliv_info = {
                        "delivery_id": d_id,
                        "destination": dest_name,
                        "destination_id": d["destination"],
                        "priority": d.get("priority", "normal"),
                        "time_window": d.get("time_window", "N/A"),
                        "estimated_delay": f"+{delay_added} mins",
                        "sla_risk": sla_risk
                    }
                    v_deliv_details.append(deliv_info)
                    affected_deliveries.append(deliv_info)

                    # Delivery DAG node
                    d_node_id = f"deliv_{d_id}"
                    dag_nodes.append({
                        "id": d_node_id,
                        "label": f"Package {d_id} ({dest_name})",
                        "type": "delivery",
                        "status": "danger" if is_urgent else "warning",
                        "details": f"Window: {d.get('time_window')} | Priority: {d.get('priority')}"
                    })
                    dag_links.append({
                        "source": v_node_id,
                        "target": d_node_id,
                        "relationship": "Delayed Cargo"
                    })

                # Downstream impact (driver shift & warehouse cross-dock)
                downstream_impacts = []
                if delay_added >= 45:
                    ds_node_id = f"downstream_shift_{v_id}"
                    downstream_impacts.append(f"Driver shift threshold exceeded (Max 8h limit at risk)")
                    dag_nodes.append({
                        "id": ds_node_id,
                        "label": f"Shift Exceedance ({v_id})",
                        "type": "downstream",
                        "status": "danger",
                        "details": "Exceeds DOT maximum shift window"
                    })
                    dag_links.append({
                        "source": v_node_id,
                        "target": ds_node_id,
                        "relationship": "Breaches Max Hours"
                    })

                if any(d.get("destination") in [14, 15, 2] for d in v_deliveries):
                    ds_dock_id = f"downstream_dock_{v_id}"
                    downstream_impacts.append("Tidel Park & Airport Cross-Dock loading slot missed")
                    dag_nodes.append({
                        "id": ds_dock_id,
                        "label": "Airport/Tidel Dock Slot Miss",
                        "type": "downstream",
                        "status": "warning",
                        "details": "Downstream flight/hub handover miss"
                    })
                    dag_links.append({
                        "source": v_node_id,
                        "target": ds_dock_id,
                        "relationship": "Misses Dock Window"
                    })

                affected_vehicles.append({
                    "vehicle_id": v_id,
                    "location": current_loc,
                    "location_name": self.graph.get_node(current_loc)["name"] if self.graph.get_node(current_loc) else str(current_loc),
                    "delay_minutes": delay_added,
                    "reason": bottleneck_reason,
                    "affected_deliveries": v_deliv_details,
                    "downstream_effects": downstream_impacts
                })

        # Calculate high-level impact metrics
        sla_breach_probability = min(98, max(25, sla_breach_count * 35 + len(affected_vehicles) * 15)) if affected_vehicles else 0
        carbon_penalty_kg = round(len(affected_vehicles) * 12.4 + total_delay_minutes * 0.15, 1)

        return {
            "disruption_id": disruption_id,
            "title": title,
            "type": disruption_type,
            "severity": "CRITICAL" if sla_breach_count > 0 or len(affected_vehicles) > 1 else "HIGH",
            "affected_vehicles_count": len(affected_vehicles),
            "affected_deliveries_count": len(affected_deliveries),
            "sla_breach_risk_percent": sla_breach_probability,
            "total_delay_minutes": total_delay_minutes,
            "carbon_penalty_kg": carbon_penalty_kg,
            "affected_vehicles": affected_vehicles,
            "affected_deliveries": affected_deliveries,
            "summary": f"{len(affected_vehicles)} active vehicles delayed with {len(affected_deliveries)} shipments at risk of SLA breach.",
            "dag": {
                "nodes": dag_nodes,
                "links": dag_links
            }
        }
