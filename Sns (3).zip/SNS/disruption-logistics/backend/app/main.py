import os
import sys
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional

from .state.store import LogisticsStateStore

# Paths
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
STATIC_DIR = os.path.join(BASE_DIR, "static")
FRONTEND_DIST = os.path.join(os.path.dirname(BASE_DIR), "frontend", "dist")

store = LogisticsStateStore(DATA_DIR)

app = FastAPI(
    title="LogiPulse Disruption-Aware Logistics API",
    description="Real-Time Disruption Identification, Cascade Impact Analysis, and Autonomous AI Decision Hub",
    version="2.0.0"
)

# Enable CORS for development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class DisruptionTriggerRequest(BaseModel):
    id: Optional[str] = None
    title: Optional[str] = "Manual Dispatcher Disruption"
    type: str = "road_closure"
    severity: Optional[str] = "HIGH"
    location_name: Optional[str] = None
    affected_edges: List[List[int]] = []
    affected_node: Optional[int] = None
    vehicle_id: Optional[str] = None
    description: Optional[str] = ""

class ApplyPlanRequest(BaseModel):
    option_id: str

class CopilotQueryRequest(BaseModel):
    query: str

@app.get("/api/health")
def health_check():
    return {"status": "healthy", "service": "LogiPulse Core Engine", "version": "2.0.0"}

@app.get("/api/fleet")
def get_fleet():
    """Returns complete operational status: vehicles, deliveries, graph, disruptions, impact & decisions."""
    return store.get_fleet_data()

@app.get("/api/scenarios")
def get_scenarios():
    """Returns curated simulation disruption scenarios."""
    return store.get_preset_scenarios()

@app.post("/api/disruptions/trigger")
def trigger_disruption(req: DisruptionTriggerRequest):
    """Triggers a disruption event and computes cascade impact & AI recommendations."""
    res = store.trigger_disruption(req.model_dump())
    return res

@app.post("/api/plan/apply")
def apply_plan(req: ApplyPlanRequest):
    """Applies a resolution card, updates fleet route state, and notifies drivers."""
    res = store.apply_solution(req.option_id)
    if res.get("status") == "error":
        raise HTTPException(status_code=400, detail=res.get("message"))
    return res

@app.post("/api/reset")
def reset_state():
    """Resets simulator to clean initial baseline."""
    store.reset_state()
    return {"status": "success", "message": "Fleet state reset to normal baseline", "fleet_data": store.get_fleet_data()}

@app.post("/api/copilot")
def query_copilot(req: CopilotQueryRequest):
    """Dispatcher AI Copilot answering natural language queries about active operations."""
    q = req.query.lower()
    stats = store.get_stats()
    impact = store.current_impact
    plan = store.current_plan
    disruptions = store.active_disruptions

    response_text = ""
    suggested_actions = []

    if "disruption" in q or "what changed" in q or "incident" in q or "alert" in q:
        if not disruptions:
            response_text = "All systems nominal! Currently no active road blockades or mechanical disruptions logged across Coimbatore network."
            suggested_actions = ["Trigger Avinashi Road Flood Demo", "Trigger Vehicle V1 Breakdown"]
        else:
            d = disruptions[0]
            response_text = f"🚨 **Active Disruption Identified:** {d.get('title')} ({d.get('type')}). Location: {d.get('location_name', 'Graph segment')}. Root cause: {d.get('description', 'Reported blockade')}."
            suggested_actions = ["Evaluate Cascade Impact", "View Recommended Re-Route"]

    elif "affected" in q or "impact" in q or "delay" in q or "risk" in q or "sla" in q:
        if not impact:
            response_text = "No cascade delays currently registered. Fleet on-time delivery rate is tracking at 98.6% with zero critical SLA breaches."
        else:
            response_text = f"⚠️ **Cascade Impact Breakdown:**\n- **Affected Fleets:** {impact.get('affected_vehicles_count')}\n- **At-Risk Shipments:** {impact.get('affected_deliveries_count')}\n- **Estimated Delay:** {impact.get('total_delay_minutes')} minutes\n- **SLA Breach Risk:** {impact.get('sla_breach_risk_percent')}%\n- **Downstream risks:** Driver shift time threshold exceeded & Airport transfer window missed."
            suggested_actions = ["Apply Dynamic Re-route", "Execute Fleet Intercept"]

    elif "recommend" in q or "what next" in q or "solution" in q or "action" in q or "reroute" in q:
        if not plan or not plan.get("options"):
            response_text = "No active intervention required. All fleet routes are currently running optimal shortest paths."
        else:
            opts = plan.get("options", [])
            opt_summaries = "\n".join([f"**{i+1}. {o['title']} ({o['badge']}):** {o['description']} (Saves: {o['metrics']['time_saved']})" for i, o in enumerate(opts)])
            response_text = f"💡 **AI Decision Engine Recommendations:**\n{opt_summaries}\n\n*Dispatcher Tip: Click 'Apply & Sync' on Option 1 to instantly push arterial bypass telemetry to the driver's handheld device.*"
            suggested_actions = [f"Apply {o['title']}" for o in opts]

    elif "vehicle" in q or "fleet" in q or "truck" in q:
        v_count = len(store.vehicles)
        response_text = f"🚛 **Fleet Status:** {v_count} active delivery vans tracked in real-time across Coimbatore sectors (Gandhipuram, Peelamedu, Tidel Park, Saravanampatti, RS Puram, Airport). Fleet health index is currently {stats['fleet_health']}%."
        suggested_actions = ["Filter Urgent Shipments", "View High-Risk Vehicles"]

    else:
        response_text = f"🤖 **LogiPulse Copilot Online:** Monitoring 20 active vehicles and 59 parcels across Coimbatore. You can ask me:\n- *'What disruptions are active?'*\n- *'What is the cascade SLA impact?'*\n- *'What should we do next?'*\n- *'Show fleet health statistics'*"
        suggested_actions = ["What changed?", "What is affected?", "What should we do next?"]

    return {
        "query": req.query,
        "reply": response_text,
        "suggested_actions": suggested_actions,
        "stats": stats
    }

# Order Tracking API
@app.get("/api/orders/{order_id}")
def get_order_tracking(order_id: str):
    """Returns real-time AI tracking telemetry for customer order."""
    order_id = order_id.upper()
    return {
        "order_id": order_id,
        "status": "Out for Delivery",
        "vehicle": "V-101",
        "partner": "Assigned (Ramesh Kumar - 4.9 Rating)",
        "current_location": "Salem (NH-544 Expressway)",
        "destination": "Coimbatore (Peelamedu)",
        "estimated_delivery": "Today, 4:30 PM",
        "has_disruption": True,
        "ai_insight": "Your order is currently on Route B. A traffic disruption was detected on the original route, so the system automatically selected an alternative route. Estimated delay: 10 minutes."
    }

# Check if static UI directory exists, if so serve it
if os.path.exists(STATIC_DIR):
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

    @app.get("/")
    def serve_index():
        index_file = os.path.join(STATIC_DIR, "index.html")
        if os.path.exists(index_file):
            return FileResponse(index_file)
        return {"message": "LogiGuard / LogiPulse API is running. UI static file not found."}

    @app.get("/track")
    def serve_track():
        track_file = os.path.join(STATIC_DIR, "track.html")
        if os.path.exists(track_file):
            return FileResponse(track_file)
        return {"message": "track.html not found"}

    @app.get("/{full_path:path}")
    def serve_spa(full_path: str):
        file_path = os.path.join(STATIC_DIR, full_path)
        if os.path.exists(file_path) and os.path.isfile(file_path):
            return FileResponse(file_path)
        if full_path in ["track", "track.html"]:
            track_file = os.path.join(STATIC_DIR, "track.html")
            if os.path.exists(track_file):
                return FileResponse(track_file)
        index_file = os.path.join(STATIC_DIR, "index.html")
        if os.path.exists(index_file):
            return FileResponse(index_file)
        return JSONResponse(status_code=404, content={"message": "Not found"})

