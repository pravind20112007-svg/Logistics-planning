import json
import os
import copy
from typing import List, Dict, Any, Optional
from datetime import datetime
from ..core.graph import RoadGraph
from ..core.impact import ImpactAnalyzer
from ..core.solver import DecisionEngine

class LogisticsStateStore:
    def __init__(self, data_dir: str):
        self.data_dir = data_dir
        self.graph_file = os.path.join(data_dir, "road_graph.json")
        self.vehicles_file = os.path.join(data_dir, "vehicles.json")
        self.deliveries_file = os.path.join(data_dir, "deliveries.json")

        self.graph: RoadGraph = RoadGraph(data_path=self.graph_file)
        self.impact_analyzer = ImpactAnalyzer(self.graph)
        self.decision_engine = DecisionEngine(self.graph)

        self._initial_vehicles: List[dict] = []
        self._initial_deliveries: List[dict] = []
        self._initial_graph_data: dict = {}

        self.vehicles: List[dict] = []
        self.deliveries: List[dict] = []
        self.active_disruptions: List[dict] = []
        self.current_impact: Optional[dict] = None
        self.current_plan: Optional[dict] = None
        self.applied_plans_history: List[dict] = []
        self.audit_log: List[dict] = []

        self.load_data()

    def load_data(self):
        with open(self.vehicles_file, 'r') as f:
            self._initial_vehicles = json.load(f)
        with open(self.deliveries_file, 'r') as f:
            self._initial_deliveries = json.load(f)
        with open(self.graph_file, 'r') as f:
            self._initial_graph_data = json.load(f)

        self.reset_state()

    def reset_state(self):
        self.vehicles = copy.deepcopy(self._initial_vehicles)
        self.deliveries = copy.deepcopy(self._initial_deliveries)
        self.active_disruptions = []
        self.current_impact = None
        self.current_plan = None
        self.applied_plans_history = []
        self.audit_log = [
            {
                "timestamp": datetime.now().strftime("%H:%M:%S"),
                "event": "LogiPulse System Initialized",
                "level": "INFO",
                "details": "Fleet telemetry online (20 vehicles, 59 active parcels, 40 graph nodes)"
            }
        ]

    def log_event(self, event: str, level: str = "INFO", details: str = ""):
        self.audit_log.insert(0, {
            "timestamp": datetime.now().strftime("%H:%M:%S"),
            "event": event,
            "level": level,
            "details": details
        })
        if len(self.audit_log) > 50:
            self.audit_log = self.audit_log[:50]

    def get_fleet_data(self) -> dict:
        return {
            "vehicles": self.vehicles,
            "deliveries": self.deliveries,
            "graph": self._initial_graph_data,
            "active_disruptions": self.active_disruptions,
            "current_impact": self.current_impact,
            "current_plan": self.current_plan,
            "audit_log": self.audit_log[:15],
            "stats": self.get_stats()
        }

    def get_stats(self) -> dict:
        total_v = len(self.vehicles)
        active_v = sum(1 for v in self.vehicles if v.get("status") == "active")
        total_d = len(self.deliveries)
        delivered_d = sum(1 for d in self.deliveries if d.get("status") == "delivered")
        urgent_d = sum(1 for d in self.deliveries if d.get("priority") == "urgent")
        disruptions_count = len(self.active_disruptions)
        
        on_time_rate = 98.6
        if self.current_impact:
            sla_risk = self.current_impact.get("sla_breach_risk_percent", 0)
            on_time_rate = max(64.0, round(98.6 - (sla_risk * 0.35), 1))

        return {
            "total_vehicles": total_v,
            "active_vehicles": active_v,
            "total_deliveries": total_d,
            "delivered_deliveries": delivered_d,
            "urgent_deliveries": urgent_d,
            "active_disruptions_count": disruptions_count,
            "on_time_rate": on_time_rate,
            "fleet_health": 100 if disruptions_count == 0 else max(60, 100 - disruptions_count * 18),
            "system_status": "NORMAL" if disruptions_count == 0 else "ACTION_REQUIRED"
        }

    def get_preset_scenarios(self) -> List[dict]:
        return [
            {
                "id": "DSR-AVINASHI-FLOOD",
                "title": "Avinashi Road Flash Flooding",
                "type": "weather_disruption",
                "severity": "CRITICAL",
                "location_name": "Avinashi Rd Junc ↔ Lakshmi Mills",
                "affected_edges": [[12, 38]],
                "affected_node": 12,
                "description": "Monsoon downpour causing severe waterlogging between Avinashi Road Junction and Lakshmi Mills. All vehicle transit halted."
            },
            {
                "id": "DSR-V1-BREAKDOWN",
                "title": "Vehicle V1 Engine Transmission Failure",
                "type": "vehicle_breakdown",
                "severity": "CRITICAL",
                "vehicle_id": "V1",
                "affected_node": 38,
                "affected_edges": [[38, 13]],
                "location_name": "Lakshmi Mills (Near Node 38)",
                "description": "Vehicle V1 reporting heavy coolant leak and complete powertrain stall while carrying urgent medical parcel D2."
            },
            {
                "id": "DSR-PEELAMEDU-FLYOVER",
                "title": "Peelamedu Flyover Construction Blockade",
                "type": "road_closure",
                "severity": "HIGH",
                "affected_edges": [[13, 2], [2, 14]],
                "affected_node": 2,
                "location_name": "Hopes College ↔ Peelamedu ↔ Tidel Park",
                "description": "Emergency municipal pipeline repair blocking Peelamedu main arterial corridor towards Tidel IT Park."
            },
            {
                "id": "DSR-AIRPORT-CARGO-RUSH",
                "title": "Airport Express Cargo Gate Jam",
                "type": "customer_window_change",
                "severity": "HIGH",
                "affected_node": 15,
                "affected_edges": [[14, 15], [15, 21]],
                "location_name": "Coimbatore International Airport Cargo Gate 3",
                "description": "Customs inspection bottleneck and security perimeter lockdown causing 90-minute inbound cargo queue."
            },
            {
                "id": "DSR-GANDHIPURAM-GRIDLOCK",
                "title": "Gandhipuram Central Terminal Gridlock",
                "type": "traffic_gridlock",
                "severity": "MEDIUM",
                "affected_node": 0,
                "affected_edges": [[0, 11], [0, 12], [0, 35]],
                "location_name": "Gandhipuram Bus Stand & Signal",
                "description": "Signal hardware failure at central crossway causing multi-kilometer vehicle congestion."
            }
        ]

    def trigger_disruption(self, disruption_data: dict) -> dict:
        d_id = disruption_data.get("id", f"DSR-{len(self.active_disruptions)+1:03d}")
        disruption_data["id"] = d_id
        disruption_data["timestamp"] = datetime.now().strftime("%H:%M:%S")

        # Check if already present
        self.active_disruptions = [d for d in self.active_disruptions if d["id"] != d_id]
        self.active_disruptions.append(disruption_data)

        # Calculate Impact
        impact = self.impact_analyzer.evaluate_impact(disruption_data, self.vehicles, self.deliveries)
        self.current_impact = impact

        # Generate Decision Recommendations
        options = self.decision_engine.generate_recommendations(disruption_data, impact, self.vehicles, self.deliveries)
        self.current_plan = {
            "disruption_id": d_id,
            "generated_at": datetime.now().strftime("%H:%M:%S"),
            "options": options,
            "selected_option_id": options[0]["id"] if options else None,
            "assignments": options[0]["payload"].get("assignments", []) if options else []
        }

        self.log_event(
            f"Disruption Detected: {disruption_data.get('title')}",
            level="CRITICAL",
            details=f"Identified {impact['affected_vehicles_count']} delayed fleets and {impact['affected_deliveries_count']} at-risk packages."
        )

        return {
            "disruption": disruption_data,
            "impact": impact,
            "plan": self.current_plan
        }

    def apply_solution(self, option_id: str) -> dict:
        if not self.current_plan:
            return {"status": "error", "message": "No active plan to apply"}

        selected_opt = next((opt for opt in self.current_plan.get("options", []) if opt["id"] == option_id), None)
        if not selected_opt:
            selected_opt = self.current_plan["options"][0] if self.current_plan.get("options") else None

        if not selected_opt:
            return {"status": "error", "message": "Selected option not found"}

        payload = selected_opt.get("payload", {})
        action_type = payload.get("action")

        if action_type == "reroute":
            v_id = payload.get("vehicle_id")
            new_route = payload.get("new_route", [])
            for v in self.vehicles:
                if v["id"] == v_id:
                    v["route"] = new_route
                    v["status"] = "rerouted (optimal)"
                    v["color"] = "#22c55e"
            self.log_event(f"Action Executed: Dynamic Re-Route Applied for Fleet {v_id}", "SUCCESS", f"Bypassing blockade. Saved estimated {selected_opt['metrics']['time_saved']}.")

        elif action_type == "intercept":
            src_v = payload.get("source_vehicle")
            tgt_v = payload.get("target_vehicle")
            transferred = payload.get("transferred_deliveries", [])
            for d in self.deliveries:
                if d["id"] in transferred:
                    d["vehicle_id"] = tgt_v
                    d["status"] = "transferred"
            for v in self.vehicles:
                if v["id"] == tgt_v:
                    v["route"].append(payload.get("rendezvous_node", 0))
            self.log_event(f"Action Executed: Intercept Rendezvous between {src_v} & {tgt_v}", "SUCCESS", f"Packages {', '.join(transferred)} transferred successfully.")

        elif action_type == "reschedule":
            notified = payload.get("deliveries_to_notify", [])
            for d in self.deliveries:
                if d["id"] in notified:
                    d["time_window"] = payload.get("revised_window", d["time_window"])
                    d["status"] = "rescheduled"
            self.log_event("Action Executed: Automated Customer Reschedule Dispatched", "SUCCESS", f"{len(notified)} customer notifications synced.")

        # Archive plan
        applied_record = {
            "applied_at": datetime.now().strftime("%H:%M:%S"),
            "option_id": option_id,
            "title": selected_opt["title"],
            "disruption_id": self.current_plan.get("disruption_id")
        }
        self.applied_plans_history.append(applied_record)

        # Clear active disruption and impact once resolved
        resolved_disruption_id = self.current_plan.get("disruption_id")
        self.active_disruptions = [d for d in self.active_disruptions if d["id"] != resolved_disruption_id]
        
        last_impact = self.current_impact
        last_plan = self.current_plan
        self.current_impact = None
        self.current_plan = None

        return {
            "status": "success",
            "message": f"Successfully applied {selected_opt['title']} and synced telemetry to drivers.",
            "applied_record": applied_record,
            "fleet_data": self.get_fleet_data()
        }
