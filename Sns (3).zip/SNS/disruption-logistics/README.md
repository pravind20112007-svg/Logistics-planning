# 🚀 LogiPulse — Disruption-Aware Autonomous Logistics Platform
> **Autonomous Disruption-Aware Logistics Platform** &bull; Intelligent real-time planning and autonomous decision hub for dynamic logistics.

---

## 🌟 Core Concept: The Three Critical Questions

When real-time disruptions (flash floods, vehicle breakdowns, flyover closures, customer window shifts) strike a logistics network, **LogiPulse** automatically answers:

| Question | LogiPulse Module | Key Capabilities |
| :--- | :--- | :--- |
| **1. What changed?** | **Module A: Disruption Center** | Sub-second anomaly detection, root cause telemetry, weather/traffic factor correlation, and simulation injector. |
| **2. What is affected?** | **Module B: Cascade Impact DAG** | Real-time calculation of delayed fleets, at-risk urgent parcels, customer SLA breach %, driver shift threshold warnings, and interactive DAG visualization. |
| **3. What should they do next?** | **Module C: AI Decision Engine** | 3 actionable resolution cards (Dynamic Re-route bypass, Mid-route intercept load swap, Automated customer reschedule) with 1-click driver sync. |

---

## 💻 Tech Stack & Architecture

- **Backend**: FastAPI (Python 3.14), Uvicorn, Pydantic, NetworkX-compatible Dijkstra shortest path algorithms, cascade dependency analyzers.
- **Frontend**: Responsive Single-Page Operations Console with dark operational glassmorphic design, Tailwind CSS, Leaflet JS interactive Coimbatore logistics grid (40 nodes, 20 fleets, 59 parcels), Lucide icons, Canvas confetti.
- **AI Copilot**: Natural language dispatcher assistant for real-time fleet queries and recommendation explanations.

---

## ⚡ Quick Start & Running Locally

### 1. One-Click Launch (Windows)
Double-click `run.bat` in the project root, or execute:
```powershell
& "C:\Users\pravi\AppData\Local\Python\bin\python.exe" "disruption-logistics\run_server.py"
```

### 2. Access the Application
- 🌐 **Web Dashboard & Landing Page**: [http://localhost:8000](http://localhost:8000)
- 📚 **Interactive Swagger API Documentation**: [http://localhost:8000/docs](http://localhost:8000/docs)

---

## 🎯 Key Simulated Scenarios

1. **🌊 Avinashi Road Flash Flooding** (`DSR-AVINASHI-FLOOD`): Waterlogging blocks Node 12 ↔ Node 38; AI solver reroutes Fleet V1 via Ganapathy/Vilankurichi arterial bypass.
2. **🔧 Fleet V1 Powertrain Failure** (`DSR-V1-BREAKDOWN`): Immobilization at Lakshmi Mills; solver triggers nearest candidate vehicle (V18/V10) to execute a mid-route rendezvous intercept for urgent parcel D2.
3. **🚧 Peelamedu Flyover Construction Blockade** (`DSR-PEELAMEDU-FLYOVER`): Pipeline rupture at Node 2; prevents airport cross-dock misses by rerouting affected freight.
4. **✈️ Airport Cargo Gate Jam** (`DSR-AIRPORT-CARGO-RUSH`): Inbound gate backlog at Node 15; auto-dispatches customer ETA reschedule notices.
5. **🛑 Gandhipuram Terminal Gridlock** (`DSR-GANDHIPURAM-GRIDLOCK`): Central signal failure; spreads traffic across parallel perimeter routes.
