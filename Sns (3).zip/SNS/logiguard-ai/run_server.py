"""
LogiGuard AI - Application Server Launcher
Disruption-Aware Logistics Planning System
"""

import os
import sys
import socket

# Ensure UTF-8 output on Windows
if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

# Ensure directory is on sys.path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from database import init_db, get_db_connection
from seed_data import seed_database
from app import app

def check_and_seed_if_needed():
    """Seeds the DB if no users or vehicles exist."""
    init_db()
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) as cnt FROM users")
    u_cnt = cur.fetchone()["cnt"]
    cur.execute("SELECT COUNT(*) as cnt FROM vehicles")
    v_cnt = cur.fetchone()["cnt"]
    conn.close()

    if u_cnt == 0 or v_cnt == 0:
        print("[INIT] Empty database detected. Seeding sample fleet & orders...")
        seed_database()

def is_port_available(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('localhost', port)) != 0

if __name__ == "__main__":
    check_and_seed_if_needed()

    target_port = 8000
    if not is_port_available(target_port):
        target_port = 5000

    print("=" * 68)
    print(">> 🚀 LogiGuard AI — Disruption-Aware Logistics Operating System")
    print(f">> 🌐 Web Dashboard: http://localhost:{target_port}")
    print(f">> 👑 Admin Demo:    admin@logiguard.ai  /  admin123")
    print(f">> 📦 Customer Demo: john.doe@example.com /  customer123")
    print("=" * 68)

    app.run(host="0.0.0.0", port=target_port, debug=False)
