/**
 * LogiGuard AI - Chart.js Visualizer
 * Renders delivery SLA performance trends, vehicle battery utilization, and package distribution.
 */

const ChartsEngine = {
    slaChart: null,
    pkgChart: null,
    fleetChart: null,

    renderAll(analyticsData) {
        this.renderSLATrend(analyticsData.performance_trend || []);
        this.renderPackageDistribution(analyticsData.package_distribution || {});
        this.renderFleetUtilization(analyticsData.fleet_utilization || []);
    },

    renderSLATrend(trendData) {
        const ctx = document.getElementById("sla-trend-chart");
        if (!ctx) return;

        if (this.slaChart) {
            this.slaChart.destroy();
        }

        const labels = trendData.map(d => d.day);
        const onTimeData = trendData.map(d => d.on_time_pct);
        const disruptionData = trendData.map(d => d.disruptions);

        this.slaChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'On-Time SLA %',
                        data: onTimeData,
                        borderColor: '#0066FF',
                        backgroundColor: 'rgba(0, 102, 255, 0.12)',
                        fill: true,
                        tension: 0.4,
                        borderWidth: 3,
                        pointBackgroundColor: '#00D2FF',
                        pointRadius: 5
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#94A3B8', font: { family: 'Plus Jakarta Sans' } } }
                },
                scales: {
                    y: {
                        min: 90,
                        max: 100,
                        grid: { color: 'rgba(64, 100, 160, 0.15)' },
                        ticks: { color: '#94A3B8', callback: v => v + '%' }
                    },
                    x: {
                        grid: { color: 'rgba(64, 100, 160, 0.15)' },
                        ticks: { color: '#94A3B8' }
                    }
                }
            }
        });
    },

    renderPackageDistribution(pkgData) {
        const ctx = document.getElementById("package-dist-chart");
        if (!ctx) return;

        if (this.pkgChart) {
            this.pkgChart.destroy();
        }

        const labels = Object.keys(pkgData);
        const data = Object.values(pkgData);

        this.pkgChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: [
                        '#EF4444', // Medical (Urgent)
                        '#0066FF', // Electronics
                        '#10B981', // Perishable
                        '#8B5CF6', // Documents
                        '#F59E0B'  // Heavy Freight
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { color: '#94A3B8', font: { size: 11, family: 'Plus Jakarta Sans' } }
                    }
                },
                cutout: '68%'
            }
        });
    },

    renderFleetUtilization(fleetData) {
        const ctx = document.getElementById("fleet-util-chart");
        if (!ctx) return;

        if (this.fleetChart) {
            this.fleetChart.destroy();
        }

        const labels = fleetData.map(f => f.vehicle_type.split(' ')[0]);
        const utilData = fleetData.map(f => Math.round(f.avg_utilization || 65));
        const batteryData = fleetData.map(f => Math.round(f.avg_battery || 82));

        this.fleetChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Capacity Util %',
                        data: utilData,
                        backgroundColor: '#0066FF',
                        borderRadius: 6
                    },
                    {
                        label: 'Avg Battery/Fuel %',
                        data: batteryData,
                        backgroundColor: '#10B981',
                        borderRadius: 6
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#94A3B8', font: { family: 'Plus Jakarta Sans' } } }
                },
                scales: {
                    y: {
                        max: 100,
                        grid: { color: 'rgba(64, 100, 160, 0.15)' },
                        ticks: { color: '#94A3B8' }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { color: '#94A3B8' }
                    }
                }
            }
        });
    }
};
