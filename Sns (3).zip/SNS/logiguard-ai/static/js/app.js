/**
 * LogiGuard AI - Core Application & Routing Controller
 * Authentication, REST API client, State management, Hackathon Demo Orchestrator.
 */

const ApiClient = {
    async request(endpoint, method = "GET", body = null) {
        const token = localStorage.getItem("logiguard_token");
        const headers = {
            "Content-Type": "application/json"
        };
        if (token) {
            headers["Authorization"] = `Bearer ${token}`;
        }

        const config = { method, headers };
        if (body) {
            config.body = JSON.stringify(body);
        }

        const response = await fetch(endpoint, config);
        const data = await response.json();

        if (!response.ok) {
            if (response.status === 401) {
                App.handleUnauthorized();
            }
            throw new Error(data.error || "An unexpected network error occurred.");
        }
        return data;
    },

    get(endpoint) { return this.request(endpoint, "GET"); },
    post(endpoint, body) { return this.request(endpoint, "POST", body); },
    put(endpoint, body) { return this.request(endpoint, "PUT", body); },
    delete(endpoint) { return this.request(endpoint, "DELETE"); }
};

const App = {
    currentUser: null,
    currentView: "landing", // "landing", "owner", "customer"

    async init() {
        this.bindGlobalEvents();
        await this.checkAuthSession();
    },

    bindGlobalEvents() {
        // Auth modal toggles
        const authModal = document.getElementById("auth-modal");
        document.querySelectorAll(".open-auth-modal-btn").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const role = e.currentTarget.dataset.role || "owner";
                this.openAuthModal(role);
            });
        });

        // Close modal on click outside or close button
        document.querySelectorAll(".modal-close, .modal-overlay").forEach(el => {
            el.addEventListener("click", (e) => {
                if (e.target === el) {
                    el.closest(".modal-overlay")?.classList.remove("active");
                }
            });
        });

        // Login role tab switcher
        document.querySelectorAll(".auth-tab-btn").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const targetRole = e.currentTarget.dataset.authRole;
                this.switchAuthTab(targetRole);
            });
        });

        // Toggle password show/hide
        document.querySelectorAll(".toggle-password").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const input = e.currentTarget.previousElementSibling;
                if (input.type === "password") {
                    input.type = "text";
                    e.currentTarget.innerText = "👁️‍🗨️";
                } else {
                    input.type = "password";
                    e.currentTarget.innerText = "👁️";
                }
            });
        });

        // Login form submit
        const loginForm = document.getElementById("login-form");
        if (loginForm) {
            loginForm.addEventListener("submit", (e) => this.handleLogin(e));
        }

        // Register form submit
        const registerForm = document.getElementById("register-form");
        if (registerForm) {
            registerForm.addEventListener("submit", (e) => this.handleRegister(e));
        }

        // Forgot password
        const forgotLink = document.getElementById("forgot-password-link");
        if (forgotLink) {
            forgotLink.addEventListener("click", (e) => {
                e.preventDefault();
                this.openForgotPasswordModal();
            });
        }
    },

    async checkAuthSession() {
        const token = localStorage.getItem("logiguard_token");
        if (!token) {
            this.showView("landing");
            return;
        }

        try {
            const res = await ApiClient.get("/api/auth/me");
            this.currentUser = res.user;
            this.updateNavbarUser();

            if (this.currentUser.role === "owner") {
                this.showView("owner");
            } else {
                this.showView("customer");
            }
        } catch (err) {
            console.warn("Session check expired or invalid", err);
            this.logout(false);
        }
    },

    showView(viewName) {
        this.currentView = viewName;

        const landingEl = document.getElementById("landing-view");
        const authEl = document.getElementById("auth-view");
        const ownerEl = document.getElementById("owner-view");
        const customerEl = document.getElementById("customer-view");

        if (landingEl) landingEl.style.display = viewName === "landing" ? "block" : "none";
        if (authEl) authEl.style.display = viewName === "auth" ? "block" : "none";
        if (ownerEl) ownerEl.style.display = viewName === "owner" ? "block" : "none";
        if (customerEl) customerEl.style.display = viewName === "customer" ? "block" : "none";

        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });

        // Navigation elements
        const userNav = document.getElementById("nav-user-section");
        const guestNav = document.getElementById("nav-guest-section");

        if (this.currentUser) {
            userNav.style.display = "flex";
            guestNav.style.display = "none";
            document.getElementById("nav-user-name").innerText = this.currentUser.full_name.split(" ")[0];
            document.getElementById("nav-user-role-badge").innerText = this.currentUser.role.toUpperCase();
        } else {
            userNav.style.display = "none";
            guestNav.style.display = "flex";
        }

        // Initialize view sub-controllers
        if (viewName === "owner") {
            OwnerController.init();
        } else if (viewName === "customer") {
            CustomerController.init();
        }
    },

    showAuthView(initialRole = "owner") {
        this.showView("auth");
        this.switchPageAuthRole(initialRole);
    },

    switchPageAuthRole(role) {
        const tabOwner = document.getElementById("auth-page-tab-owner");
        const tabCustomer = document.getElementById("auth-page-tab-customer");
        const tabRegister = document.getElementById("auth-page-tab-register");

        const loginSection = document.getElementById("page-login-section");
        const regSection = document.getElementById("page-register-section");

        const heroTitle = document.getElementById("auth-page-hero-title");
        const heroDesc = document.getElementById("auth-page-hero-desc");
        const featuresBox = document.getElementById("auth-page-features-box");

        // Clear active tab states
        [tabOwner, tabCustomer, tabRegister].forEach(t => t?.classList.remove("active"));

        if (role === "register") {
            tabRegister?.classList.add("active");
            loginSection.style.display = "none";
            regSection.style.display = "block";

            heroTitle.innerText = "Join the Autonomous Logistics Network";
            heroDesc.innerText = "Register your business or personal account to start sending shipments with AI disruption resilience and live telemetry.";
            featuresBox.innerHTML = `
                <div style="display: flex; gap: 12px; align-items: flex-start;">
                    <div style="width: 32px; height: 32px; border-radius: 8px; background: rgba(0, 102, 255, 0.2); color: #38BDF8; display: flex; align-items: center; justify-content: center; font-weight: 800; flex-shrink: 0;">✓</div>
                    <div>
                        <strong style="color: #F8FAFC; font-size: 0.95rem;">Instant Account Activation</strong>
                        <div style="color: #94A3B8; font-size: 0.85rem;">Access dashboards immediately with role-tailored features.</div>
                    </div>
                </div>
                <div style="display: flex; gap: 12px; align-items: flex-start;">
                    <div style="width: 32px; height: 32px; border-radius: 8px; background: rgba(16, 185, 129, 0.2); color: #10B981; display: flex; align-items: center; justify-content: center; font-weight: 800; flex-shrink: 0;">✓</div>
                    <div>
                        <strong style="color: #F8FAFC; font-size: 0.95rem;">Enterprise Grade Security</strong>
                        <div style="color: #94A3B8; font-size: 0.85rem;">PBKDF2 password hashing &amp; token-isolated data security.</div>
                    </div>
                </div>
            `;
            return;
        }

        // Login Mode (Owner or Customer)
        loginSection.style.display = "block";
        regSection.style.display = "none";

        document.getElementById("page-login-role").value = role;

        if (role === "owner") {
            tabOwner?.classList.add("active");
            document.getElementById("page-login-email").value = "admin@logiguard.ai";
            document.getElementById("page-login-password").value = "admin123";

            heroTitle.innerText = "Fleet Owner & Dispatcher Control Portal";
            heroDesc.innerText = "Access autonomous fleet operations across 20 vehicles and 100 customer shipments. Real-time Dijkstra rerouting solver, cascade delay DAG, and dynamic dispatch synchronization.";
            featuresBox.innerHTML = `
                <div style="display: flex; gap: 12px; align-items: flex-start;">
                    <div style="width: 32px; height: 32px; border-radius: 8px; background: rgba(0, 102, 255, 0.2); color: #38BDF8; display: flex; align-items: center; justify-content: center; font-weight: 800; flex-shrink: 0;">✓</div>
                    <div>
                        <strong style="color: #F8FAFC; font-size: 0.95rem;">Fleet-Wide Telematics &amp; Driver Control</strong>
                        <div style="color: #94A3B8; font-size: 0.85rem;">Live GPS telemetry for 20 EV vans, trucks, and cold-chain carriers.</div>
                    </div>
                </div>
                <div style="display: flex; gap: 12px; align-items: flex-start;">
                    <div style="width: 32px; height: 32px; border-radius: 8px; background: rgba(16, 185, 129, 0.2); color: #10B981; display: flex; align-items: center; justify-content: center; font-weight: 800; flex-shrink: 0;">✓</div>
                    <div>
                        <strong style="color: #F8FAFC; font-size: 0.95rem;">AI Disruption &amp; Cascade Mitigation</strong>
                        <div style="color: #94A3B8; font-size: 0.85rem;">Autonomous bypass corridor calculations and multi-vehicle load swap.</div>
                    </div>
                </div>
                <div style="display: flex; gap: 12px; align-items: flex-start;">
                    <div style="width: 32px; height: 32px; border-radius: 8px; background: rgba(245, 158, 11, 0.2); color: #F59E0B; display: flex; align-items: center; justify-content: center; font-weight: 800; flex-shrink: 0;">✓</div>
                    <div>
                        <strong style="color: #F8FAFC; font-size: 0.95rem;">Order Schedule &amp; SLA Optimization</strong>
                        <div style="color: #94A3B8; font-size: 0.85rem;">Automated customer window sync with &lt; 0.8s resolution latency.</div>
                    </div>
                </div>
            `;
        } else {
            tabCustomer?.classList.add("active");
            document.getElementById("page-login-email").value = "john.doe@example.com";
            document.getElementById("page-login-password").value = "customer123";

            heroTitle.innerText = "Customer Shipment & Tracking Portal";
            heroDesc.innerText = "Private client tracking studio. Monitor your consignments on interactive maps with real-time transparent delay warnings, dynamic ETAs, and instant order placement.";
            featuresBox.innerHTML = `
                <div style="display: flex; gap: 12px; align-items: flex-start;">
                    <div style="width: 32px; height: 32px; border-radius: 8px; background: rgba(0, 102, 255, 0.2); color: #38BDF8; display: flex; align-items: center; justify-content: center; font-weight: 800; flex-shrink: 0;">✓</div>
                    <div>
                        <strong style="color: #F8FAFC; font-size: 0.95rem;">Private &amp; Isolated Order Tracking</strong>
                        <div style="color: #94A3B8; font-size: 0.85rem;">Strict customer data isolation—only you can view your packages.</div>
                    </div>
                </div>
                <div style="display: flex; gap: 12px; align-items: flex-start;">
                    <div style="width: 32px; height: 32px; border-radius: 8px; background: rgba(16, 185, 129, 0.2); color: #10B981; display: flex; align-items: center; justify-content: center; font-weight: 800; flex-shrink: 0;">✓</div>
                    <div>
                        <strong style="color: #F8FAFC; font-size: 0.95rem;">6-Stage Live Timeline Stepper</strong>
                        <div style="color: #94A3B8; font-size: 0.85rem;">Real-time progress from Order Placed &rarr; Dispatched &rarr; Delivered.</div>
                    </div>
                </div>
                <div style="display: flex; gap: 12px; align-items: flex-start;">
                    <div style="width: 32px; height: 32px; border-radius: 8px; background: rgba(239, 68, 68, 0.2); color: #EF4444; display: flex; align-items: center; justify-content: center; font-weight: 800; flex-shrink: 0;">✓</div>
                    <div>
                        <strong style="color: #F8FAFC; font-size: 0.95rem;">Transparent Disruption Notifications</strong>
                        <div style="color: #94A3B8; font-size: 0.85rem;">Instant notification when AI recalculates an arterial bypass route.</div>
                    </div>
                </div>
            `;
        }
    },

    fillPageCredentials(role) {
        if (role === "owner") {
            this.switchPageAuthRole("owner");
            document.getElementById("page-login-email").value = "admin@logiguard.ai";
            document.getElementById("page-login-password").value = "admin123";
        } else if (role === "customer") {
            this.switchPageAuthRole("customer");
            document.getElementById("page-login-email").value = "john.doe@example.com";
            document.getElementById("page-login-password").value = "customer123";
        } else if (role === "customer2") {
            this.switchPageAuthRole("customer");
            document.getElementById("page-login-email").value = "priya.sharma@example.com";
            document.getElementById("page-login-password").value = "customer123";
        }
        this.showToast(`Prefilled demo credentials for ${role}!`, "info");
    },

    async handlePageLogin(e) {
        e.preventDefault();
        const email = document.getElementById("page-login-email").value;
        const password = document.getElementById("page-login-password").value;
        const role = document.getElementById("page-login-role").value;
        const submitBtn = document.getElementById("page-login-submit-btn");

        try {
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerText = "⏳ Authenticating...";
            }
            this.showToast("Authenticating with LogiGuard AI security vault...", "info");
            const res = await ApiClient.post("/api/auth/login", { email, password, role });

            localStorage.setItem("logiguard_token", res.token);
            this.currentUser = res.user;

            this.showToast(res.message, "success");

            if (res.user.role === "owner") {
                this.showView("owner");
            } else {
                this.showView("customer");
            }
        } catch (err) {
            this.showToast(err.message, "danger");
        } finally {
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerText = "🔐 Sign In to Console";
            }
        }
    },

    async handlePageRegister(e) {
        e.preventDefault();
        const name = document.getElementById("page-reg-name").value;
        const email = document.getElementById("page-reg-email").value;
        const password = document.getElementById("page-reg-password").value;
        const phone = document.getElementById("page-reg-phone").value;
        const role = document.getElementById("page-reg-role").value;
        const address = document.getElementById("page-reg-address").value;
        const submitBtn = document.getElementById("page-reg-submit-btn");

        try {
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerText = "⏳ Creating Account...";
            }
            const res = await ApiClient.post("/api/auth/register", {
                full_name: name,
                email: email,
                password: password,
                phone: phone,
                role: role,
                address: address
            });

            localStorage.setItem("logiguard_token", res.token);
            this.currentUser = res.user;

            this.showToast("Registration successful! Welcome to LogiGuard AI.", "success");

            if (res.user.role === "owner") {
                this.showView("owner");
            } else {
                this.showView("customer");
            }
        } catch (err) {
            this.showToast(err.message, "danger");
        } finally {
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerText = "✨ Complete Registration & Enter Dashboard";
            }
        }
    },

    openAuthModal(role = "owner") {
        this.showAuthView(role);
    },

    switchAuthTab(role) {
        this.switchPageAuthRole(role);
    },

    fillDemoCredentials(role) {
        if (role === "owner") {
            this.switchAuthTab("owner");
            document.getElementById("login-email").value = "admin@logiguard.ai";
            document.getElementById("login-password").value = "admin123";
        } else if (role === "customer") {
            this.switchAuthTab("customer");
            document.getElementById("login-email").value = "john.doe@example.com";
            document.getElementById("login-password").value = "customer123";
        } else if (role === "customer2") {
            this.switchAuthTab("customer");
            document.getElementById("login-email").value = "priya.sharma@example.com";
            document.getElementById("login-password").value = "customer123";
        }
        this.showToast(`Prefilled demo credentials for ${role}!`, "info");
    },

    async handleLogin(e) {
        e.preventDefault();
        const email = document.getElementById("login-email").value;
        const password = document.getElementById("login-password").value;
        const role = document.getElementById("auth-login-role").value;

        try {
            this.showToast("Authenticating with LogiGuard AI security vault...", "info");
            const res = await ApiClient.post("/api/auth/login", { email, password, role });
            
            localStorage.setItem("logiguard_token", res.token);
            this.currentUser = res.user;

            document.getElementById("auth-modal").classList.remove("active");
            this.showToast(res.message, "success");

            if (res.user.role === "owner") {
                this.showView("owner");
            } else {
                this.showView("customer");
            }
        } catch (err) {
            this.showToast(err.message, "danger");
        }
    },

    openRegisterModal() {
        document.getElementById("auth-modal").classList.remove("active");
        document.getElementById("register-modal").classList.add("active");
    },

    async handleRegister(e) {
        e.preventDefault();
        const name = document.getElementById("reg-name").value;
        const email = document.getElementById("reg-email").value;
        const password = document.getElementById("reg-password").value;
        const phone = document.getElementById("reg-phone").value;
        const role = document.getElementById("reg-role").value;
        const address = document.getElementById("reg-address").value;

        try {
            const res = await ApiClient.post("/api/auth/register", {
                full_name: name,
                email: email,
                password: password,
                phone: phone,
                role: role,
                address: address
            });

            localStorage.setItem("logiguard_token", res.token);
            this.currentUser = res.user;

            document.getElementById("register-modal").classList.remove("active");
            this.showToast("Registration successful! Welcome to LogiGuard AI.", "success");

            if (res.user.role === "owner") {
                this.showView("owner");
            } else {
                this.showView("customer");
            }
        } catch (err) {
            this.showToast(err.message, "danger");
        }
    },

    openForgotPasswordModal() {
        const email = prompt("Please enter your registered email address for instant password recovery verification:");
        if (email) {
            ApiClient.post("/api/auth/forgot-password", { email }).then(res => {
                alert(res.message);
            });
        }
    },

    logout(notify = true) {
        localStorage.removeItem("logiguard_token");
        this.currentUser = null;
        this.showView("landing");
        if (notify) {
            this.showToast("You have been logged out securely.", "info");
        }
    },

    handleUnauthorized() {
        this.logout(false);
        this.openAuthModal("owner");
        this.showToast("Your session has expired. Please log in again.", "warning");
    },

    updateNavbarUser() {
        if (!this.currentUser) return;
        document.getElementById("nav-user-name").innerText = this.currentUser.full_name;
    },

    trackOrderDirectly(orderCode) {
        if (this.currentUser && this.currentUser.role === "owner") {
            // Owner tracking
            OwnerController.switchTab("map");
        } else {
            // Customer tracking
            CustomerController.openTrackingForOrder(orderCode);
        }
    },

    async runHackathonDemo() {
        try {
            this.showToast("🚀 Launching Autonomous Hackathon Disruption Simulation...", "info");
            
            // Auto login as admin if not logged in
            if (!this.currentUser || this.currentUser.role !== "owner") {
                const loginRes = await ApiClient.post("/api/auth/login", {
                    email: "admin@logiguard.ai",
                    password: "admin123",
                    role: "owner"
                });
                localStorage.setItem("logiguard_token", loginRes.token);
                this.currentUser = loginRes.user;
                this.showView("owner");
            }

            // Trigger quick demo scenario
            const demoRes = await ApiClient.post("/api/hackathon/quick-demo");
            
            // Switch to disruptions tab in owner
            OwnerController.switchTab("disruptions");
            OwnerController.runDisruptionAnalysis(1);

            this.showToast("🌊 Avinashi Road flood scenario active! AI route optimizer loaded.", "success");
        } catch (err) {
            this.showToast("Demo runner error: " + err.message, "danger");
        }
    },

    showToast(message, type = "info") {
        const container = document.getElementById("toast-container");
        if (!container) return;

        const toast = document.createElement("div");
        toast.className = "toast";

        const icon = type === "success" ? "✓" : (type === "danger" ? "✕" : (type === "warning" ? "⚠️" : "ℹ️"));
        const color = type === "success" ? "#10B981" : (type === "danger" ? "#EF4444" : (type === "warning" ? "#F59E0B" : "#0066FF"));

        toast.style.borderColor = color;
        toast.innerHTML = `
            <span style="color: ${color}; font-size: 1.25rem; font-weight: 800;">${icon}</span>
            <div style="flex: 1; font-size: 0.9rem; line-height: 1.35;">${message}</div>
        `;

        container.appendChild(toast);

        setTimeout(() => {
            toast.style.opacity = "0";
            toast.style.transform = "translateX(100%)";
            setTimeout(() => toast.remove(), 300);
        }, 4500);
    }
};

// Global App Initialization on DOM Ready
document.addEventListener("DOMContentLoaded", () => {
    App.init();
});
