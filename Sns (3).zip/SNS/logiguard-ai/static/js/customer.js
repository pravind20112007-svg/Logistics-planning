/**
 * LogiGuard AI - Customer Portal Controller
 * Handles customer order placement, strictly isolated orders list, live tracking studio, and notifications.
 */

const CustomerController = {
    activeTab: 'orders',
    orders: [],
    currentTrackedOrder: null,

    async init() {
        this.bindEvents();
        await this.loadCustomerOrders();
        await this.loadNotifications();
    },

    bindEvents() {
        // Customer nav buttons
        document.querySelectorAll('.customer-nav-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const tab = e.currentTarget.dataset.tab;
                this.switchTab(tab);
            });
        });

        // Place Order Form Price Estimator
        const weightInput = document.getElementById('order-weight');
        const priorityInput = document.getElementById('order-priority');
        if (weightInput && priorityInput) {
            const updatePrice = () => {
                const weight = parseFloat(weightInput.value) || 1;
                const priority = priorityInput.value;
                const baseRate = priority === 'urgent_medical' ? 240 : (priority === 'express' ? 140 : 70);
                const estimatedTotal = Math.round(baseRate + (weight * 12));
                document.getElementById('estimated-price-tag').innerText = `₹${estimatedTotal}`;
            };
            weightInput.addEventListener('input', updatePrice);
            priorityInput.addEventListener('change', updatePrice);
        }

        // Place order form submit
        const placeOrderForm = document.getElementById('place-order-form');
        if (placeOrderForm) {
            placeOrderForm.addEventListener('submit', (e) => this.submitPlaceOrder(e));
        }

        // Profile update form submit
        const profileForm = document.getElementById('customer-profile-form');
        if (profileForm) {
            profileForm.addEventListener('submit', (e) => this.submitUpdateProfile(e));
        }
    },

    switchTab(tabName) {
        this.activeTab = tabName;
        document.querySelectorAll('.customer-nav-btn').forEach(b => {
            b.classList.toggle('active', b.dataset.tab === tabName);
        });

        document.querySelectorAll('.customer-tab-content').forEach(c => {
            c.style.display = c.id === `customer-tab-${tabName}` ? 'block' : 'none';
        });

        if (tabName === 'orders') this.loadCustomerOrders();
        if (tabName === 'track') this.loadTrackingStudio();
        if (tabName === 'notifications') this.loadNotifications();
        if (tabName === 'profile') this.loadProfile();
    },

    async loadCustomerOrders() {
        try {
            const res = await ApiClient.get('/api/customer/orders');
            this.orders = res.orders || [];

            // Update stats
            const activeCount = this.orders.filter(o => ['in_transit', 'assigned', 'order_placed', 'confirmed', 'delayed'].includes(o.status)).length;
            const deliveredCount = this.orders.filter(o => o.status === 'delivered').length;
            
            document.getElementById('cust-kpi-active').innerText = activeCount;
            document.getElementById('cust-kpi-delivered').innerText = deliveredCount;
            document.getElementById('cust-kpi-total').innerText = this.orders.length;

            const grid = document.getElementById('customer-orders-grid');
            if (!grid) return;

            if (this.orders.length === 0) {
                grid.innerHTML = `
                    <div style="grid-column: 1/-1; text-align: center; padding: 3rem; color: #94A3B8;">
                        <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">📦</div>
                        <h3>No orders found</h3>
                        <p>You have not placed any logistics requests yet.</p>
                        <button class="btn btn-primary" onclick="CustomerController.switchTab('new-order')" style="margin-top: 1rem;">+ Place New Order</button>
                    </div>
                `;
                return;
            }

            grid.innerHTML = this.orders.map(o => {
                const isDelayed = o.status === 'delayed';
                const statusBadge = isDelayed ? 
                    '<span class="badge badge-danger">⚠️ Delayed (Rerouted)</span>' :
                    (o.status === 'delivered' ? '<span class="badge badge-success">✓ Delivered</span>' :
                    (o.status === 'in_transit' ? '<span class="badge badge-info">🚚 In Transit</span>' :
                    `<span class="badge badge-purple">${o.status.replace('_', ' ')}</span>`));

                const priorityBadge = o.priority === 'urgent_medical' ?
                    '<span class="badge badge-danger">🚨 Urgent Medical</span>' :
                    (o.priority === 'express' ? '<span class="badge badge-warning">⚡ Express</span>' : '<span class="badge badge-info">Standard</span>');

                const etaFormatted = o.revised_eta ? new Date(o.revised_eta).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : 'Pending ETA';

                const canCancel = ['order_placed', 'confirmed'].includes(o.status);

                return `
                    <div class="glass-panel" style="padding: 1.5rem; display: flex; flex-direction: column; justify-content: space-between; gap: 1rem;">
                        <div>
                            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.5rem;">
                                <div>
                                    <span style="font-family: 'JetBrains Mono'; font-weight: 700; color: #38BDF8; font-size: 1.1rem;">${o.order_code}</span>
                                    <div style="font-size: 11px; color: #94A3B8;">${new Date(o.created_at).toLocaleString([], {dateStyle:'medium', timeStyle:'short'})}</div>
                                </div>
                                ${priorityBadge}
                            </div>
                            
                            <div style="margin: 0.75rem 0; font-size: 0.88rem; line-height: 1.4;">
                                <div style="color: #94A3B8; font-size: 11px;">RECIPIENT & DESTINATION</div>
                                <strong>${o.recipient_name}</strong> &bull; ${o.delivery_address}
                            </div>

                            <div style="background: rgba(14, 26, 54, 0.7); padding: 0.75rem; border-radius: 8px; font-size: 0.85rem; margin-top: 0.5rem;">
                                <div style="display: flex; justify-content: space-between;">
                                    <span style="color: #94A3B8;">Expected Arrival:</span>
                                    <strong style="color: ${isDelayed ? '#EF4444' : '#10B981'};">${etaFormatted}</strong>
                                </div>
                                <div style="display: flex; justify-content: space-between; margin-top: 4px;">
                                    <span style="color: #94A3B8;">Assigned Vehicle:</span>
                                    <span style="font-family: 'JetBrains Mono';">${o.vehicle_code || 'Matching...'}</span>
                                </div>
                            </div>
                        </div>

                        <div>
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem;">
                                <span style="font-size: 12px; color: #94A3B8;">Status:</span>
                                ${statusBadge}
                            </div>
                            <div style="display: flex; gap: 0.5rem;">
                                <button class="btn btn-primary btn-sm" style="flex: 1;" onclick="CustomerController.openTrackingForOrder('${o.order_code}')">
                                    🗺️ Live Track
                                </button>
                                ${canCancel ? `
                                    <button class="btn btn-outline btn-sm" style="color: #EF4444;" onclick="CustomerController.cancelOrder('${o.order_code}')">
                                        Cancel
                                    </button>
                                ` : ''}
                            </div>
                        </div>
                    </div>
                `;
            }).join('');
        } catch (err) {
            console.error("Failed to load customer orders", err);
        }
    },

    async submitPlaceOrder(e) {
        e.preventDefault();
        const recipient = document.getElementById('order-recipient-name').value;
        const phone = document.getElementById('order-recipient-phone').value;
        const address = document.getElementById('order-delivery-address').value;
        const pkgType = document.getElementById('order-package-type').value;
        const weight = document.getElementById('order-weight').value;
        const priority = document.getElementById('order-priority').value;
        const notes = document.getElementById('order-notes').value;

        try {
            App.showToast("Submitting order to LogiGuard AI fleet dispatcher...", "info");
            const res = await ApiClient.post('/api/customer/orders', {
                recipient_name: recipient,
                recipient_phone: phone,
                delivery_address: address,
                package_type: pkgType,
                weight_kg: parseFloat(weight),
                priority: priority,
                delivery_notes: notes
            });

            App.showToast(`Order #${res.order_code} placed successfully! Estimated delivery: ${res.eta}`, "success");
            e.target.reset();
            this.switchTab('orders');
        } catch (err) {
            App.showToast("Failed to place order: " + err.message, "danger");
        }
    },

    async openTrackingForOrder(orderCode) {
        this.switchTab('track');
        await this.loadTrackingStudio(orderCode);
    },

    async loadTrackingStudio(orderCode = null) {
        // If orderCode not supplied, pick the first active order
        if (!orderCode) {
            if (this.orders.length > 0) {
                orderCode = this.orders[0].order_code;
            } else {
                return;
            }
        }

        try {
            const res = await ApiClient.get(`/api/customer/orders/${orderCode}/track`);
            this.currentTrackedOrder = res;
            const o = res.order;

            // Populate selector dropdown
            const selector = document.getElementById('tracking-order-select');
            if (selector) {
                selector.innerHTML = this.orders.map(item => `
                    <option value="${item.order_code}" ${item.order_code === orderCode ? 'selected' : ''}>
                        ${item.order_code} - ${item.recipient_name} (${item.status})
                    </option>
                `).join('');
                selector.onchange = (e) => this.loadTrackingStudio(e.target.value);
            }

            document.getElementById('track-order-code-display').innerText = o.order_code;
            document.getElementById('track-recipient-display').innerText = o.recipient_name;
            document.getElementById('track-address-display').innerText = o.delivery_address;
            
            const etaTime = o.revised_eta ? new Date(o.revised_eta).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : 'Calculating';
            document.getElementById('track-eta-display').innerText = etaTime;

            // Disruption notice banner
            const alertBox = document.getElementById('track-disruption-alert');
            if (o.status === 'delayed' || o.delay_minutes > 0) {
                alertBox.style.display = 'block';
                alertBox.innerHTML = `
                    <div style="display: flex; gap: 10px; align-items: center;">
                        <span style="font-size: 1.5rem;">⚠️</span>
                        <div>
                            <strong>Disruption Notice & Transparent AI Reroute:</strong> 
                            A road closure on the primary corridor caused a potential +${o.delay_minutes}m delay. 
                            LogiGuard AI has automatically engaged an arterial bypass route. Your revised arrival time is <strong>${etaTime}</strong>.
                        </div>
                    </div>
                `;
            } else {
                alertBox.style.display = 'none';
            }

            // Driver Card
            document.getElementById('track-driver-name').innerText = o.driver_name || 'Assigned Driver';
            document.getElementById('track-driver-phone').innerText = o.driver_phone || '+91 98450 11001';
            document.getElementById('track-vehicle-code').innerText = `${o.vehicle_code || 'V-101'} (${o.vehicle_type || 'EV Van'})`;
            document.getElementById('track-driver-rating').innerText = `⭐ ${o.driver_rating || '4.9'}`;

            // Render 6-Stage Timeline Stepper
            this.renderTrackingStepper(o.status);

            // Render Map
            MapEngine.init("customer-tracking-map");
            MapEngine.renderCustomerLiveTrack(res.pickup, res.delivery, res.live_position, o.status);
        } catch (err) {
            console.error("Failed to load tracking data", err);
            App.showToast("Tracking error: " + err.message, "danger");
        }
    },

    renderTrackingStepper(status) {
        const steps = ['order_placed', 'confirmed', 'assigned', 'in_transit', 'delivered'];
        const statusMap = {
            'order_placed': 0,
            'confirmed': 1,
            'assigned': 2,
            'in_transit': 3,
            'delayed': 3, // In transit but delayed
            'delivered': 4
        };

        const activeIdx = statusMap[status] !== undefined ? statusMap[status] : 0;
        const stepItems = document.querySelectorAll('.cust-step-item');
        
        stepItems.forEach((item, idx) => {
            item.classList.remove('active', 'completed');
            if (idx < activeIdx) {
                item.classList.add('completed');
            } else if (idx === activeIdx) {
                item.classList.add('active');
            }
        });

        const progressBar = document.getElementById('cust-stepper-progress');
        if (progressBar) {
            const pct = (activeIdx / (steps.length - 1)) * 100;
            progressBar.style.width = `${pct}%`;
        }
    },

    async cancelOrder(orderCode) {
        if (!confirm(`Are you sure you want to cancel order #${orderCode}?`)) return;

        try {
            await ApiClient.post(`/api/customer/orders/${orderCode}/cancel`);
            App.showToast(`Order #${orderCode} cancelled successfully.`, "success");
            await this.loadCustomerOrders();
        } catch (err) {
            App.showToast("Could not cancel: " + err.message, "danger");
        }
    },

    async loadNotifications() {
        try {
            const res = await ApiClient.get('/api/customer/notifications');
            const notifs = res.notifications || [];

            // Update badge
            const badge = document.getElementById('cust-unread-notif-badge');
            if (badge) {
                badge.innerText = res.unread_count;
                badge.style.display = res.unread_count > 0 ? 'inline-flex' : 'none';
            }

            const list = document.getElementById('customer-notifications-list');
            if (!list) return;

            if (notifs.length === 0) {
                list.innerHTML = `<div style="text-align: center; padding: 2rem; color: #94A3B8;">No notifications yet.</div>`;
                return;
            }

            list.innerHTML = notifs.map(n => {
                const icon = n.notification_type === 'delay' ? '⚠️' : (n.notification_type === 'route_update' ? '🔀' : '📦');
                return `
                    <div class="glass-panel" style="padding: 1.25rem; border-left: 4px solid ${n.notification_type === 'delay' ? '#EF4444' : '#0066FF'};">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
                            <strong>${icon} ${n.title}</strong>
                            <span style="font-size: 11px; color: #94A3B8;">${new Date(n.created_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                        </div>
                        <p style="font-size: 0.88rem; color: #CBD5E1; margin: 0;">${n.message}</p>
                    </div>
                `;
            }).join('');
        } catch (err) {
            console.error("Failed to load notifications", err);
        }
    },

    async markAllNotificationsRead() {
        try {
            await ApiClient.post('/api/customer/notifications/read-all');
            App.showToast("All notifications marked as read.", "info");
            await this.loadNotifications();
        } catch (err) {
            console.error(err);
        }
    },

    async loadProfile() {
        try {
            const res = await ApiClient.get('/api/customer/profile');
            const p = res.profile;

            document.getElementById('prof-name').value = p.full_name || '';
            document.getElementById('prof-email').value = p.email || '';
            document.getElementById('prof-phone').value = p.phone || '';
            document.getElementById('prof-address').value = p.default_address || '';
            document.getElementById('prof-company').value = p.company_name || '';
            document.getElementById('prof-window').value = p.preferred_window || '09:00 - 18:00';
        } catch (err) {
            console.error("Failed to load profile", err);
        }
    },

    async submitUpdateProfile(e) {
        e.preventDefault();
        try {
            await ApiClient.put('/api/customer/profile', {
                full_name: document.getElementById('prof-name').value,
                phone: document.getElementById('prof-phone').value,
                default_address: document.getElementById('prof-address').value,
                company_name: document.getElementById('prof-company').value,
                preferred_window: document.getElementById('prof-window').value
            });
            App.showToast("Profile settings saved successfully!", "success");
        } catch (err) {
            App.showToast("Failed to update profile: " + err.message, "danger");
        }
    }
};
