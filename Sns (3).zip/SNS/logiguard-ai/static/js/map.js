/**
 * LogiGuard AI - Leaflet Map Engine
 * Handles interactive Coimbatore logistics grid, vehicle markers, hazard zones, and dynamic reroute overlays.
 */

const MapEngine = {
    map: null,
    vehicleMarkers: {},
    hazardLayers: [],
    routeLayers: [],
    networkLayers: [],
    trackingLayerGroup: null,

    // Center on Coimbatore Logistics Hub
    DEFAULT_CENTER: [11.0168, 76.9558],
    DEFAULT_ZOOM: 12,

    init(containerId = "fleet-map") {
        const container = document.getElementById(containerId);
        if (!container) return null;

        // If map already initialized on this container, destroy and reinit
        if (this.map) {
            this.map.remove();
            this.map = null;
        }

        this.vehicleMarkers = {};
        this.hazardLayers = [];
        this.routeLayers = [];
        this.networkLayers = [];

        this.map = L.map(containerId, {
            zoomControl: true,
            attributionControl: true
        }).setView(this.DEFAULT_CENTER, this.DEFAULT_ZOOM);

        // Original OpenStreetMap tile layer
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(this.map);

        this.trackingLayerGroup = L.layerGroup().addTo(this.map);
        return this.map;
    },

    async renderNetworkGrid() {
        if (!this.map) return;
        try {
            const res = await fetch('/api/network/nodes').then(r => r.json());
            if (!res || !res.nodes) return;

            // Clear old network layers
            this.networkLayers.forEach(l => l.remove());
            this.networkLayers = [];

            // 1. Draw Road Graph Edges
            if (res.edges) {
                res.edges.forEach(e => {
                    const u = res.nodes[e.from];
                    const v = res.nodes[e.to];
                    if (u && v) {
                        const line = L.polyline([[u.lat, u.lng], [v.lat, v.lng]], {
                            color: '#475569',
                            weight: 2,
                            opacity: 0.5
                        }).addTo(this.map);
                        line.bindTooltip(e.name || `${u.name} ↔ ${v.name}`, { sticky: true });
                        this.networkLayers.push(line);
                    }
                });
            }

            // 2. Draw Logistics Hub Nodes
            Object.entries(res.nodes).forEach(([id, n]) => {
                const marker = L.circleMarker([n.lat, n.lng], {
                    radius: 4,
                    fillColor: '#0284c7',
                    color: '#ffffff',
                    weight: 1.5,
                    fillOpacity: 0.9
                }).addTo(this.map);
                marker.bindTooltip(`<b>${n.name}</b> (${id})`, { direction: 'top' });
                this.networkLayers.push(marker);
            });
        } catch (err) {
            console.warn("Could not render network grid:", err);
        }
    },

    createVehicleIcon(code, status, type = "van") {
        const isDelayed = status === "delayed";
        const isIdle = status === "idle";
        const color = isDelayed ? "#EF4444" : (isIdle ? "#94A3B8" : "#0066FF");
        const pulseClass = isDelayed ? "pulse-dot-red" : (isIdle ? "" : "pulse-dot-green");

        const iconHtml = `
            <div class="custom-vehicle-marker" style="
                background: #0E1A36;
                border: 2px solid ${color};
                border-radius: 8px;
                padding: 3px 6px;
                display: flex;
                align-items: center;
                gap: 4px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.5);
                color: #fff;
                font-family: 'JetBrains Mono', monospace;
                font-size: 11px;
                font-weight: 700;
                white-space: nowrap;
            ">
                <span class="${pulseClass}" style="width: 6px; height: 6px;"></span>
                <span>${code}</span>
            </div>
        `;

        return L.divIcon({
            html: iconHtml,
            className: 'vehicle-div-icon',
            iconSize: [60, 26],
            iconAnchor: [30, 13]
        });
    },

    renderVehicles(vehicles = []) {
        if (!this.map) return;

        // Clear existing markers
        Object.values(this.vehicleMarkers).forEach(m => m.remove());
        this.vehicleMarkers = {};

        vehicles.forEach(v => {
            const icon = this.createVehicleIcon(v.code, v.status, v.vehicle_type);
            const marker = L.marker([v.current_lat, v.current_lng], { icon })
                .bindPopup(`
                    <div style="font-family: 'Plus Jakarta Sans', sans-serif; color: #0F172A; min-width: 180px;">
                        <h4 style="margin: 0 0 4px 0; font-size: 14px; font-weight: 700; color: #0066FF;">${v.code} &bull; ${v.plate_number}</h4>
                        <p style="margin: 0 0 4px 0; font-size: 12px; color: #475569;">${v.vehicle_type}</p>
                        <div style="font-size: 11px; line-height: 1.4;">
                            <div><strong>Driver:</strong> ${v.driver_name || 'Assigned Driver'}</div>
                            <div><strong>Battery / Fuel:</strong> ${v.fuel_battery_percent}%</div>
                            <div><strong>Status:</strong> <span style="text-transform: capitalize; font-weight: 600; color: ${v.status === 'delayed' ? '#DC2626' : '#059669'};">${v.status.replace('_', ' ')}</span></div>
                        </div>
                    </div>
                `);

            marker.addTo(this.map);
            this.vehicleMarkers[v.id] = marker;
        });
    },

    renderDisruptionZone(lat, lng, radiusKm, title, severity = "critical") {
        if (!this.map) return;

        // Clear prior hazard layers
        this.hazardLayers.forEach(l => l.remove());
        this.hazardLayers = [];

        const color = severity === "critical" ? "#EF4444" : "#F59E0B";

        const circle = L.circle([lat, lng], {
            radius: radiusKm * 1000,
            color: color,
            fillColor: color,
            fillOpacity: 0.25,
            weight: 2,
            dashArray: '6, 6'
        }).bindPopup(`
            <div style="font-family: 'Plus Jakarta Sans', sans-serif; color: #0F172A;">
                <span style="background: #FEE2E2; color: #DC2626; font-size: 10px; font-weight: 700; padding: 2px 6px; border-radius: 4px; text-transform: uppercase;">Hazard Zone</span>
                <h4 style="margin: 4px 0; font-size: 13px; font-weight: 700;">${title}</h4>
                <p style="margin: 0; font-size: 11px; color: #475569;">Perimeter: ${radiusKm} km radius &bull; Reroute Active</p>
            </div>
        `);

        circle.addTo(this.map);
        this.hazardLayers.push(circle);

        // Add warning pulsating center marker
        const hazardMarker = L.circleMarker([lat, lng], {
            radius: 8,
            color: '#FFFFFF',
            fillColor: '#EF4444',
            fillOpacity: 1,
            weight: 2
        }).addTo(this.map);

        this.hazardLayers.push(hazardMarker);
    },

    renderRerouteComparison(origCoords = [], altCoords = []) {
        if (!this.map) return;

        // Clear prior routes
        this.routeLayers.forEach(l => l.remove());
        this.routeLayers = [];

        // 1. Render Original Blocked Route (Red Dashed)
        if (origCoords.length > 1) {
            const origPoints = origCoords.map(c => [c.lat, c.lng]);
            const origLine = L.polyline(origPoints, {
                color: '#EF4444',
                weight: 4,
                opacity: 0.8,
                dashArray: '8, 8'
            }).bindPopup("<b>Original Route: Blocked by Flooding</b>");

            origLine.addTo(this.map);
            this.routeLayers.push(origLine);
        }

        // 2. Render AI Recommended Bypass Route (Solid Green / Cyan)
        if (altCoords.length > 1) {
            const altPoints = altCoords.map(c => [c.lat, c.lng]);
            const altLine = L.polyline(altPoints, {
                color: '#10B981',
                weight: 5,
                opacity: 0.9
            }).bindPopup("<b>AI Recommended Bypass: Ganapathy Arterial Link (Optimal)</b>");

            altLine.addTo(this.map);
            this.routeLayers.push(altLine);

            this.map.fitBounds(altLine.getBounds(), { padding: [50, 50] });
        }
    },

    renderCustomerLiveTrack(pickup, delivery, livePos, status) {
        if (!this.map) return;

        this.trackingLayerGroup.clearLayers();

        // 1. Pickup Marker (Green)
        const pickupIcon = L.divIcon({
            html: `<div style="background: #10B981; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; border: 2px solid white; box-shadow: 0 4px 10px rgba(0,0,0,0.3); font-size: 13px;">📍</div>`,
            iconSize: [28, 28],
            iconAnchor: [14, 14]
        });
        L.marker([pickup.lat, pickup.lng], { icon: pickupIcon })
            .bindPopup(`<b>Pickup Location</b><br>${pickup.name}`)
            .addTo(this.trackingLayerGroup);

        // 2. Destination Marker (Red)
        const destIcon = L.divIcon({
            html: `<div style="background: #EF4444; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; border: 2px solid white; box-shadow: 0 4px 10px rgba(0,0,0,0.3); font-size: 13px;">🏁</div>`,
            iconSize: [28, 28],
            iconAnchor: [14, 14]
        });
        L.marker([delivery.lat, delivery.lng], { icon: destIcon })
            .bindPopup(`<b>Destination Address</b><br>${delivery.name}`)
            .addTo(this.trackingLayerGroup);

        // 3. Live Vehicle Position (Blue Truck Icon)
        const truckIcon = L.divIcon({
            html: `<div style="background: #0066FF; width: 34px; height: 34px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; border: 2px solid #38BDF8; box-shadow: 0 0 16px rgba(0,102,255,0.7); font-size: 16px;">🚚</div>`,
            iconSize: [34, 34],
            iconAnchor: [17, 17]
        });
        const vMarker = L.marker([livePos.lat, livePos.lng], { icon: truckIcon })
            .bindPopup(`<b>Live Delivery Vehicle</b><br>Status: ${status.toUpperCase()}`)
            .addTo(this.trackingLayerGroup);

        // Connect path
        const pathLine = L.polyline([[pickup.lat, pickup.lng], [livePos.lat, livePos.lng], [delivery.lat, delivery.lng]], {
            color: '#0066FF',
            weight: 4,
            dashArray: '5, 8'
        }).addTo(this.trackingLayerGroup);

        this.map.fitBounds(pathLine.getBounds(), { padding: [40, 40] });
    }
};
