/**
 * LogiGuard AI - Owner / Admin Operations Controller
 * Handles fleet telemetry (20 vehicles), order dispatch (100 orders), disruption simulation, AI plan approval.
 */

const OwnerController = {
    activeTab: 'overview',
    vehicles: [],
    orders: [],
    disruptions: [],
    currentAnalysis: null,

    async init() {
        this.bindEvents();
        await this.loadOverview();
    },

    bindEvents() {
        // Tab switching
        document.querySelectorAll('.owner-nav-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const tab = e.currentTarget.dataset.tab;
                this.switchTab(tab);
            });
        });

        // Search & Filter listeners
        const orderSearch = document.getElementById('owner-order-search');
        if (orderSearch) {
            orderSearch.addEventListener('input', () => this.filterOrders());
        }

        const statusFilter = document.getElementById('owner-order-status-filter');
        if (statusFilter) {
            statusFilter.addEventListener('change', () => this.filterOrders());
        }

        const priorityFilter = document.getElementById('owner-order-priority-filter');
        if (priorityFilter) {
            priorityFilter.addEventListener('change', () => this.filterOrders());
        }
    },

    switchTab(tabName) {
        this.activeTab = tabName;
        document.querySelectorAll('.owner-nav-btn').forEach(b => {
            b.classList.toggle('active', b.dataset.tab === tabName);
        });

        document.querySelectorAll('.owner-tab-content').forEach(c => {
            c.style.display = c.id === `owner-tab-${tabName}` ? 'block' : 'none';
        });

        if (tabName === 'overview') this.loadOverview();
        if (tabName === 'vehicles') this.loadVehicles();
        if (tabName === 'orders') this.loadOrders();
        if (tabName === 'disruptions') this.loadDisruptions();
        if (tabName === 'map') this.loadFleetMap();
        if (tabName === 'analytics') this.loadAnalytics();
        if (tabName === 'customers') this.loadCustomers();
    },

    async loadOverview() {
        try {
            const res = await ApiClient.get('/api/owner/overview');
            const m = res.metrics;

            document.getElementById('kpi-total-vehicles').innerText = m.total_vehicles;
            document.getElementById('kpi-active-deliveries').innerText = m.active_deliveries;
            document.getElementById('kpi-pending-orders').innerText = m.pending_orders;
            document.getElementById('kpi-delayed-deliveries').innerText = m.delayed_deliveries;
            document.getElementById('kpi-completed-deliveries').innerText = m.completed_deliveries;
            document.getElementById('kpi-on-time-sla').innerText = m.on_time_sla_rate + '%';

            // Disruption warning banner in overview
            const alertBanner = document.getElementById('owner-active-disruption-banner');
            if (m.delayed_deliveries > 0 || m.active_disruptions > 0) {
                alertBanner.style.display = 'flex';
                document.getElementById('overview-disruption-msg').innerHTML = `
                    <strong>⚠️ Active Disruption Detected:</strong> Avinashi Road Flyover Sector is waterlogged. 
                    ${m.delayed_deliveries} vehicles impacted. Urgent parcels flagged. 
                    <button class="btn btn-sm btn-primary" onclick="OwnerController.switchTab('disruptions')" style="margin-left: 10px;">Open AI Disruption Solver</button>
                `;
            } else {
                alertBanner.style.display = 'none';
            }

            // Quick load preview vehicles on overview map
            await this.loadVehicles(false);
            MapEngine.init("overview-fleet-map");
            await MapEngine.renderNetworkGrid();
            MapEngine.renderVehicles(this.vehicles.slice(0, 10));
        } catch (err) {
            console.error("Failed to load overview KPIs", err);
        }
    },

    async loadVehicles(renderTable = true) {
        try {
            const res = await ApiClient.get('/api/owner/vehicles');
            this.vehicles = res.vehicles || [];

            if (!renderTable) return;

            const tbody = document.getElementById('vehicles-table-body');
            if (!tbody) return;

            tbody.innerHTML = this.vehicles.map(v => {
                const isDelayed = v.status === 'delayed';
                const statusBadge = isDelayed ? 
                    '<span class="badge badge-danger"><span class="pulse-dot-red"></span> Delayed</span>' :
                    (v.status === 'in_transit' ? '<span class="badge badge-success"><span class="pulse-dot-green"></span> In Transit</span>' :
                    `<span class="badge badge-info">${v.status}</span>`);

                const batteryColor = v.fuel_battery_percent < 30 ? '#EF4444' : (v.fuel_battery_percent < 60 ? '#F59E0B' : '#10B981');

                return `
                    <tr>
                        <td>
                            <strong style="font-family: 'JetBrains Mono'; color: #38BDF8;">${v.code}</strong>
                            <div style="font-size: 11px; color: #94A3B8;">${v.plate_number}</div>
                        </td>
                        <td>${v.vehicle_type}</td>
                        <td>
                            <div><strong>${v.driver_name || 'Unassigned'}</strong></div>
                            <div style="font-size: 11px; color: #94A3B8;">⭐ ${v.driver_rating || '4.8'} &bull; ${v.driver_phone || ''}</div>
                        </td>
                        <td>
                            <div style="display: flex; align-items: center; gap: 8px;">
                                <div style="flex: 1; height: 6px; background: #1E293B; border-radius: 4px; overflow: hidden; min-width: 60px;">
                                    <div style="width: ${v.fuel_battery_percent}%; height: 100%; background: ${batteryColor};"></div>
                                </div>
                                <span style="font-size: 11px; font-weight: 700; color: ${batteryColor};">${v.fuel_battery_percent}%</span>
                            </div>
                        </td>
                        <td>${v.current_load_kg} / ${v.capacity_kg} kg</td>
                        <td>${statusBadge}</td>
                        <td>
                            <button class="btn btn-sm btn-outline" onclick="OwnerController.openEditVehicleModal(${v.id})" title="Edit Vehicle Status">⚙️ Edit</button>
                        </td>
                    </tr>
                `;
            }).join('');
        } catch (err) {
            console.error("Failed to load vehicles", err);
        }
    },

    async loadOrders() {
        try {
            const res = await ApiClient.get('/api/owner/orders');
            this.orders = res.orders || [];
            this.renderOrdersTable(this.orders);
        } catch (err) {
            console.error("Failed to load orders", err);
        }
    },

    renderOrdersTable(orderList) {
        const tbody = document.getElementById('orders-table-body');
        if (!tbody) return;

        tbody.innerHTML = orderList.map(o => {
            const isDelayed = o.status === 'delayed';
            const statusBadge = isDelayed ? 
                '<span class="badge badge-danger">⚠️ Delayed</span>' :
                (o.status === 'delivered' ? '<span class="badge badge-success">✓ Delivered</span>' :
                (o.status === 'in_transit' ? '<span class="badge badge-info">🚚 In Transit</span>' :
                `<span class="badge badge-purple">${o.status.replace('_', ' ')}</span>`));

            const priorityBadge = o.priority === 'urgent_medical' ?
                '<span class="badge badge-danger">🚨 Urgent Medical</span>' :
                (o.priority === 'express' ? '<span class="badge badge-warning">⚡ Express</span>' : '<span class="badge badge-info">Standard</span>');

            const etaDisplay = o.revised_eta ? new Date(o.revised_eta).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : 'Pending';

            return `
                <tr>
                    <td>
                        <strong style="font-family: 'JetBrains Mono'; color: #38BDF8;">${o.order_code}</strong>
                        <div style="font-size: 11px; color: #94A3B8;">${new Date(o.created_at).toLocaleDateString()}</div>
                    </td>
                    <td>
                        <div><strong>${o.customer_name}</strong></div>
                        <div style="font-size: 11px; color: #94A3B8;">To: ${o.recipient_name}</div>
                    </td>
                    <td>${priorityBadge}</td>
                    <td>
                        <span style="font-family: 'JetBrains Mono'; font-weight: 600;">${o.vehicle_code || '<span style="color:#EF4444;">Unassigned</span>'}</span>
                    </td>
                    <td>
                        <div>${etaDisplay}</div>
                        ${o.delay_minutes > 0 ? `<span style="font-size: 10px; color: #EF4444; font-weight: 700;">+${o.delay_minutes}m delay</span>` : ''}
                    </td>
                    <td>${statusBadge}</td>
                    <td>
                        <button class="btn btn-sm btn-outline" onclick="OwnerController.openAssignVehicleModal(${o.id})" title="Assign Vehicle">🚚 Assign</button>
                        <button class="btn btn-sm btn-primary" onclick="App.trackOrderDirectly('${o.order_code}')" title="Track Live">🗺️ Track</button>
                    </td>
                </tr>
            `;
        }).join('');
    },

    filterOrders() {
        const searchVal = (document.getElementById('owner-order-search')?.value || '').toLowerCase();
        const statusVal = document.getElementById('owner-order-status-filter')?.value || '';
        const priorityVal = document.getElementById('owner-order-priority-filter')?.value || '';

        const filtered = this.orders.filter(o => {
            const matchesSearch = !searchVal || 
                o.order_code.toLowerCase().includes(searchVal) ||
                o.customer_name.toLowerCase().includes(searchVal) ||
                o.delivery_address.toLowerCase().includes(searchVal);

            const matchesStatus = !statusVal || o.status === statusVal;
            const matchesPriority = !priorityVal || o.priority === priorityVal;

            return matchesSearch && matchesStatus && matchesPriority;
        });

        this.renderOrdersTable(filtered);
    },

    async loadDisruptions() {
        try {
            const res = await ApiClient.get('/api/owner/disruptions');
            this.disruptions = res.disruptions || [];

            const container = document.getElementById('disruptions-cards-container');
            if (!container) return;

            container.innerHTML = this.disruptions.map(d => {
                const isCrit = d.severity === 'critical';
                const sevBadge = isCrit ? '<span class="badge badge-danger">CRITICAL HAZARD</span>' : `<span class="badge badge-warning">${d.severity.toUpperCase()}</span>`;
                
                return `
                    <div class="glass-panel" style="padding: 1.5rem; border-left: 4px solid ${isCrit ? '#EF4444' : '#F59E0B'};">
                        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.75rem;">
                            <div>
                                <span style="font-family: 'JetBrains Mono'; font-size: 11px; color: #94A3B8;">${d.code}</span>
                                <h3 style="font-size: 1.15rem; font-weight: 700; margin: 4px 0;">${d.title}</h3>
                            </div>
                            ${sevBadge}
                        </div>
                        <p style="font-size: 0.9rem; color: #94A3B8; margin-bottom: 1rem;">${d.description}</p>
                        <div style="font-size: 0.85rem; color: #CBD5E1; margin-bottom: 1.25rem;">
                            <div>📍 <strong>Location:</strong> ${d.location_name} (Radius: ${d.radius_km} km)</div>
                            <div>⚡ <strong>Type:</strong> ${d.disruption_type.replace('_', ' ').toUpperCase()}</div>
                        </div>
                        <div style="display: flex; gap: 0.75rem;">
                            <button class="btn btn-primary btn-sm" onclick="OwnerController.runDisruptionAnalysis(${d.id})">
                                🧠 Run AI Impact & Reroute Solver
                            </button>
                        </div>
                    </div>
                `;
            }).join('');

            // Auto run analysis on first active disruption
            if (this.disruptions.length > 0) {
                this.runDisruptionAnalysis(this.disruptions[0].id);
            }
        } catch (err) {
            console.error("Failed to load disruptions", err);
        }
    },

    async runDisruptionAnalysis(disruptionId) {
        try {
            App.showToast("Analyzing logistics disruption impact with Dijkstra solver...", "info");
            const res = await ApiClient.get(`/api/owner/disruptions/${disruptionId}/analysis`);
            this.currentAnalysis = res;

            document.getElementById('ai-analysis-results-section').style.display = 'block';
            document.getElementById('analysis-affected-vehicles-count').innerText = res.affected_vehicles_count;
            document.getElementById('analysis-affected-orders-count').innerText = res.affected_orders_count;
            document.getElementById('analysis-avg-delay').innerText = res.average_delay_mins + ' mins';

            // Render recommendations
            const recContainer = document.getElementById('ai-recommendations-list');
            recContainer.innerHTML = res.recommendations.map((rec, idx) => `
                <div class="glass-panel" style="padding: 1.25rem; border: 1px solid ${idx === 0 ? '#10B981' : 'var(--border-color)'};">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                        <span class="badge ${idx === 0 ? 'badge-success' : 'badge-info'}">${rec.badge}</span>
                        <span style="font-family: 'JetBrains Mono'; font-weight: 700; color: #10B981;">Score: ${rec.score}%</span>
                    </div>
                    <h4 style="font-size: 1.05rem; font-weight: 700; margin-bottom: 0.35rem;">${rec.title}</h4>
                    <p style="font-size: 0.85rem; color: #94A3B8; margin-bottom: 0.75rem;">${rec.description}</p>
                    <ul style="font-size: 0.82rem; color: #CBD5E1; padding-left: 1.2rem; margin-bottom: 1rem;">
                        ${rec.benefits.map(b => `<li>${b}</li>`).join('')}
                    </ul>
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span style="font-size: 11px; color: #38BDF8; font-weight: 600;">Delay mitigation: ${rec.estimated_delay_mitigation}</span>
                        <button class="btn btn-sm btn-primary" onclick="OwnerController.openApplyPlanModal('${rec.id}', '${rec.title}')">
                            ✓ Select & Review Plan
                        </button>
                    </div>
                </div>
            `).join('');

            // Update disruption interactive map
            MapEngine.init("disruption-simulation-map");
            await MapEngine.renderNetworkGrid();
            const d = res.disruption;
            MapEngine.renderDisruptionZone(d.lat, d.lng, d.radius_km, d.title, d.severity);
            
            if (res.proposed_reroutes && res.proposed_reroutes.length > 0) {
                const firstReroute = res.proposed_reroutes[0];
                MapEngine.renderRerouteComparison(firstReroute.original_coordinates, firstReroute.alternative_coordinates);
            }
        } catch (err) {
            console.error("AI Analysis failed", err);
            App.showToast("Failed to run AI solver: " + err.message, "danger");
        }
    },

    openApplyPlanModal(recId, recTitle) {
        if (!this.currentAnalysis) return;

        const modal = document.getElementById('apply-plan-modal');
        document.getElementById('plan-modal-rec-title').innerText = recTitle;
        document.getElementById('plan-modal-vehicles-count').innerText = this.currentAnalysis.affected_vehicles_count;
        document.getElementById('plan-modal-orders-count').innerText = this.currentAnalysis.affected_orders_count;
        document.getElementById('plan-modal-delay-recovery').innerText = `Reduces delay from ${this.currentAnalysis.average_delay_mins}m to 14m`;

        modal.dataset.recId = recId;
        modal.dataset.disruptionId = this.currentAnalysis.disruption.id;
        modal.classList.add('active');
    },

    async confirmApplyPlan() {
        const modal = document.getElementById('apply-plan-modal');
        const dId = modal.dataset.disruptionId;
        const recId = modal.dataset.recId;

        try {
            App.showToast("Broadcasting revised routing plan to drivers & customers...", "info");
            const res = await ApiClient.post(`/api/owner/disruptions/${dId}/apply-plan`, { recommendation_id: recId });
            modal.classList.remove('active');
            
            App.showToast(res.message, "success");
            await this.loadOverview();
            await this.loadOrders();
            this.switchTab('overview');
        } catch (err) {
            App.showToast("Failed to apply plan: " + err.message, "danger");
        }
    },

    async loadFleetMap() {
        await this.loadVehicles(false);
        MapEngine.init("fleet-full-map");
        await MapEngine.renderNetworkGrid();
        MapEngine.renderVehicles(this.vehicles);
    },

    async loadAnalytics() {
        try {
            const res = await ApiClient.get('/api/owner/analytics');
            ChartsEngine.renderAll(res);
            document.getElementById('analytics-co2-saved').innerText = res.co2_saved_kg + ' kg';
            document.getElementById('analytics-km-optimized').innerText = res.total_optimized_km.toLocaleString() + ' km';
        } catch (err) {
            console.error("Failed to load analytics", err);
        }
    },

    async loadCustomers() {
        try {
            const res = await ApiClient.get('/api/owner/customers');
            const tbody = document.getElementById('customers-table-body');
            if (!tbody) return;

            tbody.innerHTML = (res.customers || []).map(c => `
                <tr>
                    <td><strong>${c.full_name}</strong></td>
                    <td>${c.company_name || 'Standard Account'}</td>
                    <td>
                        <div>${c.email}</div>
                        <div style="font-size: 11px; color: #94A3B8;">${c.phone || '-'}</div>
                    </td>
                    <td>${c.city || 'Coimbatore'}</td>
                    <td><strong style="color: #38BDF8;">${c.total_orders}</strong></td>
                    <td>
                        <span class="badge badge-success">${c.completed_orders}</span>
                        ${c.delayed_orders > 0 ? `<span class="badge badge-danger">${c.delayed_orders} delayed</span>` : ''}
                    </td>
                </tr>
            `).join('');
        } catch (err) {
            console.error("Failed to load customers", err);
        }
    },

    openAddVehicleModal() {
        document.getElementById('add-vehicle-modal').classList.add('active');
    },

    async submitAddVehicle(e) {
        e.preventDefault();
        const code = document.getElementById('new-vehicle-code').value;
        const plate = document.getElementById('new-vehicle-plate').value;
        const vtype = document.getElementById('new-vehicle-type').value;
        const cap = document.getElementById('new-vehicle-cap').value;

        try {
            await ApiClient.post('/api/owner/vehicles', {
                code: code,
                plate_number: plate,
                vehicle_type: vtype,
                capacity_kg: parseFloat(cap)
            });
            document.getElementById('add-vehicle-modal').classList.remove('active');
            App.showToast(`Vehicle ${code} added to fleet!`, "success");
            await this.loadVehicles();
        } catch (err) {
            App.showToast(err.message, "danger");
        }
    },

    openEditVehicleModal(vId) {
        const v = this.vehicles.find(item => item.id === vId);
        if (!v) return;

        document.getElementById('edit-vehicle-id').value = v.id;
        document.getElementById('edit-vehicle-code-title').innerText = v.code;
        document.getElementById('edit-vehicle-status').value = v.status;
        document.getElementById('edit-vehicle-battery').value = v.fuel_battery_percent;
        document.getElementById('edit-vehicle-modal').classList.add('active');
    },

    async submitEditVehicle(e) {
        e.preventDefault();
        const vId = document.getElementById('edit-vehicle-id').value;
        const status = document.getElementById('edit-vehicle-status').value;
        const battery = document.getElementById('edit-vehicle-battery').value;

        try {
            await ApiClient.put(`/api/owner/vehicles/${vId}`, {
                status: status,
                fuel_battery_percent: parseInt(battery)
            });
            document.getElementById('edit-vehicle-modal').classList.remove('active');
            App.showToast("Vehicle updated successfully!", "success");
            await this.loadVehicles();
        } catch (err) {
            App.showToast(err.message, "danger");
        }
    },

    openAssignVehicleModal(orderId) {
        const modal = document.getElementById('assign-vehicle-modal');
        modal.dataset.orderId = orderId;

        const select = document.getElementById('assign-vehicle-select');
        select.innerHTML = this.vehicles.map(v => `
            <option value="${v.id}">${v.code} &bull; ${v.vehicle_type} (${v.status})</option>
        `).join('');

        modal.classList.add('active');
    },

    async submitAssignVehicle() {
        const modal = document.getElementById('assign-vehicle-modal');
        const orderId = modal.dataset.orderId;
        const vehicleId = document.getElementById('assign-vehicle-select').value;

        try {
            await ApiClient.put(`/api/owner/orders/${orderId}/assign`, { vehicle_id: parseInt(vehicleId) });
            modal.classList.remove('active');
            App.showToast("Vehicle assigned to order successfully!", "success");
            await this.loadOrders();
        } catch (err) {
            App.showToast(err.message, "danger");
        }
    }
};
