# 🚀 LogiGuard AI — Disruption-Aware Logistics Planning System
> **Autonomous Multi-Role Disruption Resilience & Real-Time Fleet Optimization Platform** &bull; Intelligent route re-planning, cascade delay mitigation, and transparent customer tracking.

---

## 🌟 Executive Overview: The Three Critical Questions

When real-time disruptions (flash floods, arterial road closures, flyover construction blockades, or vehicle powertrain breakdowns) strike an urban logistics network, **LogiGuard AI** autonomously answers:

| Core Question | LogiGuard AI Module | Key Capabilities |
| :--- | :--- | :--- |
| **1. What changed?** | **Module A: Disruption Center** | Sub-second anomaly ingestion, root-cause telemetry, hazard zone radius modeling, and scenario simulation. |
| **2. What is affected?** | **Module B: Cascade Impact DAG** | Real-time calculation of delayed vehicles, at-risk urgent medical/cold-chain parcels, customer SLA breach %, and graph trajectory analysis. |
| **3. What should they do next?** | **Module C: AI Decision Engine** | 3 actionable resolution strategies (Dynamic Arterial Bypass, Mid-Route Rendezvous Intercept, and Customer Window Reschedule) with 1-click driver sync. |

---

## 💻 Tech Stack & System Architecture

- **Backend**: Python 3.14 Flask RESTful API, Werkzeug Security PBKDF2 password hashing, token-based session management, role-based decorators (`@role_required`).
- **Database**: SQLite with strict relational foreign keys, performance indexes (`idx_orders_customer`, `idx_orders_status`, `idx_vehicles_status`), and automated migrations.
- **AI Routing Engine**: Dijkstra / A* Shortest-Path Graph Solver over a 20-node Coimbatore metropolitan logistics network, calculating congestion-weighted alternative bypass routes.
- **Frontend**: Single Page Application (SPA) with a modern Dark Navy & Cobalt Blue glassmorphic theme (`#0B132B`, `#0066FF`, `#38BDF8`), Leaflet.js interactive maps, Chart.js analytics visualizer, and mobile-responsive layouts.

---

## 👑 Multi-Role Capabilities

### 1. Fleet Owner / Admin Dashboard
- **Operations Overview**: High-level KPIs (Total Vehicles 20, Active Deliveries, Pending Orders, Delayed Deliveries, Completed Shipments, On-Time SLA %).
- **Fleet Management (20 Units)**: Live battery/fuel bars, driver assignment, cargo weight vs. capacity tracking, and status editor (In Transit, Delayed, Idle, Maintenance).
- **Order Dispatch (100 Orders)**: Filter by status, priority (Urgent Medical, Express, Standard), text search, vehicle assignment modal, and delivery updates.
- **AI Disruption Center**: One-click scenario injectors (Avinashi Road Flash Flood, Airport Cargo Inbound Jam, Peelamedu Pipeline Shutdown).
- **Route Optimizer Map**: Fullscreen Leaflet map displaying live vehicle coordinates, pulsating hazard perimeters, original blocked routes (dashed red), and AI bypass routes (solid emerald green).
- **Reports & Analytics**: Weekly SLA trend lines, package distribution doughnuts, and vehicle capacity utilization metrics.
- **Customer Directory**: Registered client accounts, contact details, total orders placed, and fulfillment rates.

### 2. Customer Portal
- **Strict Data Isolation**: Customers can strictly view and track only their own orders.
- **Place New Order**: Instant booking with pickup/dropoff selection, consignment type, weight, priority tier (Standard / Express / Urgent Medical), and real-time fare estimator.
- **Live Consignment Tracking Studio**:
  - 6-stage visual timeline stepper (*Order Placed &rarr; Confirmed &rarr; Assigned &rarr; In Transit &rarr; Delayed/Rerouted &rarr; Delivered*).
  - Interactive Leaflet tracking map with pickup marker, destination marker, live truck beacon, and driver card (*Driver Name, Rating, Phone, Vehicle Code*).
  - Transparent Disruption Alert Banner displaying real-time reasons for revised ETAs.
- **Disruption Notifications**: Time-stamped feed of delay warnings and automated reroute notices.
- **Order Management & Cancellation**: Cancel orders in eligible statuses (*Order Placed / Confirmed*).
- **Profile Settings**: Update contact information, organization name, and preferred receiving windows.

---

## ⚡ Quick Start & Running Locally

### Option 1: One-Click Launch (Windows)
Double-click `run.bat` in the workspace root, or execute in PowerShell:
```powershell
& "C:\Users\pravi\AppData\Local\Python\bin\python.exe" "c:\Users\pravi\OneDrive\Documents\SNS\logiguard-ai\run_server.py"
```

### Option 2: Access Application
- 🌐 **Web Dashboard & Landing Page**: [http://localhost:8000](http://localhost:8000)
- 🔌 **API Health Endpoint**: [http://localhost:8000/api/health](http://localhost:8000/api/health)

---

## 🔑 Preloaded Demo Credentials

| Role | Email | Password | Preloaded Scenarios |
| :--- | :--- | :--- | :--- |
| **👑 Fleet Owner / Admin** | `admin@logiguard.ai` | `admin123` | Full access to 20 vehicles, 100 orders, AI Disruption Solver |
| **📦 Customer 1 (Medical)** | `john.doe@example.com` | `customer123` | Urgent Cold-Chain Vaccines & Medical Consignments |
| **📦 Customer 2 (Express)** | `priya.sharma@example.com` | `customer123` | High-Precision Electronics & Express Parcels |

---

## 🏆 Hackathon Demonstration Flow (Step-by-Step)

1. **Open the Landing Page** at [http://localhost:8000](http://localhost:8000).
2. Click **"🚀 1-Click Hackathon Demo"** on the hero banner.
3. Observe the system automatically:
   - Authenticate as the **Fleet Owner**.
   - Simulate the **Avinashi Road Flash Flood / Flyover Blockade** (`DIS-AVINASHI-01`).
   - Identify 3 affected vehicles (V-101, V-102, V-105) and 8 delayed customer orders.
   - Run the **Dijkstra Shortest-Path Graph Solver** to calculate the **Ganapathy-Vilankurichi Arterial Bypass**.
4. Click **"✓ Select & Review Plan"** and then **"Approve & Execute Plan"**.
5. Switch to the **Customer Portal** (`john.doe@example.com` / `customer123`).
6. Click **"Live Track"** on order `#ORD-7001` to view:
   - The updated ETA (+14 mins instead of +35 mins).
   - The transparent Disruption Alert Banner explaining the arterial bypass.
   - The live vehicle moving along the safe corridor on the map.
