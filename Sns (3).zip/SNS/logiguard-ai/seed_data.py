"""
LogiGuard AI - Seed Data Generator
Populates realistic demo fleet (20 vehicles), 100 orders, disruptions, drivers, and accounts.
"""

import json
import random
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash
from database import get_db_connection, init_db

COIMBATORE_LOCATIONS = [
    {"name": "Gandhipuram Logistics Hub", "lat": 11.0168, "lng": 76.9558, "city": "Coimbatore"},
    {"name": "Peelamedu Tech Park", "lat": 11.0285, "lng": 76.9995, "city": "Coimbatore"},
    {"name": "Hope College Commercial", "lat": 11.0345, "lng": 77.0182, "city": "Coimbatore"},
    {"name": "Coimbatore Airport Cargo Terminal", "lat": 11.0300, "lng": 77.0434, "city": "Coimbatore"},
    {"name": "Singanallur Industrial Estate", "lat": 10.9990, "lng": 77.0160, "city": "Coimbatore"},
    {"name": "Ramanathapuram Market", "lat": 10.9935, "lng": 76.9850, "city": "Coimbatore"},
    {"name": "Ukkadam Bus Terminal", "lat": 10.9880, "lng": 76.9605, "city": "Coimbatore"},
    {"name": "RS Puram Shopping District", "lat": 11.0110, "lng": 76.9450, "city": "Coimbatore"},
    {"name": "Saibaba Colony Junction", "lat": 11.0260, "lng": 76.9410, "city": "Coimbatore"},
    {"name": "Ganapathy Industrial Zone", "lat": 11.0410, "lng": 76.9740, "city": "Coimbatore"},
    {"name": "Saravanampatti SEZ IT Hub", "lat": 11.0800, "lng": 76.9950, "city": "Coimbatore"},
    {"name": "Thudiyalur Agro Complex", "lat": 11.0760, "lng": 76.9380, "city": "Coimbatore"},
    {"name": "Sundarapuram Heavy Engineering", "lat": 10.9520, "lng": 76.9720, "city": "Coimbatore"},
    {"name": "Kovaipudur Residential Sector", "lat": 10.9380, "lng": 76.9320, "city": "Coimbatore"},
    {"name": "Vilankurichi Tech Corridor", "lat": 11.0620, "lng": 77.0190, "city": "Coimbatore"},
    {"name": "Ondipudur Railway Siding", "lat": 10.9950, "lng": 77.0510, "city": "Coimbatore"},
    {"name": "Sulur Airfield Zone", "lat": 11.0250, "lng": 77.1260, "city": "Coimbatore"},
    {"name": "Vadavalli Hills Colony", "lat": 11.0250, "lng": 76.8950, "city": "Coimbatore"},
    {"name": "Perur Temple Road", "lat": 10.9720, "lng": 76.9180, "city": "Coimbatore"},
    {"name": "Avinashi Road Flyover Sector", "lat": 11.0220, "lng": 76.9780, "city": "Coimbatore"}
]

PACKAGE_DESCRIPTIONS = [
    ("Urgent Insulin & Vaccines (2-8°C Cold Chain)", "Medical Supplies", "urgent_medical", 4.5),
    ("Cardiac Monitors & Defibrillators", "Medical Supplies", "urgent_medical", 12.0),
    ("Fresh Organic Dairy & Cold Press Goods", "Perishable / Cold-Chain", "express", 25.0),
    ("High-Precision Optical Sensors", "High-Value Electronics", "express", 8.2),
    ("Industrial CNC Spindle Replacement", "Heavy Freight", "standard", 85.0),
    ("Lithium-Ion Drone Battery Packs", "High-Value Electronics", "express", 14.5),
    ("Critical Legal Deeds & Commercial Contracts", "Priority Documents", "express", 1.2),
    ("Textile Weaving Machine Spare Parts", "Heavy Freight", "standard", 65.0),
    ("Specialized Surgical Orthopedic Implants", "Medical Supplies", "urgent_medical", 3.8),
    ("Hydraulic Pump Assembly Kit", "Heavy Freight", "standard", 48.0),
    ("Consumer Laptop & Tablet Consignment", "High-Value Electronics", "standard", 32.0),
    ("Lab Reagents & Diagnostic Test Kits", "Medical Supplies", "urgent_medical", 6.0),
    ("Pharmaceutical Ampoules Batch", "Medical Supplies", "urgent_medical", 9.5),
    ("Automotive ECU Microcontrollers", "High-Value Electronics", "express", 5.4),
    ("Artisan Bakery & Confectionery Crates", "Perishable / Cold-Chain", "standard", 18.0)
]

def seed_database():
    """Wipes and reseeds the entire database with realistic production-grade mock data."""
    init_db()
    conn = get_db_connection()
    cursor = conn.cursor()

    # Clear existing data
    tables = [
        "notifications", "delivery_plan_changes", "deliveries", "orders", 
        "vehicles", "drivers", "routes", "disruptions", "customer_profiles", "users"
    ]
    for table in tables:
        cursor.execute(f"DELETE FROM {table};")
        cursor.execute(f"DELETE FROM sqlite_sequence WHERE name='{table}';")

    print("[SEED] Cleared existing tables.")

    # 1. Seed Users (Owner + Customers)
    owner_pwd = generate_password_hash("admin123")
    cust_pwd = generate_password_hash("customer123")

    users_data = [
        ("admin@logiguard.ai", owner_pwd, "owner", "Marcus Vance (Chief Fleet Officer)", "+91 98450 11001", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150"),
        ("john.doe@example.com", cust_pwd, "customer", "Dr. John Doe (Apex Healthcare Labs)", "+91 98765 43210", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150"),
        ("priya.sharma@example.com", cust_pwd, "customer", "Priya Sharma (NexGen Electronics)", "+91 94433 22110", "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150"),
        ("arun.kumar@example.com", cust_pwd, "customer", "Arun Kumar (Kovai Textiles Hub)", "+91 91234 56780", None),
        ("kavitha.m@example.com", cust_pwd, "customer", "Kavitha Murugan (FreshBio Organics)", "+91 98421 99887", None),
        ("rajesh.n@example.com", cust_pwd, "customer", "Rajesh Nambiar (Titan Precision Parts)", "+91 97890 12345", None),
        ("sneha.patel@example.com", cust_pwd, "customer", "Sneha Patel (PharmaDirect Coimbatore)", "+91 96550 44332", None),
        ("anand.r@example.com", cust_pwd, "customer", "Anand Ramakrishnan (Air Cargo Logistics)", "+91 94880 77665", None),
        ("divya.s@example.com", cust_pwd, "customer", "Divya Sundaram (SmartTech Solutions)", "+91 99400 11223", None),
        ("vikram.s@example.com", cust_pwd, "customer", "Vikram Sethi (Aerospace Precision Labs)", "+91 98940 55667", None),
        ("meena.k@example.com", cust_pwd, "customer", "Meena Krishnan (Coimbatore Agro Exports)", "+91 97500 88990", None),
    ]

    for email, pwd, role, name, phone, avatar in users_data:
        cursor.execute("""
            INSERT INTO users (email, password_hash, role, full_name, phone, avatar_url)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (email, pwd, role, name, phone, avatar))

    # Customer Profiles
    customer_ids = [row["id"] for row in cursor.execute("SELECT id FROM users WHERE role='customer'").fetchall()]
    for cid in customer_ids:
        cursor.execute("""
            INSERT INTO customer_profiles (user_id, default_address, city, postal_code, company_name, preferred_window)
            VALUES (?, '104 Avinashi Road, Peelamedu', 'Coimbatore', '641004', 'Corporate Logistics Partner', '08:00 - 18:00')
        """, (cid,))

    # 2. Seed Drivers (20 Professional Drivers)
    driver_names = [
        "Karthik Selvan", "Manojkumar R.", "Ramesh B.", "Deepak Sundaram",
        "Suresh Kumar", "Balaji Krishnan", "Ganesh Moorthy", "Vigneshwaran P.",
        "Dinesh Babu", "Praveenraj V.", "Saravanan T.", "Anbarasan K.",
        "Gokulnath S.", "Naveen Prakash", "Pradeep Chandran", "Vijay Anand",
        "Senthil Nathan", "Muruganandam A.", "Harishankar V.", "Ravichandran M."
    ]
    for i, name in enumerate(driver_names, 1):
        phone = f"+91 984{random.randint(10,99)} {random.randint(10000,99999)}"
        lic = f"TN-38-{2015 + (i % 8)}-{random.randint(1000000, 9999999)}"
        cursor.execute("""
            INSERT INTO drivers (name, phone, license_no, experience_years, rating, status)
            VALUES (?, ?, ?, ?, ?, 'assigned')
        """, (name, phone, lic, random.randint(3, 14), round(random.uniform(4.6, 5.0), 1)))

    # 3. Seed Vehicles (20 Fleet Units)
    v_types = [
        ("EV Van (Autonomous Pilot)", 1200),
        ("Refrigerated Cold-Chain Van", 1500),
        ("Heavy Freight Truck", 4500),
        ("Express Courier EV Bike", 150),
        ("Urban Delivery Van", 1800)
    ]

    vehicle_locations = [
        (11.0168, 76.9558), (11.0220, 76.9780), (11.0285, 76.9995), (11.0345, 77.0182),
        (11.0300, 77.0434), (10.9990, 77.0160), (10.9935, 76.9850), (10.9880, 76.9605),
        (11.0110, 76.9450), (11.0260, 76.9410), (11.0410, 76.9740), (11.0800, 76.9950),
        (11.0760, 76.9380), (10.9520, 76.9720), (10.9380, 76.9320), (11.0620, 77.0190),
        (10.9950, 77.0510), (11.0250, 77.1260), (11.0250, 76.8950), (10.9720, 76.9180)
    ]

    for i in range(1, 21):
        v_code = f"V-{100 + i}"
        plate = f"TN-38-BZ-{1000 + i}"
        vt, cap = v_types[i % len(v_types)]
        lat, lng = vehicle_locations[i - 1]
        
        # Vehicles near Avinashi road start as in_transit or delayed
        v_status = "delayed" if i in (1, 2, 5) else ("in_transit" if i <= 15 else "idle")
        load = round(random.uniform(0.4, 0.85) * cap, 1) if v_status != "idle" else 0
        battery = random.randint(55, 98)

        cursor.execute("""
            INSERT INTO vehicles (code, plate_number, vehicle_type, capacity_kg, current_load_kg, fuel_battery_percent, driver_id, status, current_lat, current_lng)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (v_code, plate, vt, cap, load, battery, i, v_status, lat, lng))

    # 4. Seed Disruptions
    disruptions_data = [
        (
            "DIS-AVINASHI-01",
            "Avinashi Road Flyover Construction Blockade & Flash Waterlogging",
            "road_closure",
            "critical",
            "Avinashi Road Flyover Corridor (Lakshmi Mills to Peelamedu)",
            11.0220, 76.9780,
            1.8,
            "Major arterial road completely blocked due to storm drainage rupture and deep waterlogging between Node 12 and Node 2. Heavy freight and light vehicles immobilized.",
            1
        ),
        (
            "DIS-AIRPORT-02",
            "Coimbatore Airport Cargo Inbound Gate Congestion",
            "traffic_congestion",
            "high",
            "SITRA Airport Terminal Road",
            11.0300, 77.0434,
            1.2,
            "Customs clearing bottleneck causing 45-minute truck queue on Inbound Lane 3.",
            0
        ),
        (
            "DIS-PEELAMEDU-03",
            "Gas Pipeline Repair Emergency Shutdown",
            "accident",
            "moderate",
            "Peelamedu Tech Zone Junction",
            11.0285, 76.9995,
            0.8,
            "City municipal team executing emergency valve welding. Single-lane slow passage.",
            0
        ),
        (
            "DIS-GANDHIPURAM-04",
            "Gandhipuram Central Signal Failure Gridlock",
            "traffic_congestion",
            "high",
            "Gandhipuram Bus Complex Crossing",
            11.0168, 76.9558,
            1.0,
            "Traffic controller malfunction leading to multi-spoke arterial gridlock.",
            0
        )
    ]

    for code, title, dtype, sev, loc_name, lat, lng, radius, desc, is_act in disruptions_data:
        cursor.execute("""
            INSERT INTO disruptions (code, title, disruption_type, severity, location_name, lat, lng, radius_km, description, is_active)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (code, title, dtype, sev, loc_name, lat, lng, radius, desc, is_act))

    # 5. Seed Routes
    routes_data = [
        ("RT-101", "Central Avinashi Express Route", "Gandhipuram Hub", 11.0168, 76.9558, "Airport Cargo", 11.0300, 77.0434, 11.2, 28, 1, "Blocked by Avinashi Waterlogging"),
        ("RT-102", "Ganapathy-Vilankurichi Arterial Bypass", "Gandhipuram Hub", 11.0168, 76.9558, "Airport Cargo", 11.0300, 77.0434, 14.5, 34, 0, None),
        ("RT-103", "Trichy Road Southern Bypass", "Gandhipuram Hub", 11.0168, 76.9558, "Sulur Base", 11.0250, 77.1260, 16.8, 38, 0, None),
        ("RT-104", "Saravanampatti Tech Corridor Line", "Saibaba Colony", 11.0260, 76.9410, "Saravanampatti SEZ", 11.0800, 76.9950, 9.4, 22, 0, None),
        ("RT-105", "Sundarapuram - Kovaipudur Circuit", "Ukkadam Hub", 10.9880, 76.9605, "Kovaipudur Depot", 10.9380, 76.9320, 10.2, 24, 0, None)
    ]

    for code, name, o_name, o_lat, o_lng, d_name, d_lat, d_lng, dist, time_m, is_blk, blk_res in routes_data:
        wp = [{"lat": o_lat, "lng": o_lng}, {"lat": (o_lat+d_lat)/2, "lng": (o_lng+d_lng)/2}, {"lat": d_lat, "lng": d_lng}]
        cursor.execute("""
            INSERT INTO routes (code, name, origin_name, origin_lat, origin_lng, dest_name, dest_lat, dest_lng, waypoints_json, distance_km, estimated_time_mins, is_blocked, blocked_reason)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (code, name, o_name, o_lat, o_lng, d_name, d_lat, d_lng, json.dumps(wp), dist, time_m, is_blk, blk_res))

    # 6. Seed 100 Realistic Customer Orders
    now = datetime.now()
    statuses = ["in_transit", "in_transit", "in_transit", "assigned", "confirmed", "order_placed", "delivered", "delivered"]
    
    # Ensure John Doe (user_id=2) and Priya Sharma (user_id=3) have distinct urgent & tracked orders
    print("[SEED] Generating 100 realistic logistics orders...")

    for i in range(1, 101):
        order_code = f"ORD-{7000 + i}"
        
        # Distribute orders: 20 to John Doe, 15 to Priya Sharma, rest spread over other customers
        if i <= 20:
            c_id = 2 # John Doe
        elif i <= 35:
            c_id = 3 # Priya Sharma
        else:
            c_id = customer_ids[i % len(customer_ids)]

        pkg_desc, pkg_type, priority, weight = PACKAGE_DESCRIPTIONS[i % len(PACKAGE_DESCRIPTIONS)]
        
        pickup_loc = COIMBATORE_LOCATIONS[i % len(COIMBATORE_LOCATIONS)]
        deliv_loc = COIMBATORE_LOCATIONS[(i + 5) % len(COIMBATORE_LOCATIONS)]

        v_id = ((i - 1) % 20) + 1
        
        # Specific status distribution
        if i in (1, 2, 3, 4, 5, 6, 7):
            status = "delayed" if i in (1, 2, 5) else "in_transit"
        elif i > 85:
            status = "delivered"
        elif i > 70:
            status = "order_placed"
        elif i > 55:
            status = "confirmed"
        else:
            status = "in_transit"

        eta_offset_mins = random.randint(20, 180)
        orig_eta = now + timedelta(minutes=eta_offset_mins)
        
        delay_mins = 25 if status == "delayed" else 0
        rev_eta = orig_eta + timedelta(minutes=delay_mins) if delay_mins > 0 else orig_eta

        cur_lat = pickup_loc["lat"] + (deliv_loc["lat"] - pickup_loc["lat"]) * 0.4
        cur_lng = pickup_loc["lng"] + (deliv_loc["lng"] - pickup_loc["lng"]) * 0.4

        cursor.execute("""
            INSERT INTO orders (
                order_code, customer_id, recipient_name, recipient_phone,
                pickup_address, pickup_lat, pickup_lng,
                delivery_address, delivery_lat, delivery_lng,
                package_type, weight_kg, priority,
                assigned_vehicle_id, status,
                original_eta, revised_eta, delay_minutes,
                current_lat, current_lng, delivery_notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            order_code, c_id, f"Receiving Officer #{i}", f"+91 989{random.randint(10,99)} {random.randint(10000,99999)}",
            pickup_loc["name"] + ", Coimbatore", pickup_loc["lat"], pickup_loc["lng"],
            deliv_loc["name"] + ", Coimbatore", deliv_loc["lat"], deliv_loc["lng"],
            pkg_type, weight, priority,
            v_id if status not in ("order_placed", "cancelled") else None,
            status,
            orig_eta.strftime('%Y-%m-%d %H:%M:%S'),
            rev_eta.strftime('%Y-%m-%d %H:%M:%S'),
            delay_mins,
            cur_lat, cur_lng,
            f"Package content: {pkg_desc}. Handle with care."
        ))

        order_db_id = cursor.lastrowid

        # Deliveries table record
        tracking_steps = [
            {"step": "Order Placed", "status": "completed", "time": (now - timedelta(hours=2)).strftime('%I:%M %p'), "desc": "Order registered in LogiGuard AI central dispatch"},
            {"step": "Confirmed & Scheduled", "status": "completed", "time": (now - timedelta(hours=1, minutes=45)).strftime('%I:%M %p'), "desc": "Automated warehouse binning verified"},
            {"step": "Vehicle Assigned", "status": "completed" if status != "order_placed" else "pending", "time": (now - timedelta(hours=1, minutes=20)).strftime('%I:%M %p') if status != "order_placed" else "-", "desc": f"Assigned to Unit V-{100 + v_id}"},
            {"step": "In Transit / Dispatched", "status": "completed" if status in ("in_transit", "delayed", "delivered") else "pending", "time": (now - timedelta(minutes=40)).strftime('%I:%M %p') if status in ("in_transit", "delayed", "delivered") else "-", "desc": f"En route on logistics arterial grid"},
            {"step": "Delivered", "status": "completed" if status == "delivered" else "pending", "time": (now - timedelta(minutes=5)).strftime('%I:%M %p') if status == "delivered" else "-", "desc": "Electronic sign-off registered at delivery destination"}
        ]

        cursor.execute("""
            INSERT INTO deliveries (order_id, vehicle_id, driver_id, start_time, completion_time, current_step_index, tracking_steps_json)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            order_db_id,
            v_id,
            v_id,
            (now - timedelta(hours=1)).strftime('%Y-%m-%d %H:%M:%S'),
            now.strftime('%Y-%m-%d %H:%M:%S') if status == "delivered" else None,
            4 if status == "delivered" else 3,
            json.dumps(tracking_steps)
        ))

    # 7. Seed Initial Notifications
    notifs = [
        (1, None, "Autonomous Fleet Telemetry Active", "20/20 vehicles connected to LogiGuard real-time telemetry stream. Network load optimal.", "info"),
        (1, None, "Disruption Warning: Avinashi Road Flood Alert", "Critical waterlogging detected near Node 12. 3 vehicles within impact perimeter flagged for rerouting.", "delay"),
        (2, 1, "Order #ORD-7001 Status Update", "Your critical medical shipment has been dispatched in Temperature-Controlled EV Van V-101. Live tracking active.", "order_status"),
        (2, 2, "Traffic Reroute Notice: Order #ORD-7002", "Autonomous AI detected corridor congestion. AI recalculating alternative bypass.", "delay"),
        (3, 21, "Order #ORD-7021 Confirmed", "Your electronics consignment is confirmed for 02:30 PM delivery slot.", "order_status")
    ]

    for uid, oid, title, msg, ntype in notifs:
        cursor.execute("""
            INSERT INTO notifications (user_id, order_id, title, message, notification_type, is_read)
            VALUES (?, ?, ?, ?, ?, 0)
        """, (uid, oid, title, msg, ntype))

    conn.commit()
    conn.close()
    print("[SEED] Successfully populated database with 20 Vehicles, 100 Orders, 20 Drivers, Disruptions, and Demo Accounts.")

if __name__ == "__main__":
    seed_database()
