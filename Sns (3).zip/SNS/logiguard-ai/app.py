"""
LogiGuard AI - Backend Flask Application
REST API for Fleet Owner/Admin & Customer Portals, AI Route Optimization & Disruption Solver.
"""

import os
import sys
import json
import secrets
from datetime import datetime, timedelta
from functools import wraps
from flask import Flask, request, jsonify, send_from_directory, g
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash

from database import get_db_connection, init_db
from ai_engine import DisruptionAI, NETWORK_NODES, NETWORK_EDGES

app = Flask(__name__, static_folder="static", static_url_path="")
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "logiguard-ai-super-secret-key-2026")
CORS(app, resources={r"/api/*": {"origins": "*"}})

# In-memory simple session/token store (for high-speed hackathon prototyping with token support)
ACTIVE_TOKENS = {}

# ---------------------------------------------------------
# AUTHENTICATION & ROLE MIDDLEWARE
# ---------------------------------------------------------

def auth_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth_header = request.headers.get("Authorization", "")
        token = ""
        if auth_header.startswith("Bearer "):
            token = auth_header.split(" ", 1)[1].strip()
        elif "X-Auth-Token" in request.headers:
            token = request.headers["X-Auth-Token"].strip()
        
        # Fallback to query param or demo header
        if not token:
            token = request.args.get("token", "")

        user = ACTIVE_TOKENS.get(token)
        if not user:
            # Check if demo header is supplied (e.g. for rapid testing)
            demo_user_id = request.headers.get("X-Demo-User-Id")
            if demo_user_id:
                conn = get_db_connection()
                cur = conn.cursor()
                cur.execute("SELECT id, email, role, full_name, phone, avatar_url FROM users WHERE id = ?", (demo_user_id,))
                row = cur.fetchone()
                conn.close()
                if row:
                    user = dict(row)

        if not user:
            return jsonify({"error": "Unauthorized. Please log in.", "code": "AUTH_REQUIRED"}), 401
        
        g.current_user = user
        return f(*args, **kwargs)
    return decorated

def role_required(allowed_roles):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if not hasattr(g, "current_user") or not g.current_user:
                return jsonify({"error": "Authentication required."}), 401
            if g.current_user.get("role") not in allowed_roles:
                return jsonify({"error": f"Forbidden. Requires role: {','.join(allowed_roles)}"}), 403
            return f(*args, **kwargs)
        return decorated
    return decorator

# ---------------------------------------------------------
# STATIC ASSETS & FRONTEND SERVING
# ---------------------------------------------------------

@app.route("/")
@app.route("/track")
def serve_index():
    return send_from_directory(app.static_folder, "index.html")

@app.route("/api/health")
def health_check():
    return jsonify({
        "status": "healthy",
        "system": "LogiGuard AI - Disruption-Aware Logistics Platform",
        "version": "2.4.0",
        "timestamp": datetime.now().isoformat()
    })

# ---------------------------------------------------------
# AUTHENTICATION APIS
# ---------------------------------------------------------

@app.route("/api/auth/login", methods=["POST"])
def login():
    data = request.get_json() or {}
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")
    expected_role = data.get("role") # optional: 'owner' or 'customer'

    if not email or not password:
        return jsonify({"error": "Email and password are required."}), 400

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE LOWER(email) = ?", (email,))
    user_row = cursor.fetchone()
    conn.close()

    if not user_row or not check_password_hash(user_row["password_hash"], password):
        return jsonify({"error": "Invalid email or password credentials."}), 401

    user = dict(user_row)
    del user["password_hash"]

    if expected_role and user["role"] != expected_role:
        return jsonify({
            "error": f"Role mismatch: This account is registered as '{user['role'].title()}'. Please use the {user['role'].title()} tab to log in."
        }), 403

    token = secrets.token_hex(24)
    ACTIVE_TOKENS[token] = user

    return jsonify({
        "success": True,
        "message": f"Welcome back, {user['full_name']}!",
        "token": token,
        "user": user
    })

@app.route("/api/auth/register", methods=["POST"])
def register():
    data = request.get_json() or {}
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")
    full_name = data.get("full_name", "").strip()
    phone = data.get("phone", "").strip()
    role = data.get("role", "customer").strip().lower()
    address = data.get("address", "Coimbatore Main Hub")

    if not email or not password or not full_name:
        return jsonify({"error": "Name, email, and password are required."}), 400

    if role not in ("owner", "customer"):
        role = "customer"

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        password_hash = generate_password_hash(password)
        cursor.execute("""
            INSERT INTO users (email, password_hash, role, full_name, phone)
            VALUES (?, ?, ?, ?, ?)
        """, (email, password_hash, role, full_name, phone))
        
        user_id = cursor.lastrowid

        if role == "customer":
            cursor.execute("""
                INSERT INTO customer_profiles (user_id, default_address, city)
                VALUES (?, ?, 'Coimbatore')
            """, (user_id, address))

        conn.commit()
    except Exception as e:
        conn.rollback()
        conn.close()
        if "UNIQUE" in str(e):
            return jsonify({"error": "An account with this email address already exists."}), 400
        return jsonify({"error": f"Registration failed: {str(e)}"}), 500

    cursor.execute("SELECT id, email, role, full_name, phone FROM users WHERE id = ?", (user_id,))
    user = dict(cursor.fetchone())
    conn.close()

    token = secrets.token_hex(24)
    ACTIVE_TOKENS[token] = user

    return jsonify({
        "success": True,
        "message": "Account created successfully.",
        "token": token,
        "user": user
    }), 201

@app.route("/api/auth/me", methods=["GET"])
@auth_required
def get_current_user():
    user_id = g.current_user["id"]
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, email, role, full_name, phone, avatar_url, created_at FROM users WHERE id = ?", (user_id,))
    user = dict(cursor.fetchone())

    profile = {}
    if user["role"] == "customer":
        cursor.execute("SELECT * FROM customer_profiles WHERE user_id = ?", (user_id,))
        p_row = cursor.fetchone()
        if p_row:
            profile = dict(p_row)

    conn.close()
    return jsonify({"user": user, "profile": profile})

@app.route("/api/auth/logout", methods=["POST"])
def logout():
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        token = auth_header.split(" ", 1)[1].strip()
        ACTIVE_TOKENS.pop(token, None)
    return jsonify({"success": True, "message": "Logged out successfully."})

@app.route("/api/auth/forgot-password", methods=["POST"])
def forgot_password():
    data = request.get_json() or {}
    email = data.get("email", "").strip()
    return jsonify({
        "success": True,
        "message": f"If an account exists for {email}, a secure password reset link and temporary authorization code has been dispatched."
    })

# ---------------------------------------------------------
# OWNER / ADMIN DASHBOARD APIS
# ---------------------------------------------------------

@app.route("/api/owner/overview", methods=["GET"])
@auth_required
@role_required(["owner"])
def get_owner_overview():
    conn = get_db_connection()
    cursor = conn.cursor()

    # Vehicles stats
    cursor.execute("SELECT COUNT(*) as total FROM vehicles")
    total_vehicles = cursor.fetchone()["total"]

    # Orders stats
    cursor.execute("SELECT status, COUNT(*) as cnt FROM orders GROUP BY status")
    order_counts = {row["status"]: row["cnt"] for row in cursor.fetchall()}

    # Disruption stats
    cursor.execute("SELECT COUNT(*) as active_disruptions FROM disruptions WHERE is_active = 1")
    active_disruptions = cursor.fetchone()["active_disruptions"]

    # Urgent orders flagged
    cursor.execute("SELECT COUNT(*) as urgent FROM orders WHERE priority = 'urgent_medical' AND status IN ('in_transit', 'delayed')")
    urgent_at_risk = cursor.fetchone()["urgent"]

    conn.close()

    return jsonify({
        "metrics": {
            "total_vehicles": total_vehicles,
            "active_deliveries": order_counts.get("in_transit", 0),
            "pending_orders": order_counts.get("order_placed", 0) + order_counts.get("confirmed", 0),
            "delayed_deliveries": order_counts.get("delayed", 0),
            "completed_deliveries": order_counts.get("delivered", 0),
            "total_orders": sum(order_counts.values()),
            "active_disruptions": active_disruptions,
            "urgent_medical_at_risk": urgent_at_risk,
            "on_time_sla_rate": 96.8 if order_counts.get("delayed", 0) == 0 else round(100.0 - (order_counts.get("delayed", 0) / max(sum(order_counts.values()), 1) * 100), 1)
        },
        "order_status_breakdown": order_counts
    })

@app.route("/api/owner/vehicles", methods=["GET", "POST"])
@auth_required
@role_required(["owner"])
def manage_vehicles():
    conn = get_db_connection()
    cursor = conn.cursor()

    if request.method == "POST":
        data = request.get_json() or {}
        code = data.get("code", f"V-{random.randint(121, 999)}")
        plate = data.get("plate_number", f"TN-38-AB-{random.randint(1000, 9999)}")
        v_type = data.get("vehicle_type", "EV Van (Autonomous Pilot)")
        cap = float(data.get("capacity_kg", 1200))
        lat = float(data.get("current_lat", 11.0168))
        lng = float(data.get("current_lng", 76.9558))

        cursor.execute("""
            INSERT INTO vehicles (code, plate_number, vehicle_type, capacity_kg, current_load_kg, fuel_battery_percent, status, current_lat, current_lng)
            VALUES (?, ?, ?, ?, 0, 100, 'idle', ?, ?)
        """, (code, plate, v_type, cap, lat, lng))
        conn.commit()
        new_id = cursor.lastrowid
        conn.close()
        return jsonify({"success": True, "message": f"Vehicle {code} added to fleet.", "vehicle_id": new_id}), 201

    # GET vehicles
    cursor.execute("""
        SELECT v.*, d.name as driver_name, d.phone as driver_phone, d.rating as driver_rating,
               (SELECT COUNT(*) FROM orders o WHERE o.assigned_vehicle_id = v.id AND o.status IN ('in_transit', 'delayed', 'assigned')) as active_order_count
        FROM vehicles v
        LEFT JOIN drivers d ON v.driver_id = d.id
        ORDER BY v.id ASC
    """)
    vehicles = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return jsonify({"vehicles": vehicles, "total": len(vehicles)})

@app.route("/api/owner/vehicles/<int:v_id>", methods=["PUT", "DELETE"])
@auth_required
@role_required(["owner"])
def vehicle_detail_action(v_id):
    conn = get_db_connection()
    cursor = conn.cursor()

    if request.method == "DELETE":
        cursor.execute("DELETE FROM vehicles WHERE id = ?", (v_id,))
        conn.commit()
        conn.close()
        return jsonify({"success": True, "message": "Vehicle deleted successfully."})

    # PUT update
    data = request.get_json() or {}
    status = data.get("status")
    fuel = data.get("fuel_battery_percent")
    driver_id = data.get("driver_id")

    updates = []
    params = []
    if status:
        updates.append("status = ?")
        params.append(status)
    if fuel is not None:
        updates.append("fuel_battery_percent = ?")
        params.append(fuel)
    if driver_id is not None:
        updates.append("driver_id = ?")
        params.append(driver_id)

    if updates:
        params.append(v_id)
        cursor.execute(f"UPDATE vehicles SET {', '.join(updates)} WHERE id = ?", params)
        conn.commit()

    conn.close()
    return jsonify({"success": True, "message": "Vehicle updated successfully."})

@app.route("/api/owner/orders", methods=["GET"])
@auth_required
@role_required(["owner"])
def get_all_orders():
    search = request.args.get("search", "").strip().lower()
    status_filter = request.args.get("status", "")
    priority_filter = request.args.get("priority", "")

    conn = get_db_connection()
    cursor = conn.cursor()

    query = """
        SELECT o.*, u.full_name as customer_name, u.email as customer_email, u.phone as customer_phone,
               v.code as vehicle_code, d.name as driver_name
        FROM orders o
        JOIN users u ON o.customer_id = u.id
        LEFT JOIN vehicles v ON o.assigned_vehicle_id = v.id
        LEFT JOIN drivers d ON v.driver_id = d.id
        WHERE 1=1
    """
    params = []

    if status_filter:
        query += " AND o.status = ?"
        params.append(status_filter)

    if priority_filter:
        query += " AND o.priority = ?"
        params.append(priority_filter)

    if search:
        query += " AND (LOWER(o.order_code) LIKE ? OR LOWER(u.full_name) LIKE ? OR LOWER(o.delivery_address) LIKE ?)"
        term = f"%{search}%"
        params.extend([term, term, term])

    query += " ORDER BY o.id DESC"
    cursor.execute(query, params)
    orders = [dict(r) for r in cursor.fetchall()]
    conn.close()

    return jsonify({"orders": orders, "total": len(orders)})

@app.route("/api/owner/orders/<int:order_id>/assign", methods=["PUT"])
@auth_required
@role_required(["owner"])
def assign_order_vehicle(order_id):
    data = request.get_json() or {}
    vehicle_id = data.get("vehicle_id")

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE orders 
        SET assigned_vehicle_id = ?, status = 'assigned', updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    """, (vehicle_id, order_id))
    conn.commit()
    conn.close()

    return jsonify({"success": True, "message": f"Order #{order_id} assigned to vehicle #{vehicle_id}."})

@app.route("/api/owner/orders/<int:order_id>/status", methods=["PUT"])
@auth_required
@role_required(["owner"])
def update_order_status(order_id):
    data = request.get_json() or {}
    new_status = data.get("status")

    if new_status not in ('order_placed', 'confirmed', 'assigned', 'in_transit', 'delayed', 'delivered', 'cancelled'):
        return jsonify({"error": "Invalid status."}), 400

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", (new_status, order_id))
    conn.commit()
    conn.close()

    return jsonify({"success": True, "message": f"Order status updated to '{new_status}'."})

@app.route("/api/owner/disruptions", methods=["GET", "POST"])
@auth_required
@role_required(["owner"])
def handle_disruptions():
    conn = get_db_connection()
    cursor = conn.cursor()

    if request.method == "POST":
        data = request.get_json() or {}
        code = data.get("code", f"DIS-{random.randint(100, 999)}")
        title = data.get("title", "New Disruption Report")
        dtype = data.get("disruption_type", "road_closure")
        sev = data.get("severity", "high")
        loc_name = data.get("location_name", "Avinashi Road")
        lat = float(data.get("lat", 11.0220))
        lng = float(data.get("lng", 76.9780))
        radius = float(data.get("radius_km", 1.5))
        desc = data.get("description", "Reported incident blocking logistics transit corridor.")

        cursor.execute("""
            INSERT INTO disruptions (code, title, disruption_type, severity, location_name, lat, lng, radius_km, description, is_active)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
        """, (code, title, dtype, sev, loc_name, lat, lng, radius, desc))
        conn.commit()
        new_id = cursor.lastrowid
        conn.close()
        return jsonify({"success": True, "message": f"Disruption '{title}' registered.", "disruption_id": new_id}), 201

    # GET disruptions
    cursor.execute("SELECT * FROM disruptions ORDER BY id ASC")
    disruptions = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return jsonify({"disruptions": disruptions})

@app.route("/api/owner/disruptions/<int:d_id>/analysis", methods=["GET"])
@auth_required
@role_required(["owner"])
def get_disruption_analysis(d_id):
    analysis = DisruptionAI.analyze_disruption_impact(d_id)
    return jsonify(analysis)

@app.route("/api/owner/disruptions/<int:d_id>/apply-plan", methods=["POST"])
@auth_required
@role_required(["owner"])
def apply_disruption_plan(d_id):
    data = request.get_json() or {}
    rec_id = data.get("recommendation_id", "REC-01")
    result = DisruptionAI.apply_revised_plan(
        disruption_id=d_id,
        approved_by_user_id=g.current_user["id"],
        selected_recommendation_id=rec_id
    )
    return jsonify(result)

@app.route("/api/owner/customers", methods=["GET"])
@auth_required
@role_required(["owner"])
def list_customers():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT u.id, u.full_name, u.email, u.phone, u.created_at, cp.company_name, cp.city,
               COUNT(o.id) as total_orders,
               SUM(CASE WHEN o.status = 'delivered' THEN 1 ELSE 0 END) as completed_orders,
               SUM(CASE WHEN o.status = 'delayed' THEN 1 ELSE 0 END) as delayed_orders
        FROM users u
        LEFT JOIN customer_profiles cp ON u.id = cp.user_id
        LEFT JOIN orders o ON u.id = o.customer_id
        WHERE u.role = 'customer'
        GROUP BY u.id
        ORDER BY total_orders DESC
    """)
    customers = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return jsonify({"customers": customers, "total": len(customers)})

@app.route("/api/owner/analytics", methods=["GET"])
@auth_required
@role_required(["owner"])
def get_analytics():
    conn = get_db_connection()
    cursor = conn.cursor()

    # Package types
    cursor.execute("SELECT package_type, COUNT(*) as count FROM orders GROUP BY package_type")
    pkg_distribution = {r["package_type"]: r["count"] for r in cursor.fetchall()}

    # Vehicle utilization
    cursor.execute("""
        SELECT vehicle_type, AVG(fuel_battery_percent) as avg_battery, 
               AVG((current_load_kg / capacity_kg) * 100) as avg_utilization, COUNT(*) as count 
        FROM vehicles GROUP BY vehicle_type
    """)
    fleet_utilization = [dict(r) for r in cursor.fetchall()]

    conn.close()

    # Performance trend mock data
    performance_trend = [
        {"day": "Mon", "on_time_pct": 98.4, "disruptions": 1},
        {"day": "Tue", "on_time_pct": 99.1, "disruptions": 0},
        {"day": "Wed", "on_time_pct": 97.5, "disruptions": 2},
        {"day": "Thu", "on_time_pct": 98.8, "disruptions": 1},
        {"day": "Fri", "on_time_pct": 95.2, "disruptions": 3},
        {"day": "Sat", "on_time_pct": 99.4, "disruptions": 0},
        {"day": "Sun", "on_time_pct": 98.9, "disruptions": 1}
    ]

    return jsonify({
        "package_distribution": pkg_distribution,
        "fleet_utilization": fleet_utilization,
        "performance_trend": performance_trend,
        "co2_saved_kg": 438.5,
        "total_optimized_km": 12840
    })

# ---------------------------------------------------------
# CUSTOMER DASHBOARD APIS
# ---------------------------------------------------------

@app.route("/api/customer/profile", methods=["GET", "PUT"])
@auth_required
@role_required(["customer"])
def customer_profile():
    user_id = g.current_user["id"]
    conn = get_db_connection()
    cursor = conn.cursor()

    if request.method == "PUT":
        data = request.get_json() or {}
        full_name = data.get("full_name", g.current_user["full_name"])
        phone = data.get("phone", g.current_user.get("phone", ""))
        address = data.get("default_address", "")
        company = data.get("company_name", "")
        window = data.get("preferred_window", "09:00 - 18:00")

        cursor.execute("UPDATE users SET full_name = ?, phone = ? WHERE id = ?", (full_name, phone, user_id))
        cursor.execute("""
            UPDATE customer_profiles 
            SET default_address = ?, company_name = ?, preferred_window = ?
            WHERE user_id = ?
        """, (address, company, window, user_id))
        conn.commit()

    cursor.execute("""
        SELECT u.id, u.email, u.full_name, u.phone, u.avatar_url,
               cp.default_address, cp.city, cp.postal_code, cp.company_name, cp.preferred_window
        FROM users u
        LEFT JOIN customer_profiles cp ON u.id = cp.user_id
        WHERE u.id = ?
    """, (user_id,))
    profile_data = dict(cursor.fetchone())
    conn.close()

    return jsonify({"profile": profile_data})

@app.route("/api/customer/orders", methods=["GET", "POST"])
@auth_required
@role_required(["customer"])
def customer_orders():
    user_id = g.current_user["id"]
    conn = get_db_connection()
    cursor = conn.cursor()

    if request.method == "POST":
        data = request.get_json() or {}
        recipient_name = data.get("recipient_name", "").strip()
        recipient_phone = data.get("recipient_phone", "").strip()
        pickup_address = data.get("pickup_address", "Central Logistics Hub, Coimbatore").strip()
        delivery_address = data.get("delivery_address", "").strip()
        package_type = data.get("package_type", "Standard Parcel")
        weight_kg = float(data.get("weight_kg", 2.5))
        priority = data.get("priority", "standard")
        notes = data.get("delivery_notes", "")

        if not recipient_name or not delivery_address:
            return jsonify({"error": "Recipient name and delivery address are required."}), 400

        # Generate unique order code
        cursor.execute("SELECT COUNT(*) as count FROM orders")
        next_num = 7001 + cursor.fetchone()["count"]
        order_code = f"ORD-{next_num}"

        # Assign pickup/delivery coordinates based on Coimbatore locations
        pickup_loc = NETWORK_NODES["N1"]
        deliv_loc = NETWORK_NODES.get("N4", NETWORK_NODES["N2"])

        now = datetime.now()
        eta_mins = 45 if priority == "urgent_medical" else (90 if priority == "express" else 150)
        orig_eta = now + timedelta(minutes=eta_mins)

        # Auto-assign available vehicle
        cursor.execute("SELECT id FROM vehicles WHERE status != 'maintenance' ORDER BY RANDOM() LIMIT 1")
        v_row = cursor.fetchone()
        assigned_v = v_row["id"] if v_row else 1

        cursor.execute("""
            INSERT INTO orders (
                order_code, customer_id, recipient_name, recipient_phone,
                pickup_address, pickup_lat, pickup_lng,
                delivery_address, delivery_lat, delivery_lng,
                package_type, weight_kg, priority,
                assigned_vehicle_id, status,
                original_eta, revised_eta, delay_minutes,
                current_lat, current_lng, delivery_notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'order_placed', ?, ?, 0, ?, ?, ?)
        """, (
            order_code, user_id, recipient_name, recipient_phone,
            pickup_address, pickup_loc["lat"], pickup_loc["lng"],
            delivery_address, deliv_loc["lat"], deliv_loc["lng"],
            package_type, weight_kg, priority,
            assigned_v,
            orig_eta.strftime('%Y-%m-%d %H:%M:%S'),
            orig_eta.strftime('%Y-%m-%d %H:%M:%S'),
            pickup_loc["lat"], pickup_loc["lng"],
            notes
        ))
        
        order_id = cursor.lastrowid

        # Insert tracking steps
        tracking_steps = [
            {"step": "Order Placed", "status": "completed", "time": now.strftime('%I:%M %p'), "desc": "Order placed successfully."},
            {"step": "Confirmed & Scheduled", "status": "pending", "time": "-", "desc": "Warehouse dispatching soon."},
            {"step": "Vehicle Assigned", "status": "pending", "time": "-", "desc": "Fleet unit matching."},
            {"step": "In Transit", "status": "pending", "time": "-", "desc": "Driver en route."},
            {"step": "Delivered", "status": "pending", "time": "-", "desc": "Awaiting delivery signoff."}
        ]

        cursor.execute("""
            INSERT INTO deliveries (order_id, vehicle_id, driver_id, start_time, current_step_index, tracking_steps_json)
            VALUES (?, ?, ?, ?, 0, ?)
        """, (order_id, assigned_v, assigned_v, now.strftime('%Y-%m-%d %H:%M:%S'), json.dumps(tracking_steps)))

        # Confirmation notification
        cursor.execute("""
            INSERT INTO notifications (user_id, order_id, title, message, notification_type, is_read)
            VALUES (?, ?, ?, ?, 'order_status', 0)
        """, (user_id, order_id, f"Order #{order_code} Placed", f"Your {priority.title()} order has been accepted. Estimated delivery: {orig_eta.strftime('%I:%M %p')}."))

        conn.commit()
        conn.close()

        return jsonify({
            "success": True,
            "message": f"Order #{order_code} created successfully!",
            "order_code": order_code,
            "order_id": order_id,
            "eta": orig_eta.strftime('%I:%M %p')
        }), 201

    # GET Customer Orders (Strict Customer Isolation!)
    cursor.execute("""
        SELECT o.*, v.code as vehicle_code, d.name as driver_name, d.phone as driver_phone
        FROM orders o
        LEFT JOIN vehicles v ON o.assigned_vehicle_id = v.id
        LEFT JOIN drivers d ON v.driver_id = d.id
        WHERE o.customer_id = ?
        ORDER BY o.id DESC
    """, (user_id,))
    orders = [dict(r) for r in cursor.fetchall()]
    conn.close()

    return jsonify({"orders": orders, "total": len(orders)})

@app.route("/api/customer/orders/<order_code>/track", methods=["GET"])
@auth_required
def track_order(order_code):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT o.*, u.full_name as customer_name,
               v.code as vehicle_code, v.vehicle_type, v.plate_number, v.fuel_battery_percent,
               v.current_lat as vehicle_live_lat, v.current_lng as vehicle_live_lng,
               d.name as driver_name, d.phone as driver_phone, d.rating as driver_rating,
               del.tracking_steps_json
        FROM orders o
        JOIN users u ON o.customer_id = u.id
        LEFT JOIN vehicles v ON o.assigned_vehicle_id = v.id
        LEFT JOIN drivers d ON v.driver_id = d.id
        LEFT JOIN deliveries del ON del.order_id = o.id
        WHERE o.order_code = ?
    """, (order_code,))
    row = cursor.fetchone()
    
    if not row:
        conn.close()
        return jsonify({"error": "Order not found."}), 404

    order = dict(row)

    # Check authorization (Customer can only track own orders, Owner can track any)
    if g.current_user["role"] == "customer" and order["customer_id"] != g.current_user["id"]:
        conn.close()
        return jsonify({"error": "Unauthorized to view this order."}), 403

    # Check if any active disruption is impacting this vehicle or route
    cursor.execute("""
        SELECT title, location_name, disruption_type, severity 
        FROM disruptions 
        WHERE is_active = 1 
        LIMIT 1
    """)
    disruption = cursor.fetchone()

    steps = []
    if order.get("tracking_steps_json"):
        try:
            steps = json.loads(order["tracking_steps_json"])
        except Exception:
            steps = []

    # Map trajectory points
    pickup = {"lat": order["pickup_lat"], "lng": order["pickup_lng"], "name": order["pickup_address"]}
    delivery = {"lat": order["delivery_lat"], "lng": order["delivery_lng"], "name": order["delivery_address"]}
    live_pos = {
        "lat": order["vehicle_live_lat"] or order["current_lat"] or order["pickup_lat"],
        "lng": order["vehicle_live_lng"] or order["current_lng"] or order["pickup_lng"]
    }

    conn.close()

    return jsonify({
        "order": order,
        "pickup": pickup,
        "delivery": delivery,
        "live_position": live_pos,
        "tracking_steps": steps,
        "active_disruption": dict(disruption) if disruption and order["status"] == "delayed" else None
    })

@app.route("/api/customer/orders/<order_code>/cancel", methods=["POST"])
@auth_required
@role_required(["customer"])
def cancel_order(order_code):
    user_id = g.current_user["id"]
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT id, status, customer_id FROM orders WHERE order_code = ?", (order_code,))
    row = cursor.fetchone()

    if not row:
        conn.close()
        return jsonify({"error": "Order not found."}), 404

    if row["customer_id"] != user_id:
        conn.close()
        return jsonify({"error": "Unauthorized."}), 403

    if row["status"] not in ("order_placed", "confirmed"):
        conn.close()
        return jsonify({"error": f"Cannot cancel order with status '{row['status']}'. It has already been assigned or dispatched."}), 400

    cursor.execute("UPDATE orders SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP WHERE id = ?", (row["id"],))
    conn.commit()
    conn.close()

    return jsonify({"success": True, "message": f"Order #{order_code} has been cancelled."})

@app.route("/api/customer/notifications", methods=["GET"])
@auth_required
def get_user_notifications():
    user_id = g.current_user["id"]
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT * FROM notifications 
        WHERE user_id = ? OR user_id IS NULL 
        ORDER BY id DESC LIMIT 30
    """, (user_id,))
    notifs = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return jsonify({"notifications": notifs, "unread_count": sum(1 for n in notifs if not n["is_read"])})

@app.route("/api/customer/notifications/read-all", methods=["POST"])
@auth_required
def mark_notifications_read():
    user_id = g.current_user["id"]
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE notifications SET is_read = 1 WHERE user_id = ? OR user_id IS NULL", (user_id,))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

# ---------------------------------------------------------
# SHARED MAP & NETWORK APIS
# ---------------------------------------------------------

@app.route("/api/network/nodes", methods=["GET"])
def get_network_nodes():
    return jsonify({"nodes": NETWORK_NODES, "edges": [{"from": u, "to": v, "dist_km": d, "speed_kmh": s, "name": n} for u, v, d, s, n in NETWORK_EDGES]})

# ---------------------------------------------------------
# HACKATHON 1-CLICK DEMO ORCHESTRATOR
# ---------------------------------------------------------

@app.route("/api/hackathon/quick-demo", methods=["POST"])
def run_quick_demo():
    """
    Executes the entire end-to-end hackathon demonstration in one atomic call:
    1. Triggers Avinashi Road Flood Disruption.
    2. Runs AI Solver.
    3. Returns pre-mitigation and post-mitigation state comparison for interactive presentation.
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    # Reset disruption 1 to active
    cursor.execute("UPDATE disruptions SET is_active = 1 WHERE id = 1")
    # Mark vehicles 1, 2, 5 as delayed
    cursor.execute("UPDATE vehicles SET status = 'delayed' WHERE id IN (1, 2, 5)")
    cursor.execute("UPDATE orders SET status = 'delayed', delay_minutes = 28 WHERE id IN (1, 2, 5, 12, 18)")
    conn.commit()
    conn.close()

    # Run AI Analysis
    analysis = DisruptionAI.analyze_disruption_impact(1)

    return jsonify({
        "success": True,
        "demo_title": "Avinashi Road Arterial Flood & Flyover Blockade Simulation",
        "scenario": {
            "disruption_code": "DIS-AVINASHI-01",
            "location": "Avinashi Road Flyover Sector",
            "blocked_axis": "Node 12 ↔ Node 2 (Lakshmi Mills to Peelamedu)",
            "affected_vehicles_count": analysis["affected_vehicles_count"],
            "affected_orders_count": analysis["affected_orders_count"],
            "average_delay_without_ai": "28 - 35 mins (Critical SLA Risk)",
            "average_delay_with_ai": "12 - 14 mins (98.2% SLA Preserved)"
        },
        "analysis": analysis,
        "ready_to_apply": True
    })

if __name__ == "__main__":
    init_db()
    port = int(os.environ.get("PORT", 8000))
    print("=" * 65)
    print(f">> LogiGuard AI Disruption-Aware Logistics Platform Live")
    print(f">> Web Dashboard: http://localhost:{port}")
    print(f">> API Root:      http://localhost:{port}/api/health")
    print("=" * 65)
    app.run(host="0.0.0.0", port=port, debug=False)
