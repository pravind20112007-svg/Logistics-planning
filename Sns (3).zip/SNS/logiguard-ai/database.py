"""
LogiGuard AI - Database Layer
SQLite schema and management with relational integrity and role-based access models.
"""

import sqlite3
import os
import json
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logiguard.db")

def get_db_connection():
    """Returns a database connection with dict-like row factory."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    """Initializes all database tables with strict relational constraints and indexing."""
    conn = get_db_connection()
    cursor = conn.cursor()

    # 1. Users Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('owner', 'customer')),
        full_name TEXT NOT NULL,
        phone TEXT,
        avatar_url TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # 2. Customer Profiles Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS customer_profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER UNIQUE NOT NULL,
        default_address TEXT,
        city TEXT DEFAULT 'Coimbatore',
        postal_code TEXT,
        company_name TEXT,
        preferred_window TEXT DEFAULT '09:00 - 18:00',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    """)

    # 3. Drivers Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS drivers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT NOT NULL,
        license_no TEXT UNIQUE NOT NULL,
        experience_years INTEGER DEFAULT 3,
        rating REAL DEFAULT 4.8,
        status TEXT DEFAULT 'active' CHECK(status IN ('active', 'on_leave', 'assigned')),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # 4. Vehicles Table (20 fleet units)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS vehicles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        plate_number TEXT NOT NULL,
        vehicle_type TEXT NOT NULL,
        capacity_kg REAL NOT NULL,
        current_load_kg REAL DEFAULT 0,
        fuel_battery_percent INTEGER DEFAULT 95,
        driver_id INTEGER,
        status TEXT DEFAULT 'idle' CHECK(status IN ('idle', 'in_transit', 'delayed', 'maintenance')),
        current_lat REAL NOT NULL,
        current_lng REAL NOT NULL,
        assigned_route_id INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (driver_id) REFERENCES drivers(id) ON DELETE SET NULL
    );
    """)

    # 5. Disruptions Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS disruptions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        title TEXT NOT NULL,
        disruption_type TEXT NOT NULL CHECK(disruption_type IN ('road_closure', 'traffic_congestion', 'accident', 'vehicle_breakdown', 'flooding')),
        severity TEXT DEFAULT 'high' CHECK(severity IN ('critical', 'high', 'moderate', 'low')),
        location_name TEXT NOT NULL,
        lat REAL NOT NULL,
        lng REAL NOT NULL,
        radius_km REAL DEFAULT 1.5,
        description TEXT,
        is_active INTEGER DEFAULT 1,
        reported_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        resolved_at TIMESTAMP
    );
    """)

    # 6. Routes Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS routes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        origin_name TEXT NOT NULL,
        origin_lat REAL NOT NULL,
        origin_lng REAL NOT NULL,
        dest_name TEXT NOT NULL,
        dest_lat REAL NOT NULL,
        dest_lng REAL NOT NULL,
        waypoints_json TEXT NOT NULL,
        distance_km REAL NOT NULL,
        estimated_time_mins INTEGER NOT NULL,
        is_blocked INTEGER DEFAULT 0,
        blocked_reason TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # 7. Orders Table (100 logistics packages)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_code TEXT UNIQUE NOT NULL,
        customer_id INTEGER NOT NULL,
        recipient_name TEXT NOT NULL,
        recipient_phone TEXT NOT NULL,
        pickup_address TEXT NOT NULL,
        pickup_lat REAL NOT NULL,
        pickup_lng REAL NOT NULL,
        delivery_address TEXT NOT NULL,
        delivery_lat REAL NOT NULL,
        delivery_lng REAL NOT NULL,
        package_type TEXT NOT NULL,
        weight_kg REAL NOT NULL,
        priority TEXT DEFAULT 'standard' CHECK(priority IN ('standard', 'express', 'urgent_medical')),
        assigned_vehicle_id INTEGER,
        status TEXT DEFAULT 'order_placed' CHECK(status IN ('order_placed', 'confirmed', 'assigned', 'in_transit', 'delayed', 'delivered', 'cancelled')),
        original_eta TIMESTAMP,
        revised_eta TIMESTAMP,
        delay_minutes INTEGER DEFAULT 0,
        current_lat REAL,
        current_lng REAL,
        delivery_notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (assigned_vehicle_id) REFERENCES vehicles(id) ON DELETE SET NULL
    );
    """)

    # 8. Deliveries Tracking Steps Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS deliveries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER UNIQUE NOT NULL,
        vehicle_id INTEGER,
        driver_id INTEGER,
        start_time TIMESTAMP,
        completion_time TIMESTAMP,
        current_step_index INTEGER DEFAULT 0,
        tracking_steps_json TEXT,
        signature_recipient TEXT,
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
        FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE SET NULL,
        FOREIGN KEY (driver_id) REFERENCES drivers(id) ON DELETE SET NULL
    );
    """)

    # 9. Notifications Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        order_id INTEGER,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        notification_type TEXT DEFAULT 'info' CHECK(notification_type IN ('delay', 'route_update', 'plan_approval', 'order_status', 'info')),
        is_read INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
    );
    """)

    # 10. Delivery Plan Changes (Audit Trail for AI Re-routing)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS delivery_plan_changes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        disruption_id INTEGER,
        affected_vehicles_count INTEGER DEFAULT 0,
        affected_orders_count INTEGER DEFAULT 0,
        average_delay_mins INTEGER DEFAULT 0,
        plan_summary TEXT NOT NULL,
        proposed_actions_json TEXT NOT NULL,
        status TEXT DEFAULT 'pending_approval' CHECK(status IN ('pending_approval', 'approved', 'rejected', 'applied')),
        approved_by INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        applied_at TIMESTAMP,
        FOREIGN KEY (disruption_id) REFERENCES disruptions(id) ON DELETE SET NULL,
        FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL
    );
    """)

    # Create Performance Indexes
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders(customer_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_vehicle ON orders(assigned_vehicle_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_vehicles_status ON vehicles(status);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read);")

    conn.commit()
    conn.close()
    print("[DB] Database initialized successfully with all tables and indexes.")

if __name__ == "__main__":
    init_db()
